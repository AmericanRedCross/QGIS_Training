# -*- coding: utf-8 -*-
#
# 1-Band Raster Colour Table (c) BC Consulting 2010
#
#    This file is part of "bcccoltbl"
#
#    bcccoltbl is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    bcccoltbl is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with bcccoltbl.  If not, see <http://www.gnu.org/licenses/>.
#
#===============================================================================
# WARNING: this code is not pythonic at all. I'm in no way a python programmer..
#          corrections are more than welcome if properly explained.
#          (trying to learn by mistakes!)
#===============================================================================
#
#DoColorTable.py
#    A class where all the hard work of creating a colour table is done.
#===============================================================================
#V1.1.0 - 25 October 2010
#===============================================================================
#
import os
import string
import numpy as np
from math import *
#
# Colouring method contants
ctEQUAL   = 0
ctLINEAR  = 1
ctNORMAL  = 2
ctGEOSOFT = 3
ctGRASSdm = 4
ctGRASS   = 5
ctEXP     = 6
ctLN      = 7
ctPOWER   = 8
ctLOGA    = 9
ctUSER    = 10
ctCATLAY  = 11
ctLOG     = 12
ctPOW     = 13
#
class ColorTable():
    """
    #       A class to compute different colouring methods to be applied
    #                    on a raster and a colour palette
    #
    # This code is not pythonic AT ALL!!!
    #    it is a straight manual conversion from VB
    #    by a VB programmer with ZERO experience in python... LOL
    """

    def __init__(self, NbColours, RasterStats, tabFile):
        # Init some values and constants
        self.lERR      = ""
        self.strFile   = tabFile
        self.nColo     = NbColours
        self.S         = RasterStats
        #
        self.nClass    = self.S.nClass
        self.vMin      = self.S.vMin
        self.vMax      = self.S.vMax
        self.mean      = self.S.mean
        self.STDev     = self.S.STDev
        self.npts      = self.S.npts + 1
        self.arHisto   = self.S.Histo
        #
        #This is the product of this class
        self.arColV    = np.zeros((self.nColo),np.float32)
        #   it contains nColo indices and the real raster Z value at each index
#-------------------------------------------------------------------------------

    def DoTable(self, lColMeth, lOpt, N=None):
        """
        lColMeth: colour scaling code to apply
        lOpt: option relevant to the current colour method (not used here)
        """
        #
        self.lERR = ""
        if lColMeth < 0 :
            return "ERROR: Colouring method is unknown!"
        #
        #Get real value <-> colour index from user selected distribution
        if (lColMeth == ctEQUAL):
        #Equal area distribution (histogram equalization)
            self.DoEqual()
        #
        elif (lColMeth == ctLINEAR):
        #Linear distribution
            #Linear ramp
            self.DoLinear()
        #
        elif (lColMeth == ctNORMAL):
        #Normal distribution: 8-colour
            self.DoNormal()
        #
        elif (lColMeth == ctGEOSOFT):
        #Normal distribution - standard algorithm (Geosoft)
            self.DoNormalG()
        #
        elif (lColMeth == ctGRASS):
        #Normal distribution: GRASS style (colour bands)
            #black | red | yellow | green | green | yellow | red | black
            self.DoNormal()
        #
        elif (lColMeth == ctGRASSdm):
        #Normal distribution: GRASS style (differences map)
            #blue | 14 colours from blue- to white- | white |
            #                               14 colours from white- to red- | red
            self.DoNormalR()
        #
        elif (lColMeth == ctCATLAY):
        #Categorical layer: number of colours = number of classes,
        #break on integer numbers
            self.DoCategorical()
        #
        elif (lColMeth == ctLOG):
        #Log distribution
            self.DoLog()
        #
        elif (lColMeth == ctEXP):
        #Exponential distribution
            self.DoExp()
        #
        #Finally we return either the colour index array or an error message
        if self.lERR == "":  return self.arColV
        return self.lERR
#-------------------------------------------------------------------------------

    def IsNumeric(self, var):
        """
        Return True if the argument can be converted to a valid float number
        """
        #
        try:
            float(var)
            return True
        except ValueError:
            return False
#-------------------------------------------------------------------------------

    def RescalePal(self, j):
        """
        not enough "data values" compared to number of colours
        need to stretch the data values
        """
        #
        temp = np.ones((self.nColo), np.float32)
        tmp = -1e32*temp
        rr = self.nColo / j
        n = self.nColo -1
        #distribute real values along all the colours range
        for i in range(j):
            #new index
            d = int(i * rr)
            if d <= n: tmp[d] = self.arColV[i]
        if tmp[n] < -5e31: tmp[n] = self.arColV[j]
        self.arColV = np.zeros((self.nColo), np.float32)
        self.arColV = tmp
        tmp = None
        i  = 1
        j0 = 1    #first empty slot
        #now we iterate over the whole nColo range and interpolate the
        #real values over empty slots
        #The first slot arColV[0] is already filled with first real value
        #so we first find the next non-empty slot
        for i in range(1,self.nColo):
            if (self.arColV[i] > -5E+31):
                #we've found the next non-empty slot
                #interpolate over j0 and i-1
                # we have a value at (j0-1) and at (i)
                dV = (self.arColV[i] - self.arColV[j0-1]) / float(i - j0 +1)
                for k in range(j0,i):
                    self.arColV[k] = self.arColV[j0-1] + float(k - j0 +1) * dV
                #new first empty slot position
                j0 = i +1
#-------------------------------------------------------------------------------

    def DoEqualIntern(self, Histo):
        """
        Equal-area distribution of colours over value range

        Work on histogram bins

        We now need to compute the Z-value at which the sum (t) of
        the n classes reaches a value very near to npts/nColo.
        We then reset the sum to zero and carry on up to the last class
        in Histo().
        """
        #
        self.arColV = np.zeros((self.nColo),np.float32)
        dV = (self.vMax - self.vMin) / float(self.nClass)
        tresh = int(float(self.npts) / float(self.nColo) + 0.5)
        t = 0
        k = -1
        for i in range(self.nClass):
            t = t + Histo[i,0]
            if (t >= tresh):
                k = k + 1
                if (k == self.nColo): break
                self.arColV[k] = self.vMin + float(i) * dV
                t = t - tresh
        if k < self.nColo -1:
            if (self.arColV[k] < self.vMax) and (k <= self.nColo -1):
                if (k < (self.nColo -1)): k = k + 1
                self.arColV[k] = self.vMax +dV
            if (k < self.nColo-1): self.RescalePal(k)
            #
        else:
            if (self.arColV[self.nColo -1] < self.vMax):
                self.arColV[self.nColo -1] = self.vMax +dV
        return True
#-------------------------------------------------------------------------------

    def DoEqualG(self, hist):
        """
        Equal-area distribution of colours over value range

        Work on cumulative histogram

        We now need to classify this histogram into
        a second histogram (iHist2()) having at most nColo
        classes by summing the original classes from the first
        class up to the time the summed value reaches a value
        very near npts/nClass. We then reset the sum to zero
        and carry on up to the last class in hist().
        """
        #
        j = 1
        iHist2      = np.zeros((self.nColo), int)
        self.arColV = np.zeros((self.nColo), np.float32)

        #Normalise to [0, nColo] & fill iHist2()
        #this result in iHist2() having indexes of when the normalised
        #hist() value increases by one
        d0 = 1
        dV = (self.nColo - 1) / (hist[self.nClass-1, 1] - hist[0, 1])
        for i in range(self.nClass):
            d = 1 + dV * (hist[i, 1] - hist[0, 1])
            if d > d0:
                iHist2[j] = i
                j = j + 1
                d0 = d
        iHist2[j] = self.nClass-1   #max value
        #
        dV = (self.vMax - self.vMin) / float(self.nClass)
        for i in range(self.nColo):
            self.arColV[i] = self.vMin + (iHist2[i] + 1) * dV
        if j < self.nColo-1: self.RescalePal(j)
#-------------------------------------------------------------------------------

    def DoEqual(self):
        #
        self.DoEqualIntern(self.arHisto)
#-------------------------------------------------------------------------------

    def DoLinear(self):
        """ Linear distribution of colours over value range """
        #
        self.arColV = np.zeros((self.nColo),np.float32)
        dV = (self.vMax - self.vMin) / float(self.nColo)
        for i in range(self.nColo):
            self.arColV[i] = self.vMin + float(i+1) * dV
#-------------------------------------------------------------------------------

    def DoLog(self):
        """
        Log distribution of values over the colours range

        Algorithm:
           let Max = vMax - vMin +1, Min = 1 and V' = V - vMin +1
               nColo is number of colours
           then (we distribute the log of the values in the [0, nColo[ range):
              log(Max) - log(Min)  <-->  nColo - 1
              log(V')  - log(Min)  <-->    i

           thus (we extract V'):
              V' = 10**( log(Min) + i/(nColo-1) * (log(Max) - log(Min)) )
              log(Min) = log(1) = 0
              V' = 10**((i/(nColo-1) * log(Max))
              V' = (10**(log(Max))**(i/(nColo-1))
              V' = Max**(i/nColo-1)
           and:
              V = ( vMax - vMin +1 )**( 1/(nColo-1) )

        Notes:
          - Whatever the log-base it seems that the algorithm gives the same
            values.
        """
        #
        self.arColV = np.zeros((self.nColo),np.float32)
        vMi = self.vMin - 1
        dV  = (self.vMax - vMi)
        for i in range(self.nColo):
            self.arColV[i] = vMi + dV **((float(i)/float(self.nColo-1)))
#-------------------------------------------------------------------------------

    def DoExp(self):
        """
        Exponential distribution of values over the colours range

        In order to avoid overflow we use the [9, 10] interval to compute the
        exponential distribution over the number of colours. Then we scale those
        values to the set of real values.
        """
        #
        self.arColV = np.zeros((self.nColo),np.float32)
        N    = 10                        #use base-10
        aMin = 9.0                       #minimum value of our dummy interval
        aMax = 10.0                      #maximum value of our dummy interval
        eMin = N**(aMin)
        eAI  = N**aMax - N**aMin
        for i in range(self.nColo):
            # compute exponential value in the [9, 10] range
            v = math.log( eMin + (float(i)/float(self.nColo-1)) * eAI , N )
            # scale that value to a value in the real range [vMin, vMax]
            self.arColV[i] = self.vMin + (v - 9.0)*(self.vMax - self.vMin)
#-------------------------------------------------------------------------------

    def DoCategorical(self):
        """
        Categorical layer:
           number of classes = number of colours, break on integer numbers
           if number of classes > number of colours => truncation of classes
           if number of classes < number of colours => higher colours are absent
        """
        #
        self.arColV = np.zeros((self.nColo),np.int)
        for i in range(self.nColo):
            self.arColV[i] = self.vMin + i
#-------------------------------------------------------------------------------

    def DoNormal(self):
        """
        Normal distribution of 8 colours over +/- 4 STD
        also GRASS colour band
          4 STD   |_|
                  | |
                  | | colour 8 (4 STD)
          3 STD   |_|
                  | |
                  | | colour 7
          2 STD   |_|
                  | |
                  | | colour 6
          1 STD   |_|
                  | |
                  | | colour 5
          Mean    |_|
                  | |
                  | | colour 4 (mean)
         -1 STD   |_|
                  | |
                  | | colour 3
         -2 STD   |_|
                  | |
                  | | colour 2
         -3 STD   |_|
                  | |
                  | | colour 1 (-3 STD)
         -4 STD   |_|
        """
        #
        if self.nColo <> 8:
            lERR = "WARNING: Can only use an 8-colour table!"
            return
        #Mean
        mean = self.mean
        #Standard Deviation (STD)
        STD = self.STDev
        #Middle of cumulative curve
        nMid = self.FindMiddle()
        #dim our arrays
        self.arColV = np.zeros((self.nColo), np.float32)
        arP = np.zeros((self.nColo), np.float32)
        #Offset between normal distribution and current distribution
        # in [0,1] space
        X = 0.5 - nMid / float(self.nClass)
        #Starting value (-3STD)
        dV = -3.0 * STD + mean
        #Compute cdf for each of:
        #    -3STD, -2STD, -STD, mean, +STD, +2STD, +3STD, +4STD
        for i in range(self.nColo):
            arP[i] = self.cdf(dV, mean, STD)   #result is between [0,1]
            #convert to real grid values
            self.arColV[i] = self.vMin + (arP[i] - X) * (self.vMax - self.vMin)
            #next value
            dV = dV + STD
        #Make sure we stay within vMin & vMax
        #Skewed towards the left
        if (self.arColV[self.nColo-1] < self.vMax):
            self.arColV[self.nColo-1] = self.vMax
        for i in range(self.nColo):
            if (self.arColV[i] < self.vMin): self.arColV[i] = self.vMin
            else:                            break
        #Skewed toward the right
        if (self.arColV[1] > self.vMin):     self.arColV[1] = self.vMin
        for i in range(self.nColo-1,0,-1):
            if (self.arColV[i] > self.vMax): self.arColV[i] = self.vMax
            else:                            break
#-------------------------------------------------------------------------------

    def DoNormalG(self):
        """ Normal distribution Geosoft style """
        #
        #Mean
        mean = self.mean
        #Standard Deviation (STD)
        STD = self.STDev
        #
        #Compute cumulative histogram on the normal curve having mean and
        # STD as parameters
        # f(x) = 1/SQRT(2Pi*STD^2) * EXP(-(x - mean)^2/(2STD^2))
        # where:
        #   x    = histogram bin number (value along x-axis)
        #   mean = mean of all histogram bins value
        #   STD  = standard deviation of all histogram bins value
        #   Pi   = 4*ATN(1)
        #   SQRT = square root
        #   EXP  = e power
        #   ATN  = arctangent
        #
        hist = self.arHisto
        dS = 2.0 * STD * STD
        d = 1.0 / sqrt(4.0 * atan(1.0) * dS)
        #we compute normal curve from -4*STD to +4*STD
        dXs = 8.0 * STD / float(self.nClass)
        #Starting value
        X = -4.0 * STD
        #find maximum of normal curve
        Y1 = -1E+20
        nMid = self.nClass-1
        n2 = int(hist[self.nClass-1,1] / 2)
        iMax = 0
        iMid = 0
        for i in range(self.nClass):
            if hist[i,0]>iMax: iMax = hist[i,0]
        #
        for i in range(self.nClass):
            if (abs(hist[i,1] - n2) < nMid):
                #find middle point of cumulative values of real curve
                nMid = abs(hist[i,1] - n2)
                iMid = i
            Y = d * exp(-pow((X - mean), 2) / dS)
            if (Y1 < Y): Y1 = Y   #Maximum
            hist[i,1] = 0
            #new bin
            X = X + dXs
        Y1 = iMax / Y1   #scale factor for scaling normal curve range to iMax
        #do it now
        X = -4.0 * STD
        for i in range(self.nClass):
            #number of point in current normal bin
            Y = d * exp(-pow((X - mean), 2) / dS) * Y1
            j = int(Y)
            #cumulative histogram
            if (i > 0): hist[i,1] = hist[i - 1,1] + j
            else:       hist[i,1] = j
            #new bin
            X = X + dXs
        if (hist[self.nClass-1,1] == 0): return
        #Find middle of normal curve
        jMid = self.FindMiddle()
        #Offset between normal and real middle
        if (jMid <> iMid): iMid = iMid - jMid
        else:              iMid = 0
        #Shift normal curve to real curve position
        if (iMid < 0):
            #Move left
            j = self.nClass + iMid
            for i in range(j):
                hist[i,1] = hist[i - iMid,1]
            for i in range(j + 1, self.nClass):
                hist[i,1] = hist[j,1]
        elif (iMid > 0):
            #Move right
            j = iMid
            for i in range(j, self.nClass):
                hist[i,1] = hist[i - iMid,1]
            for i in range(0, j):
                hist[i,1] = hist[j,1]
        #finish it
        self.DoEqualG(hist)
#-------------------------------------------------------------------------------

    def DoNormalR(self):
        """
        Normal distribution GRASS style: differences map only
        colour band is dealt with DoNormal

        ------------------------------------------------------------------------
        r.colors.stddev set raster map color rules based on standard deviations
        from a map's mean value, either as a continuous color gradient or in
        color bands per standard deviation from the mean.

        With the color band option values less that 1 S.D. from the mean are
        colored green, within 1-2 S.D. are colored yellow, within 2-3 S.D. are
        colored red, and beyond 3 S.D. are colored black.

        For a differences map there is an option to lock the center of the color
        table at zero. Values more than two S.D. below the mean will be colored
        blue; values below the mean but less than 2 S.D. away will transition to
        white, and above the mean the colors will simularly transition to full
        red at +2 S.D.
        ------------------------------------------------------------------------
        """
        #
        #Mean
        mean = self.mean
        #Standard Deviation (STD)
        STD = self.STDev
        #Middle of cumulative curve
        nMid = self.FindMiddle()
        #dim our arrays
        self.arColV = np.zeros((self.nColo), np.float32)
        arP = [0,0,0]
        #Offset between normal distribution and current distribution
        # in [0,1] space
        X = 0.5 - nMid / float(self.nClass)
        #Compute cdf for each of -2STD, mean, +2STD
        dV = -2.0 * STD + mean
        Y = self.cdf(dV, mean, STD)  #result is between [0,1]
        #convert to real grid values
        arP[0] = self.vMin + (Y - X) * (self.vMax - self.vMin)
        dV = mean
        Y = self.cdf(dV, mean, STD)
        arP[1] = self.vMin + (Y - X) * (self.vMax - self.vMin)
        dV = 2.0 * STD + mean
        Y = self.cdf(dV, mean, STD)
        arP[2] = self.vMin + (Y - X) * (self.vMax - self.vMin)
        #
        if arP[0] < self.vMin: arP[0] = self.vMin
        if arP[2] > self.vMax: arP[2] = self.vMax
        #
        if (arP[1] < self.vMin or arP[1] > self.vMax):
            lERR = "ERROR: Cannot compute this colour scheme!"
            return
        #
        #31 colours:
        #    1, 2 blue
        #    3 - 16 blue to white
        #   16 - 31 white to red
        self.arColV[0]  = arP[0]
        self.arColV[16] = arP[1]
        self.arColV[30] = arP[2]
        #distribute the other colour linearly
        dV = (arP[1] - arP[0]) / 15.0
        for i in range(2, 16):
            self.arColV[i] = arP[0] + float(i - 1) * dV
        dV = (arP[2] - arP[1]) / 14.0
        for i in range(17, 31):
            self.arColV[i] = arP[1] + float(i - 16) * dV
        self.arColV[self.nColo-1] = self.vMax
#-------------------------------------------------------------------------------

    def FindMiddle(self):
        """ Find and return the middle point of the cumulative curve """
        #
        nMid = self.nClass
        jMid = self.nClass / 2
        # half value of cumulative curve
        n2 = int(self.arHisto[self.nClass-1,1] / 2)
        for i in range(self.nClass):
            # >0 as long as we are left on middle point
            j = n2 - self.arHisto[i,1]
            if (j < 0):
                #past or at middle, exit
                break
            elif (j < nMid):
                #find middle point
                nMid = j
                jMid = i
        return jMid
#-------------------------------------------------------------------------------

    def Fact(self, n):
        """
        Compute the factorial of x (x!)
         4! = 4*3*2*1 = 24
        """
        #
        d = 1.0
        for i in range(2, n+1):
            d = d * i
        return d
#-------------------------------------------------------------------------------

    def erf(self, X):
        """ Compute the error function erf with limited precision """
        #
        nPrecision = 21
        d = 0.0
        for i in range(0, nPrecision):
            n = 2 * i + 1
            d = d + pow((-1), i) * (pow(X, n) / (n * self.Fact(i)))
        return (2.0 / sqrt(4.0 * atan(1.0)) * d)
#-------------------------------------------------------------------------------

    def cdf(self, X, mean, STD):
        """
        Compute the cumulative distribution function (cdf) as point x
        mean: is the distribution mean
        STD:  is the distribution standard deviation

        Asumption, the distribution is normal...
        """
        #
        d = (X - mean) / (sqrt(2.0) * STD)
        return (0.5 * (1.0 + self.erf(d)))
#
#===============================================================================