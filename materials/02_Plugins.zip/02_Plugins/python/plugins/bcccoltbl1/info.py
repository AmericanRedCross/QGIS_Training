# -*- coding: utf-8 -*-
#
# 1-Band Raster Colour Table (c) BC Consulting 2010
#
#    This file is part of "bcccoltbl"
#
#    This file is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This file is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this file.  If not, see <http://www.gnu.org/licenses/>.
#
#===============================================================================
# info.py
#     Information about the plugin
#
#===============================================================================
#
currVersion   = "1.1.2"
currDate      = "27 December 2011"
MSG_BOX_TITLE = "1-Band Raster Colour Table V1.x"
Author        = "BC Consulting - benoit-3 at bc-consult dot com"
Icon          = ":/plugins/bcccoltbl1/img/bcccoltbl.png"
Linfo         = ("This plugin creates colour tables for a 1-band raster from "
                "preset colour palettes and colouring methods.")
inMenu        = "Raster Colours"
HlpURL        = "http://www.bc-consult.com/free/bcccoltbl1.html"
#
description="This plugin creates colour tables for a 1-band raster from preset colour palettes and colouring methods."
name="1-Band Raster Colour Table V1.x"
version="Version 1.1.2"
icon=":/plugins/bcccoltbl1/img/bcccoltbl.png"
qgisMinimumVersion="1.6.0"
class_name="RasterColour"
author="BC Consulting"
email_address="benoit-3 at bc-consult dot com"
url="http://www.bc-consult.com/free/bcccoltbl1.html"
#
#===============================================================================
#
ccM  = ["Equal area distribution (histogram equalization)",
        "Linear distribution",
        "Log distribution",
        "Power distribution",
        "Normal distribution (8 colours)",
        "Normal distribution (Geosoft style)",
        "Normal distribution GRASS style (differences map)",
        "Normal distribution GRASS style (Colour band)"]
ccM1 = ["Categorical layer"]
#
#===============================================================================
#
def Usage():
    """ Return usage and info message about the plugin """
    #
    import platform
    from PyQt4.QtCore import *
    #
    L = """<p align="center"><b>%s</b><br />
    (c) BC Consulting 2010<br />&nbsp;<br />
    Version: %s<br />%s<br />&nbsp;<br /><br />
    %s<br /><br />
    Help available <a href="%s">here</a><br />&nbsp;</p>
    <p>This plugin is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.</p>

    <p>This plugin is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.</p>

    <p>You should have received a copy of the GNU General Public License along
    with this plugin. If not, see [<a href="http://www.gnu.org/licenses/"
    target="blank">http://www.gnu.org/licenses/</a>].</p>
    <p>&nbsp;</p>
    <p align="center"><i>Python %s - Qt %s - PyQt %s on %s</i></p>
""" % (MSG_BOX_TITLE, str(currVersion), str(currDate), Linfo, HlpURL,
       platform.python_version(),
       QT_VERSION_STR, PYQT_VERSION_STR, platform.system())
    #
    return L
#
#===============================================================================