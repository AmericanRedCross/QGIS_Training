# -*- coding: utf-8 -*-
#
# 1-Band Raster Colour Table (c) BC Consulting 2010
#
#    This file is part of "bcccoltbl"
#
#    bcccoltbl is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    bcccoltbl is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with bcccoltbl.  If not, see <http://www.gnu.org/licenses/>.
#
#===============================================================================
# WARNING: this code is not pythonic at all. I'm in no way a python programmer..
#          corrections are more than welcome if properly explained.
#          (trying to learn by mistakes!)
#===============================================================================
#
# vscbar.py
#    Vertical scale bar for raster legend.
#
#===============================================================================
#V1.0.0 - 20 October 2010
#===============================================================================
#
#  little essential things needed for the smooth running of the code...
#
import os
import sys
import string
import math
import numpy as np

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PyQt4.uic import *
#
#===============================================================================
#    Utilities functions
#
class storeVar():
    def __init__(self):
        """ Stores needed to construct a colour scale bar.
            This info comes from either the QGIS dialog box
            or the standalone app.
        """
        self.txtDeci    = 2
        self.bEnforce   = True
        self.scTitle    = ''
        self.scUnits    = ''
        self.scFontSize = 10
        self.bH         = False
        self.bV         = True
        self.bAuto      = True
        self.nbTicks    = -1
        self.boxW       = 10
        self.boxH       = 1
        self.doExtrema  = True
        self.mini       = ' '

    def __str__(self):
        """ Return the string representation of storeVar """
        return  "txtDeci    : "+str(self.txtDeci   )+"\n" \
                "bEnforce   : "+str(self.bEnforce  )+"\n" \
                "scTitle    : "+str(self.scTitle   )+"\n" \
                "scUnits    : "+str(self.scUnits   )+"\n" \
                "scFontSize : "+str(self.scFontSize)+"\n" \
                "bH         : "+str(self.bH        )+"\n" \
                "bV         : "+str(self.bV        )+"\n" \
                "bAuto      : "+str(self.bAuto     )+"\n" \
                "nbTicks    : "+str(self.nbTicks   )+"\n" \
                "boxW       : "+str(self.boxW      )+"\n" \
                "boxH       : "+str(self.boxH      )+"\n" \
                "doExtrema  : "+str(self.doExtrema )+"\n" \
                "mini       : "+str(self.mini      )+"\n"
#
#===============================================================================
#
def GetL(d, n, bEnforce):
    """
    Format a number

    d       : number to format
    n       : number of decimal places
    bEnforce: True will force the number of decimals to be 'n', adding 0s if
              necessary
    """
    if int(n) == 0:
        L = str(int(round(float(d))))
    else:
        L = ("%.*f" % (int(n),float(d)))
        if not bEnforce: L = L.rstrip("0")
    if L[-1] == ".": L = L[:-1]
    return L
#
#===============================================================================
#
class scVLgd(QWidget):
    def __init__(self, nC, arColo, arV, Vmin, parent=None):
        """
        Create a vertical scale bar

        nC:       number of colours in array arColo()
        arColo(): R, G, B values
        arV():    real life values
        Vmin:     minumum real life value

        We use a trick in here because Qt's painter cannot display text outside
        of a paintEvent() envent!
        We thus create a dummy widget and call its paintEnvent() function on
        creation!
        """
        super(scVLgd, self).__init__(parent)
        self.nC      = nC
        self.arColo  = arColo
        self.arV     = arV
        self.md      = storeVar()
        self.md.mini = Vmin
        #
        [b, self.myIMG] = self.paintEvent()
        if not b: self.myIMG = ""

    def retrieveIMG(self):
        return self.myIMG

    def paintEvent(self, event=None):
        nC       = int(self.nC)
        arColo   = self.arColo
        arV      = self.arV
        md       = self.md
        offset   = int(md.boxH)
        #
        # We start by finding the minimum dimension of the final scale bar
        # in order to do that we create a dummy painting device and
        # compute the total height and width of all elements to be put in
        # the scale bar: title, unit, ticks annotations & colour boxes.
        #
        hi = 0    #height of block enclosing title + unit lines
        wi = 0    #width of block enclosing title + unit lines
        wl = 0    # max number of chars of ticks annotations
        wt = 0    # width of the longest ticks annotation
        jt = 0    # height of a tick annotation, also bottom margin
        ht = 0    # total Height of the image
        pw = 0    # total Width of the image
        LT = ''
        LU = ''
        #
        myIMG = QImage(500,2000,QImage.Format_RGB32)
        myIMG.fill(0)
        #
        myP = QPainter()
        if not myP.begin( myIMG ):  return [False, ""]
        #
        myBrush = QBrush()
        myBrush.setColor(QColor("white"))
        myP.setBackground(myBrush)
        myP.setBrush(QColor("black"))
        myP.setPen(QColor("black"))
        #
        # set text properties for ticks annotations (user defined)
        myFNT = QFont()
        myFNT.setFamily("arial")
        myFNT.setPointSize(int(md.scFontSize))
        myFNT.setBold( False )
        myP.setFont(myFNT)
        fm = QFontMetricsF(myFNT)
        hh = fm.height()
        #
        #Define necessary space to plot the scale bar with its ticks and title
        i = nC / 2  # we plot min, max and middle values
        # width of the longest annotation
        L = GetL(arV[i], md.txtDeci, md.bEnforce)
        vmin = GetL(md.mini, md.txtDeci, md.bEnforce)
        v = GetL(arV[nC-1], md.txtDeci, md.bEnforce)
        wl = max(len(str(L)), len(str(vmin)), len(str(v)))
        text = QString("0" * wl)
        wt = fm.boundingRect(QString(text)).width()
        #
        # Height of a tick annotation
        jt = fm.boundingRect(QString("Qq")).height()
        #
        # Bounding rectangle for the annotations
        mPtF = QPointF()
        xx   = int(md.boxW) + 12
        mPtF.setX(float(xx))
        nRect = fm.boundingRect(text)
        #
        # Remove dummy painter
        myFNT=''
        myP.end()
        myIMG = ''
        #
        #------------------------- Start painting now --------------------------
        #
        # Total Height of the image
        ht = int(md.boxH) * (nC +1) + jt + jt
        # Total Width of the image
        pw = int(md.boxW) + 13 + wt  # width of box + tick + annotation
        #
        # Create a new QImage of the correct size and draw the scale bar on it
        myIMG = QImage(pw,ht,QImage.Format_RGB32)
        mc = QColor(255,255,255)
        myIMG.fill(mc.rgb())
        # create a new QPainter for the QImage
        myP = QPainter()
        if not myP.begin( myIMG ): return [False, ""]
        #
        # set text properties
        myFNT = QFont()
        myFNT.setFamily("arial")
        myFNT.setPointSize(int(md.scFontSize))
        myFNT.setBold( False )
        fm = QFontMetricsF(myFNT)
        myP.setFont(myFNT)
        myP.setRenderHint(QPainter.TextAntialiasing)
        #
        # Colour bar
        for i in range(nC):
            colo = QColor(arColo[i, 0], arColo[i, 1], arColo[i, 2])
            myP.setBrush(colo)
            myP.setPen(colo)
            h = ht - int(md.boxH) * i - jt
            myP.drawRect(0, h - int(md.boxH), int(md.boxW), int(md.boxH))
        colo = QColor(0,0,0,255)
        myP.setBrush(QColor(0,0,0,0))
        myP.setPen(colo)
        #
        # bounding rectangle
        y0 = ht - float(md.boxH)*(nC-1) -jt -offset
        myP.drawRect(0, y0, int(md.boxW)+1, int(md.boxH)*nC)
        #
        #----------------- Tick annotations
        L0 = " " * wl
        #
        if fm.height() < nC:
            #middle annotation
            i     = nC / 2
            i0    = ht - int(md.boxH) * i - jt
            text  = QString(GetL(arV[i], md.txtDeci, md.bEnforce))
            y     = i0 + fm.height() / 2.0 - offset
            y1    = i0 - offset
            mPtF.setY(float(y))
            rectf = QRectF(nRect)
            rectf.moveBottomLeft(mPtF)
            myP.drawText(rectf, Qt.AlignRight, text)       # annotation
            myP.drawLine(xx -10, y1, xx -5, y1)            # tick
        #
        #bottom extremum
        text  = QString(GetL(vmin, md.txtDeci, md.bEnforce))
        rectf = QRectF(nRect)
        y     = ht - jt
        mPtF.setY(float(y + fm.height()))
        rectf.moveBottomLeft(mPtF)
        myP.drawText(rectf, Qt.AlignRight, text)
        myP.drawLine(xx -10, y, xx -5, y)
        #
        #top extremum
        text  = QString(GetL(arV[nC-1], md.txtDeci, md.bEnforce))
        rectf = QRectF(nRect)
        mPtF.setY(float(y0))
        rectf.moveBottomLeft(mPtF)
        myP.drawText(rectf, Qt.AlignRight, text)
        myP.drawLine(xx -10, y0, xx -5, y0)
        #
        # Finally return the image
##        myIMG.save("C:/img.png")
        myFNT=''
        myP.end()
        return [True, myIMG]
#
#===============================================================================