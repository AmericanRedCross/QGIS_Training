# -*- coding: utf-8 -*-
"""
 ***************************************************************************
                         1-Band Raster Colour Table
            A QGIS plugin creates a colour table for a 1-band raster
                from preset colour palettes and colouring method
                           -------------------
    begin                : 2010-10-20
    copyright            : (C) 2010 by BC Consulting
    email                : Benoit-3 at bc-consult dot com
 ***************************************************************************

 ***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 3 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************

 ***************************************************************************
 *                                                                         *
 *       bcccoltbl is distributed in the hope that it will be useful,      *
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of     *
 *       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the      *
 *                GNU General Public License for more details.             *
 *                                                                         *
 ***************************************************************************
"""
import info
def name():
  return info.MSG_BOX_TITLE
def description():
  return info.Linfo
def authorName():
  return info.Author
def version():
  return info.currVersion
def qgisMinimumVersion():
  return "1.5"
def classFactory(iface):
  # load Plugin class from file bcccoltbl.py
  from bcctbl import bcccoltbl
  return bcccoltbl(iface)
#
#===============================================================================