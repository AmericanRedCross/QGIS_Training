# -*- coding: utf-8 -*-
#
# 1-Band Raster Colour Table (c) BC Consulting 2010
#
#    This file is part of "bcccoltbl"
#
#    bcccoltbl is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    bcccoltbl is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with bcccoltbl.  If not, see <http://www.gnu.org/licenses/>.
#
#===============================================================================
# WARNING: this code is not pythonic at all. I'm in no way a python programmer..
#          corrections are more than welcome if properly explained.
#          (trying to learn by mistakes!)
#===============================================================================
#
#Palette.py
#  class to handle reading a colour palette into an array
#===============================================================================
#V1.0.0 - 20 October 2010
#===============================================================================
#
#  little essential things needed for the smooth running of the code...
#
from PyQt4.QtCore import *
from PyQt4.QtGui import *

import os
import string
import math
import numpy as np
#
#===============================================================================
#
class Palette():
    def __init__(self, palPath, colorbrewer = False):
        """
        Class for reading a palette file from disk and filling the
        arColo array (RGBA values) each in [0,255]
        nColo = the number of colours in the palette array
        If colorbrewer is True, then import a ColorBrewer palette string.
        -------------------------------------------------------------------------------
         Fill-in the arColo() array with nColo taken from the palPTH table file
         Colour palettes can be defined in different colour systems:
           The first non-blank line of the file has one of the following format:
               { hue sat val }                # for HSV colour space
               {  red   grn   blu}            # for RGB colour space
               {  blk   cyn   mag   yel}      # for CMYK colour space
               {  cyn   mag   yel}            # form CMY colour space
           Notes:
             - the end of line should be just after } on the lines above
             - the order of the colour codes cannot be changed! They must be as above
             - the alpha channel is always set to 255 although provision is made to
               read it from the colour palette file.
        -------------------------------------------------------------------------------
        """
        #init parameters
        self.nColo = -1
        self.arColo = np.ones((1000,4),int)
        #
        if colorbrewer:
            self.ImportCB(palPath)
            return
        #
        # get content of the palette file
        strFile = palPath
        try:
            fpal = open(strFile, 'r')
            buff = ""
            for L in fpal:
                buff = buff + L
            fpal.close()
        except:
            #we cannot access the requested palette, load default palette
            buff = LoadGrey()
        #
        # remove consecutive white spaces
        buff = buff.replace("\t"," ")
        buff = buff.replace(","," ")
        while (buff.find("  ") > -1):
            buff = buff.replace("  "," ")
        # split it into constituent values
        ar = buff.splitlines()
        # get to the header line
        idx = 0
        while (ar[idx].strip(' ') == ""):
            idx = idx + 1
        i1 = len(ar)
        # take the first character of the header line
        L = ar[idx].strip(' ')
        L = L[1:-1].strip(' ')       #Trim$(Mid$(L, 2, Len(L) - 2))
        L = L[:1].lower()
        #
        # create the arColo[] list of r,g,b values
        self.nColo = -1
        arC = [0,0,0,0]
        for i in range(idx+1, i1):
            ar[i] = ar[i].strip(' ')
            if ar[i] != "":
                br = ar[i].split(" ")
                if (L == "b"):
                    if len(br) == 3:
                       self.KCMY2RGB(0, br[0], br[1], br[2], arC)
                    else:
                       self.KCMY2RGB(br[0], br[1], br[2], br[3], arC)
                    if len(br) <= 4: arC[3] = 255
                    else:            arC[3] = br[4]
                elif (L == "c"):
                    arC[0] = 255 - int(br[0])  #cyan -> red
                    arC[1] = 255 - int(br[1])  #magenta -> green
                    arC[2] = 255 - int(br[2])  #yellow -> blue
                    if len(br) <= 3: arC[3] = 255
                    else:            arC[3] = br[3]
                elif (L == "h"):
                    self.HSV2RGB(br[0], br[1], br[2], arC)
                    if len(br) <= 3: arC[3] = 255
                    else:            arC[3] = br[3]
                elif (L == "r"):
                    arC[0] = int(br[0])   #red
                    arC[1] = int(br[1])   #green
                    arC[2] = int(br[2])   #blue
                    if len(br) <= 3: arC[3] = 255
                    else:            arC[3] = br[3]
                else:
                    pass
                self.nColo += 1
                self.arColo[self.nColo,0] = arC[0]
                self.arColo[self.nColo,1] = arC[1]
                self.arColo[self.nColo,2] = arC[2]
                self.arColo[self.nColo,3] = arC[3]

    def ToRRRGGGBBB(self,i):
        """
        Format a colour from arColo as RRRGGGBBB. (unused for now)
        """
        r='000'+str(self.arColo[i,0])
        g='000'+str(self.arColo[i,1])
        b='000'+str(self.arColo[i,2])
        return r[-3:]+g[-3:]+b[-3:]

    def KCMY2RGB(self,iBl,iCy,iMa,iYe,arC):
        """
        -- Transform CMYK to RGB
        """
        cmyk = QColor()
        cmyk.setCmyk(int(iCy), int(iMa), int(iYe), int(iBl))
        (arC[0], arC[1], arC[2], alpha) = cmyk.getRgb()

    def HSV2RGB(self,iHue,iSat,iValue,arC):
        """
        -- Transform CMYK to RGB
        """
        hsv = QColor()
        hsv.setHsv(int(iHue), int(iSat), int(iValue))
        (arC[0], arC[1], arC[2], alpha) = hsv.getRgb()

    # interfaces to export useful objects
    def getColPalette(self, bInvert = False, bReverse = False):
        """
        -- return the colour palette array
        """
        if bInvert:
            #invert the colour palette
            for i in range(self.nColo+1):
                self.arColo[i,0] = 255 - self.arColo[i,0]
                self.arColo[i,1] = 255 - self.arColo[i,1]
                self.arColo[i,2] = 255 - self.arColo[i,2]
        if bReverse:
            #reverse the colours order
            ar = np.zeros((self.nColo+1,4),int)
            n = self.nColo
            for i in range(self.nColo+1):
                ar[i,0] = self.arColo[n -i,0]
                ar[i,1] = self.arColo[n -i,1]
                ar[i,2] = self.arColo[n -i,2]
            self.arColo = ar
        return self.arColo

    def getNumberOfColours(self):
        """
        -- return the number of colours in the palette array
        """
        return self.nColo

    def ImportCB(self, cbPalette):
        """
        Import a ColorBrewer colour palette into the arColo array

        cbPalette: string containing the ColorBrewer palette:
        e.g.:
            254, 240, 217; 253, 204, 138; 252, 141, 89; 227, 74, 51; 179, 0, 0;
            is a 5-colour palette (r, g, b; r, g, b; ...)
        """
        #
        arPal       = cbPalette.split(";")
        self.nColo  = len(arPal) -1
        self.arColo = np.ones((512,4),int)
        for i in range(self.nColo):
            rgb = arPal[i].split(",")
            self.arColo[i,0] = int(rgb[0])
            self.arColo[i,1] = int(rgb[1])
            self.arColo[i,2] = int(rgb[2])
            self.arColo[i,3] = 255
        self.nColo  -= 1
#
#=================================================================================================================
#
def LoadGrey():
    greypal="""{    black      cyan   magenta    yellow  }
       224         0         0         0
       208         0         0         0
       192         0         0         0
       176         0         0         0
       160         0         0         0
       152         0         0         0
       144         0         0         0
       128         0         0         0
       120         0         0         0
       112         0         0         0
       104         0         0         0
        96         0         0         0
        88         0         0         0
        80         0         0         0
        72         0         0         0
        64         0         0         0
        60         0         0         0
        56         0         0         0
        52         0         0         0
        48         0         0         0
        44         0         0         0
        40         0         0         0
        36         0         0         0
        32         0         0         0
        28         0         0         0
        24         0         0         0
        20         0         0         0
        16         0         0         0
        12         0         0         0
         8         0         0         0
         4         0         0         0
         0         0         0         0
    """
    return greypal
