# -*- coding: utf-8 -*-
#
#===============================================================================
# Name:        bcctbl
# Purpose:     workhorse of the plugin
#
# Author:      BC Consulting
#
# Created:     20/10/2010
# Copyright:   (c) BC Consulting 2010
# Licence:
#    This plugin is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This plugin is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this plugin. If not, see <http://www.gnu.org/licenses/>.
#===============================================================================
#
# This file contains the following objects:
# - bcccoltbl: the class to create and run the plugin (called by __init__)
# - cdlgTBL:   the user interface mechanics
# and six helper functions
#
#===============================================================================
#
from xml.dom import minidom
import os
import sys
import string
import math
import numpy as np
import tempfile
import pickle
import operator
import platform
#
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PyQt4.uic import *
#
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
#
from osgeo import gdal
from osgeo.gdalconst import *
#
#The objects for this project
try:
    import utils
    import info as uu
    import vscbar
    import resources
    from loadManually import *
    from ColorTable import *
    from Palette import *
    from ui_dlgColourTable import Ui_bccTBL
except ImportError, e:
  error_str = "Cannot find bcccoltbl1 modules!"
  raise ImportError( error_str )
#
#===============================================================================
#
def setRasterColourTable(theLayer, theTBL):
    """
    Apply the colour table to the temp raster
    This has the disadvantage of making QGIS compute the stats on the raster the
    first time it is called
    """
    #
    # - tell the layer to use a QgsColorRampShader function
    theLayer.setColorShadingAlgorithm( QgsRasterLayer.ColorRampShader )
    # - get a pointer to the raster shader function
    #   (QgsColorRampShader)
    myColorRampShader = theLayer.rasterShader().rasterShaderFunction()
    # - set parameters for the QgsColorRampShader function
    myColorRampShader.setColorRampType( QgsColorRampShader.DISCRETE )
    myColorRampShader.setColorRampItemList( theTBL )
    theLayer.setDrawingStyle( QgsRasterLayer.SingleBandPseudoColor )
    # - refresh map & legend
    if hasattr(theLayer, "setCacheImage"):
        theLayer.setCacheImage( None )
    theLayer.triggerRepaint()
#
#===============================================================================
#
def FormatString(v, vDeci = -1):
    """
    Return a number to a given format
    v number to format
    bDeci: number of decimals
    """
    #
    i = int(vDeci)
    if (i > -1): L = "%." + str(i) + "f"

    try:
        d = float(v)
        if (i > -1):
           return (L % d)
        elif (d == float(int(v))):
           return ("%i" % int(d))
        elif (d < 0.001):
             return ("%.8f" % d)
        elif (d < 10):
             return ("%.4f" % d)
        elif (d < 10000):
             return ("%.2f" % d)
        else:
             return ("%i" % int(d))
    except:
        return str(v)
#
#===============================================================================
#
def get_tempdir():
    """
    Return a folder in temp directory where to store all palette little pics
    """
    #
    tempdir = os.path.join(tempfile.gettempdir(), 'bccapps')
    if not os.path.exists(tempdir): os.mkdir(tempdir)
    return tempdir
#
#===============================================================================
#
def toCode(lColMeth):
    """ Code the colouring method """
    #
    if   lColMeth == uu.ccM[0]:  return ctEQUAL
    elif lColMeth == uu.ccM[1]:  return ctLINEAR
    elif lColMeth == uu.ccM[2]:  return ctLOG
    elif lColMeth == uu.ccM[3]:  return ctPOW
    elif lColMeth == uu.ccM[4]:  return ctNORMAL
    elif lColMeth == uu.ccM[5]:  return ctGEOSOFT
    elif lColMeth == uu.ccM[6]:  return ctGRASSdm
    elif lColMeth == uu.ccM[7]:  return ctGRASS
    elif lColMeth == uu.ccM1[0]: return ctCATLAY
    else:
        return -1
#
#===============================================================================
#
def toSymb(lColMeth):
    """ Code the colouring method for file output """
    #
    if   lColMeth == uu.ccM[0]:  return 'EQ'
    elif lColMeth == uu.ccM[1]:  return 'LI'
    elif lColMeth == uu.ccM[2]:  return 'LG'
    elif lColMeth == uu.ccM[3]:  return 'PO'
    elif lColMeth == uu.ccM[4]:  return 'NO'
    elif lColMeth == uu.ccM[5]:  return 'GE'
    elif lColMeth == uu.ccM[6]:  return 'DM'
    elif lColMeth == uu.ccM[7]:  return 'GR'
    elif lColMeth == uu.ccM1[0]: return 'CL'
    else:
        return '--'
#
#===============================================================================
#
def GetRasterType(fi1):
    """ Return True if the GDAL data type is either byte or int16 """
    #
    #Open the GDAL driver
    gdal.AllRegister()
    dsin1 = gdal.Open(fi1, GA_ReadOnly)
    if dsin1 is None:
       strInfo = 'Could not open required file!'
       dsin1   = None
       return False, strInfo
    #
    # Get data type
    band1 = dsin1.GetRasterBand(1)
    dt    = ((band1.DataType == GDT_Byte) or (band1.DataType == GDT_Int16))
    band1 = None
    dsin1 = None
    return True, dt
#
#===============================================================================
#
class cdlgTBL(QDialog, Ui_bccTBL):
    """
    The user interface mechanics

    All interactions with the user are handled in here.
    Computations of the colour table are also done here.
    """

    def __init__(self, iface, FilePath, theFileIN, dum, parent=None):
        """
        iface:  the QGIS interface
        FilePath: the path to the selected raster
        theFileIN: the name of the selected raster
        dum:  the NaN value (dummy)
        """
        #
        # Initialise class and setup the graphical interface
        super(cdlgTBL, self).__init__(iface.mainWindow())
        self.setupUi(self)
        # QGIS objects
        self.iface  = iface
        self.canvas = self.iface.mapCanvas()
        # Placeholder for the layer to use to show previews of the col. tables
        self.theLayer = None
        # Path to the py script folder
        self.FilePath = FilePath
        # The name of the raster to act on
        self.theFileIN   = theFileIN
        (theFile,theExt) = os.path.splitext(self.theFileIN)
        # The data type of the raster (to allow Categorical layer method)
        b, self.RasterDT = GetRasterType(os.path.join(FilePath,theFileIN))
        if not b: self.RasterDT = 0
        # The placeholder name of the created colour table
        self.theFileTBL = theFile + '¥.txt'
        self.theFileTBL = os.path.join(self.FilePath,self.theFileTBL)
        # Extension of the raster file
        self.theExt = theExt
        # System temp dir
        self.TMPdir = get_tempdir()
        # Flag: 0 no computation has been done, 1 colour table is created
        self.bJobDone = 0
        # imgColPal display the selected colour palette
        self.imgColPal.setText('')
        # Set the Create button as default
        self.btnCreate.setDefault(1)
        # Width & height of the imgColPal widget
        self.w = self.imgColPal.sizeHint().width()
        self.h = self.imgColPal.sizeHint().height()
        # The Not-A-Value value
        self.lDum  = dum
        # Initialise number of colours in colour palette
        self.nColo = 0
        # Flag to know if we have to invert the colour palette
        self.InvertPalette = False
        # Flag to know if we have to revert the colours
        self.RevertPalette = False
        # Flag to tell that we use an external colour palette
        self.DoColorBrewer = False
        # System name for a colorbrewer external palette
        self.ColBrew       = "* ColorBrewer Palette *"
        # Current ColorBrewer palette
        self.cbBACK = ""
        # Various flag for program flow execution
        self.bOutOfHere    = False
        self.bbOUT         = False
        self.theTBL        = False
        self.OK            = False
        self.bFirst        = True
        # An object to store all the stats/histogram info about the raster
        self.myGRD = ""
        # Data values at the colour palette top intervals
        self.arColV = []
        # Selected colour palette
        self.arColo = np.ones((512,4),int)
        # Number of colour palettes name in crTBLS[]
        self.nTBLS  = 0
        # Current QML filename
        self.LTBL         = ""
        # Statistics info about raster values
        self.strSTATSInfo = ""
        # Keep track of the colour tables created during this session
        self.crTBLS = []
        # Graphics elements to display info to user
        self.lbTBLName.setText(self.theFileTBL)
        self.lbLayerName.setText(self.theFileIN)
        #Path to the bcccoltbl.xml file (definition of all palettes)
        self.bccPath = "C:/bcc/Plugins/bcccoltbl1/allP/"
        if os.access(str(self.bccPath + "bcccoltbl.xml"), os.F_OK):
            #BC Consulting own private colour palettes
            self.userPluginPath = str( self.bccPath )
        else:
            #Public colour palettes (provided with the plugin)
            self.userPluginPath = str( QFileInfo(
                                  QgsApplication.qgisUserDbFilePath() ).path() +
                                  "/python/plugins/bcccoltbl1/" )
        #-----------------------------------------------------------------------
        #
        # Read the colour palettes name and colouring methods name and
        #  fill respective comboboxes
        xmlFile = os.path.join(str(self.userPluginPath), "bcccoltbl.xml")
        if not os.path.exists(xmlFile):
            [self.nbPals,
             self.lPals,
             self.nbSrt,
             self.lSrt]   = loadManually(self, self.RasterDT)
            QMessageBox.warning(self, uu.MSG_BOX_TITLE,
                                         'WARNING - The xml file is not found!')
        else:
            try:
                #parse the xml file
                xmldoc = minidom.parse(xmlFile)
            except:
                [self.nbPals,
                 self.lPals,
                 self.nbSrt,
                 self.lSrt]  = loadManually(self, self.RasterDT)
                QMessageBox.warning(self, uu.MSG_BOX_TITLE,
                                                 'WARNING - XML parsing error!')
            else:
                #
                #fill in the colouring methods combobox
                self.cbColMeth.clear()
                self.cbColMeth.addItems( uu.ccM )
                if self.RasterDT: self.cbColMeth.addItems( uu.ccM1 )
                #
                #Get the colour palettes info
                allcol = xmldoc.getElementsByTagName("ColPal")
                col    = allcol[0]
                c      = col.getElementsByTagName("cp")
                self.nbPals = len(c)
                self.lPals  = range(self.nbPals)
                for i in range(self.nbPals):
                    ns    = c[i]
                    nelem = ns.attributes["value"]
                    nid   = ns.attributes["id"]
                    nc    = ns.attributes["class"]
                    self.lPals[i]    = [0,0,0]
                    self.lPals[i][0] = nelem.value
                    self.lPals[i][1] = ('00000' + nid.value)[-5:]
                    self.lPals[i][2] = nc.value
                #Get colour palettes classes
                allcol = xmldoc.getElementsByTagName("ColPalClasses")
                col    = allcol[0]
                c      = col.getElementsByTagName("cl")
                self.nbSrt = len(c)+1
                self.lSrt  = range(self.nbSrt)
                self.lSrt[0]    = [0,0]
                self.lSrt[0][1] = 'ALL'
                self.lSrt[0][0] = "All palettes"
                for i in range(1,self.nbSrt):
                    ns     = c[i-1]
                    nelem  = ns.attributes["value"]
                    nid    = ns.attributes["id"]
                    self.lSrt[i]    = [0,0]
                    self.lSrt[i][1] = nid.value
                    self.lSrt[i][0] = nelem.value
        #
        #-------------------------------------
        # create the palettes thumbnail images
        # to go into dropdown menu
        self.CreatePalettes()
        #-------------------------------------
        #
        # Sort colours by their id (default is colour number)
        self.SortPalette(0)
        #
        # Palette classification
        self.cbSortBy.clear()
        for i in range(self.nbSrt):
            self.cbSortBy.addItem( self.lSrt[i][0] )
        #
        #-----------------------------------------------------------------------
        # Set up the UI comms
        #
        # Colour palette selected
        QObject.connect(self.cbColPal, SIGNAL("activated(int)"),
                                                             self.ShowPalette)
        # Colour palette classification selected
        QObject.connect(self.cbSortBy, SIGNAL("currentIndexChanged(int)"),
                                                             self.SortPalette)
        # Colour method selected
        QObject.connect(self.cbColMeth, SIGNAL("currentIndexChanged(int)"),
                                                             self.TestMethod)
        # Create colour table
        QObject.connect(self.btnCreate, SIGNAL("clicked()"), self.applyTBL)
        QObject.connect(self.btnCreate, SIGNAL("pressed()"), self.applyTBL)
        # Close button
        QObject.connect(self.btnClose, SIGNAL("clicked()"),  self.accept)
        QObject.connect(self.btnClose, SIGNAL("pressed()"),  self.accept)
        # Cancel button
        QObject.connect(self.btnCancel, SIGNAL("clicked()"), self.reject)
        QObject.connect(self.btnCancel, SIGNAL("pressed()"), self.reject)
        # Help button
        QObject.connect(self.btnHelp, SIGNAL("clicked()"),   self.helpme)
        QObject.connect(self.btnHelp, SIGNAL("pressed()"),   self.helpme)
        # About button
        QObject.connect(self.btnAbout, SIGNAL("clicked()"),  self.about)
        QObject.connect(self.btnAbout, SIGNAL("pressed()"),  self.about)
        # Invert Colour palette
        QObject.connect(self.ckInvert, SIGNAL("stateChanged(int)"),
                                                             self.InvPalette)
        # Reverse colours
        QObject.connect(self.ckReverse, SIGNAL("stateChanged(int)"),
                                                             self.RevPalette)
        #
        #-----------------------------------------------------------------------
        # Define and display the default colour palette (32 grey)
        self.cbColPal.setCurrentIndex(self.DefaultColPal)
        L0 = self.UpdateFN()
        self.ShowPalette()

    #---------------------------------------------------------------------------
    def computeRasterStats(self):
        """
        Compute or retrieve the stats for the current raster
        Happens only once, when the plugin is launched on the selected raster
        """
        #
        (theFile, theExt) = os.path.splitext(self.theFileIN)
        theFile = os.path.join(self.FilePath,theFile + ".bccPAL1")
        #
#
#Ugly patch: ignore the bccpal1 file altogether and compute stats from raster!
#
#        if os.access(theFile, os.F_OK):
#            # We've already loaded this raster from this folder previously
#            # and user did not delete our file: load required info from it.
#            # This has the advantage to speed up stats loading
#            [grd, b] = self.LoadWork(theFile)
#        else:
#            # First time we act on this file, so take the pain to load its stats
#            # the slow way
#            [grd, b] = self.__computeRasterStats()
        [grd, b] = self.__computeRasterStats()
#------------------------------------------------------------------------------
#
        #
        if b:
            # All OK for now, show stats info to the user
             self.strSTATSInfo = """
                 <p>Band X size: %i<br />Band Y size: %i<br />
                 Total number of points: %i<br />
                 Number of points used in histogram: %i</p>
                 <p>Minimum data value: %.3f<br />
                 Maximum data value: %.3f<br />
                 Average value: %.3f<br />
                 Standard deviation: %.3f</p>
                 """ % (grd.S.nX, grd.S.nY, grd.S.nX*grd.S.nY, grd.S.npts,
                        grd.S.vMin, grd.S.vMax, grd.S.mean, grd.S.STDev)
             self.txtInfo.setText(self.strSTATSInfo)
             #
             # The stats object is being filled
             self.myGRD = grd
        #
        return b

    #---------------------------------------------------------------------------
    def __computeRasterStats(self):
        """
        Compute the stats for the current raster
        This is a GDAL only routine. It is very fast compare to QGIS stats func
        because GDAL only uses a sub-set of the data even with bApproxOK = 0

        Possible problem: if dummy is NaN then QGIS (& numpy) considers it as
        0.0, if there is true zeros in the data set they will be considered
        as dummies!
        """
        #
        grd         = utils.oneBandRaster(self.theLayer)
        grd.S.lDum  = float(self.lDum)
        grd.S.Histo = np.zeros((grd.S.nClass, 2), int)
        # Use GDAL to get the needed variables
        gdal.AllRegister()
        gd = gdal.Open(str(self.theLayer.source()), GA_ReadOnly)
        self.pBar.setValue(10)                       # show progress to the user
        band     = gd.GetRasterBand(1)
        grd.S.nX = band.XSize
        grd.S.nY = band.YSize
        grd.S.vMin,grd.S.vMax,grd.S.mean,grd.S.STDev = band.GetStatistics(0, 1)
        self.pBar.setValue(70)
        # Get the histogram from GDAL
        a = 0.0001
        HistoGDAL = band.GetHistogram(grd.S.vMin-a, grd.S.vMax+a, grd.S.nClass)
        self.pBar.setValue(90)
        # Convert the histogram to a bcccoltbl object
        grd.S.Histo[:,0] = HistoGDAL[:]
        # Compute cumulative histogram
        grd.S.Histo[0,1] = grd.S.Histo[0,0]
        for i in range(1, grd.S.nClass):
            grd.S.Histo[i,1] = grd.S.Histo[i - 1,1] + grd.S.Histo[i,0]
        grd.S.npts = grd.S.Histo[grd.S.nClass-1, 1]
        # We're done with the stats/histo computations
        self.pBar.setValue(100)
        return [grd, True]

    #---------------------------------------------------------------------------
    def setRaster(self, rasterL):
        """
        Add the temporary raster, same raster as the one selected by user but
        in a new layer on top of all layers
        """
        #
        layer = QgsRasterLayer(rasterL, 'bccRaster', True)
        if not layer.isValid():
            raise IOError, "Failed to open the layer"
        # add layer to the registry
        QgsMapLayerRegistry.instance().addMapLayer(layer)
        self.theLayer = layer

    #---------------------------------------------------------------------------
    def setColourTable(self, theTBL):
        """
        Apply the colour table to the temp raster
        This has the disadvantage of making QGIS compute the stats on the raster
        """
        #
        strInfo = "Please wait QGIS computes statistics on raster..."
        self.txtFD.setText(strInfo)
        setRasterColourTable(self.theLayer, theTBL)
        self.txtFD.setText("")

    #---------------------------------------------------------------------------
    def LoadWork(self, theFile):
        """ Set the myGRD object from saved data """
        #
        dd = open(theFile,"rb")
        try:
            self.pBar.setValue(50)
            grd = pickle.load(dd)
            dd.close()
            self.pBar.setValue(100)
            return [grd, True]
        except:
            dd.close()
            return ["", False]

    #---------------------------------------------------------------------------
    def SaveWork(self):
        """ Save the myGRD object to file """
        #
        (theFile,theExt) = os.path.splitext(self.theFileIN)
        dd = open(os.path.join(self.FilePath,theFile+".bccPAL1"),"wb")
        pickle.dump(self.myGRD,dd,pickle.HIGHEST_PROTOCOL)
        dd.close()

    #---------------------------------------------------------------------------
    def ParseTBL(self, LTBL):
        """
        Parse the colour table (QML file) to create a
        QgsColorRampShader::ColorRampItem Struct
        """
        #
        # Full name to the colour table to load
        theTBLfile = os.path.join(self.FilePath,str(LTBL))
        if not os.path.exists(theTBLfile):
            QMessageBox.critical(self, uu.MSG_BOX_TITLE,
                             "ERROR: colour table not found:\n"+str(theTBLfile))
            return False
        else:
            sc = open(theTBLfile,'r')
            ar = sc.readlines()
            sc.close()
            #
            nC = 0
            colorRampEntries = []
            #
            for a in ar:
                if a.find(",") >= 0:
                    #value,r,g,b,alpha
                    #-0.65480690,1,1,1,255,
                    br = a.split(",")
                    red = int(br[1])   #red
                    gre = int(br[2])   #green
                    blu = int(br[3])   #blue
                    alp = int(br[4])   #alpha
                    colorRampEntries.append(QgsColorRampShader.ColorRampItem())
                    colorRampEntries[nC].label = QString(" ")
                    colorRampEntries[nC].value = float(br[0])
                    colorRampEntries[nC].color = QColor(red, gre, blu, alp)
                    nC += 1
            #
            return colorRampEntries

    #---------------------------------------------------------------------------
    def SaveColTable(self):
        """
        Save mapped colour table to a QGIS compatible file
        """
        #
        try:
            if os.access(self.tableFile, os.F_OK): os.remove(self.tableFile)
            odx = open(self.tableFile,"w")
            odx.write("INTERPOLATION:DISCRETE\n")
            self.LTBL = str(os.path.basename(self.tableFile))
            LL   = ""
            sTbl = ""
            if abs(self.myGRD.S.vMax - self.myGRD.S.vMin) > 1e-3: Ndec = 5
            else:                                                 Ndec = -1
            for i in range(self.nColo):
                L = (FormatString(self.arColV[i], Ndec).rjust(14)
                                 +","+str(self.arColo[i,0]).rjust(3)
                                 +","+str(self.arColo[i,1]).rjust(3)
                                 +","+str(self.arColo[i,2]).rjust(3)
                                 +","+str(self.arColo[i,3]).rjust(3))
                sTbl += L.strip() + ", \n"
                LL   += L + "<br />"
            odx.write(sTbl)
            odx.close()
            #
            if not self.bFirst:
                # display stats & colour table
                self.txtInfo.setText(self.strSTATSInfo)
                strInfo = (
"""<p>--------------------------------------------------------------------------
< br />%s<pre><font face="Courier, monospace, Courier New">%s%s</font></pre></p>
"""
                       % (self.LTBL, LL, "-----------------------------------"))
                self.txtInfo.append(strInfo)
            #
            self.nTBLS += 1
            self.crTBLS.append(self.LTBL)
            if self.cbCreatedTBL.findText(self.LTBL) == -1:
                self.cbCreatedTBL.addItem(self.LTBL)
            if not self.cbCreatedTBL.isEnabled():
                self.cbCreatedTBL.setEnabled(True)
            return ""
        except:
            return ("ERROR: cannot save the colour table to file!!\n" +
                                                                 self.tableFile)

    #---------------------------------------------------------------------------
    def SortPalette(self, idx):
        """ Show only the colour palettes from selected range """
        #
        self.DefaultColPal = -1
        self.GRASSdmColPal = -1
        self.GRASSColPal   = -1
        igr                = -1
        idm                = -1
        Sorted             = sorted(self.lPals, key=operator.itemgetter(1))
        sortparam          = self.lSrt[idx][1]
        self.bbOUT         = True
        self.cbColPal.clear()
        #
        self.cbColPal.addItem(self.ColBrew)
        tmpFile = self.userPluginPath + "cTBLs/cbp.png"
        self.cbColPal.setItemData(0, QPixmap(tmpFile), Qt.DecorationRole)
        #
        k = 1
        for i in range(self.nbPals):
            if ((Sorted[i][2] == sortparam) or sortparam == 'ALL'):
                    tmpFile= os.path.join(self.TMPdir, str(Sorted[i][0])+".png")
                    self.cbColPal.addItem( str(Sorted[i][0]) )
                    self.cbColPal.setItemData(k, QPixmap(tmpFile),
                                                              Qt.DecorationRole)
                    # keep the ColPal id number for later use
                    if Sorted[i][0]   == '032_grey':       self.DefaultColPal= k
                    elif Sorted[i][0] == '008_GRASSstdev': self.GRASSColPal  = k
                    elif Sorted[i][0] == '031_GRASSdm':    self.GRASSdmColPal= k
                    k += 1
            elif Sorted[i][0] == '008_GRASSstdev': igr = i
            elif Sorted[i][0] == '031_GRASSdm':    idm = i
        if sortparam != 'ALL':
            # Always add the two special GRASS colour palettes
            if igr > -1:
                tmpFile =(os.path.join(self.TMPdir, str(Sorted[igr][0])+".png"))
                self.cbColPal.addItem( str(Sorted[igr][0]) )
                self.cbColPal.setItemData(k, QPixmap(tmpFile),Qt.DecorationRole)
                self.GRASSColPal = k
                k += 1
            if idm > -1:
                tmpFile = os.path.join(self.TMPdir, str(Sorted[idm][0])+".png")
                self.cbColPal.addItem( str(Sorted[idm][0]) )
                self.cbColPal.setItemData(k, QPixmap(tmpFile),Qt.DecorationRole)
                self.GRASSdmColPal = k
        #
        if (self.DefaultColPal == -1): self.DefaultColPal = 1
        self.ShowPalette()
        self.bbOUT = False

    #---------------------------------------------------------------------------
    def InvPalette(self, iSt):
        """ Get the invert palette state """
        #
        self.InvertPalette = bool(iSt)
        self.ShowPalette()

    #---------------------------------------------------------------------------
    def RevPalette(self, iSt):
        """ Get the reverse colours state """
        #
        self.RevertPalette = bool(iSt)
        self.ShowPalette()

    #---------------------------------------------------------------------------
    def TestMethod(self, idx):
        """
        If user selects one of the GRASS colouring method, we
        change the palette to the relevant one.
        """
        #
        if idx == ctGRASSdm:
            #select colour palette 031_GRASSdm
            self.cbColPal.setCurrentIndex(self.GRASSdmColPal)
            self.ShowPalette()
        elif idx == ctGRASS:
            #select colour palette 008_GRASSstdev
            self.cbColPal.setCurrentIndex(self.GRASSColPal)
            self.ShowPalette()
        else:
            #do nothing...
            pass
        self.UpdateFN()

    #---------------------------------------------------------------------------
    def ShowPalette(self):
        """
        Display the colour palette in the imgColPal widget
        for user to see what it is all about.
        """
        #
        #display name of the colour table when it will be created
        MethodSelected = self.UpdateFN()
        #Get the colour palette coulours from the relevant colour palette file
        if not self.DoColorBrewer:
            palPTH = self.userPluginPath + "cTBLs/" + MethodSelected + ".tbl"
        else:
            palPTH = MethodSelected
        myPalette = Palette(palPTH, self.DoColorBrewer)
        self.arColo = myPalette.getColPalette(self.InvertPalette,
                                                             self.RevertPalette)
        self.nColo  = myPalette.getNumberOfColours()+1
        myPalette = None
        # We create a QImage object to draw the colour palette onto
        myIMG = QImage(self.nColo,1,QImage.Format_RGB32)
        myIMG.fill(0)
        #Draw the colour palette onto it
        for i in range(self.nColo):
            r = self.arColo[i,0]
            g = self.arColo[i,1]
            b = self.arColo[i,2]
            a = self.arColo[i,3]
            tempcol = QColor(r, g, b, a)
            myIMG.setPixel(i,0,tempcol.rgba())
            myIMG.setPixel(i,1,tempcol.rgba())
        #create another QImage object and stretch the image to
        # the size of the imgColPal widget
        myIMGsc = myIMG.scaled(self.w,self.h,Qt.IgnoreAspectRatio,
                                                          Qt.FastTransformation)
        #finally copy the scaled image to the widget
        self.imgColPal.setPixmap(QPixmap.fromImage(myIMGsc))

    #---------------------------------------------------------------------------
    def CreatePalettes(self):
        """ Create pixmap files of all palettes present """
        #
        w = 150
        h = 8
        for j in range(self.nbPals):
            tmpFile = (os.path.join(self.TMPdir, str(self.lPals[j][0])+".png"))
            if not os.access(tmpFile,os.F_OK):
                #Create the colour palette icon from the relevant
                # colour palette file
                palPTH = self.userPluginPath + "cTBLs/" + self.lPals[j][0] + \
                                                                          ".tbl"
                myPalette = Palette(palPTH)
                arColo = myPalette.getColPalette(False, False)
                nColo  = myPalette.getNumberOfColours()+1
                myPalette = None
                # We create a QImage object to draw the colour palette onto
                myIMG = QImage(nColo,1,QImage.Format_RGB32)
                myIMG.fill(0)
                #Draw the colour palette into it
                for i in range(nColo):
                    tempcol = QColor(arColo[i,0], arColo[i,1], arColo[i,2],
                                                               arColo[i,3])
                    myIMG.setPixel(i,0,tempcol.rgba())
                    myIMG.setPixel(i,1,tempcol.rgba())
                #Create another QImage object and stretch the image to
                # the size of the imgColPal widget
                myIMGsc = myIMG.scaled(w,h,Qt.IgnoreAspectRatio,
                                                          Qt.FastTransformation)
                myIMGsc.save(tmpFile)
                myIMGsc = None
                myIMG = None

    #---------------------------------------------------------------------------
    def UpdateFN(self):
        """
        Create the name of the colour table when it is created and display it
        """
        #
        if self.bbOUT: return ""
        # default colorbrewer palette
        cbDef = "237,248,251;178,226,226;102,194,164;44,162,95;0,109,44;"
        #
        self.DoColorBrewer = False
        L0 = self.cbColPal.currentText()
        if str(L0) == self.ColBrew:
            # Ask user for the colour palette definition
            self.DoColorBrewer = True
            if  self.cbBACK == "":
                cbPal, b = QInputDialog.getText(self,
                              "Paste a ColourBrewer palette",
                              "Copy and paste the *R*G*B* ColourBrewer palette "
                              "values in the box below from the 'simple copy-"
                              "n-paste' box on the colorbrewer web site.\n"
                              "Don't forget the ending ';'")
                if b: L0 = str(cbPal)
                else: L0 = cbDef
                self.cbBACK = str(L0)
            else:
                L0 = self.cbBACK
            L = '_ColorBrewer_' + toSymb(self.cbColMeth.currentText())
        #
        else:
             self.cbBACK = ""
             L = '_' + L0 + '_' + toSymb(self.cbColMeth.currentText())
        #
        if self.InvertPalette: L = L + 'i'
        if self.RevertPalette: L = L + 'r'
        self.tableFile = self.theFileTBL.replace("¥",L,1)
        self.lbTBLName.setText(self.tableFile)
        return L0

    #---------------------------------------------------------------------------
    def applyTBL(self):
        """
        The main routine to create the colour table in function of
        the parameters selected by user.
        user has selected a colour palette and a colouring method
        we already have reduced the raster to imgRST
        so we need now to apply the new colouring method to the raster and
        use the colour palette to display the resulting colour table
        """
        #
        if self.bOutOfHere:
            self.bOutOfHere = False
            return
        self.bOutOfHere = True
        #
        self.txtFD.setText("Computing colour table...")
        #1- Get stats
        self.pBar.setValue(0)
        myStats = self.myGRD.getStats()
        #-2 create the colour table and save it:
        self.pBar.setValue(20)
        lColMeth = toCode(self.cbColMeth.currentText())
        #
        if lColMeth==ctGRASSdm and self.cbColPal.currentText() != '031_GRASSdm':
            QMessageBox.critical(self, uu.MSG_BOX_TITLE,
                                 str('You can only use colour table '
                                      '031_GRASSdm for this colouring method!'))
            self.txtFD.setText("")
            return
        if lColMeth==ctGRASS and self.cbColPal.currentText() !='008_GRASSstdev':
            QMessageBox.critical(self, uu.MSG_BOX_TITLE,
                                 str('You can only use colour table '
                                   '008_GRASSstdev for this colouring method!'))
            self.txtFD.setText("")
            return
        #
        lOpt = ''
        self.tableFile = str(self.lbTBLName.text())
        self.pBar.setValue(30)
        myTable = ColorTable(self.nColo, myStats, self.tableFile)
        self.pBar.setValue(50)
        self.arColV = myTable.DoTable(lColMeth, lOpt)
        #test if it is a string => error
        try:
            a=float(self.arColV[self.nColo-1])
        except:
            QMessageBox.critical(self,uu.MSG_BOX_TITLE,str(self.arColV))
            self.txtFD.setText("")
            return
        #
        #-3 save the colour table
        self.pBar.setValue(70)
        status = self.SaveColTable()
        if status != "":
            QMessageBox.critical(self,uu.MSG_BOX_TITLE,str(status))
        #-4 display coloured raster
        self.pBar.setValue(90)
        theTBL = self.ParseTBL(self.LTBL)
        self.setColourTable(theTBL)
        #-5 set the completed flag
        self.bJobDone = 1
        #-6 save histogram and stats to disk
        self.SaveWork()
        self.pBar.setValue(100)
        self.txtFD.setText("")

    #---------------------------------------------------------------------------
    def accept(self):
        """ Close button is clicked. Does the job has been done? """
        #
        if self.bOutOfHere:
            self.bOutOfHere = False
            return
        self.bOutOfHere = True
        #
        if self.bJobDone == 0:
            # Nothing has been done, ask user if she really wants to quit
            rep = QMessageBox.question(self, uu.MSG_BOX_TITLE,
                                       'Are you sure you want to quit?',
                                       QMessageBox.Yes, QMessageBox.No)
            if rep == QMessageBox.Yes:
                #close app
                self.reject()
        else:
            LTBL = self.cbCreatedTBL.currentText()
            if LTBL == "":
               # No table is selected, tell user what to do next
                strInfo = ("Now import one of the colour tables using the "
                           "raster properties dialog.\n"
                           "   You have created the following colour tables:")
                if self.nTBLS > 10:
                    for i in range(5):
                        strInfo += "\n    -  "+str(self.crTBLS[i])
                    strInfo += "    \n       ..."
                    n = self.nTBLS -5
                    for i in range(n, self.nTBLS):
                        strInfo += "\n    -  "+str(self.crTBLS[i])
                else:
                    for i in range(self.nTBLS):
                        strInfo += "\n    -  "+str(self.crTBLS[i])
                QMessageBox.information(self,uu.MSG_BOX_TITLE,strInfo)
            else:
                # Set the selected colour table to the raster
                self.theTBL = self.ParseTBL(LTBL)
            #
            #close app
            self.OK = True
            self.reject()

    #---------------------------------------------------------------------------
    def helpme(self):
        """ provide some help: display the HTML help file """
        #
        if self.bOutOfHere:
            self.bOutOfHere = False
            return
        self.bOutOfHere = True
        self.iface.openURL(uu.HlpURL,False)
        self.bOutOfHere = False

    #---------------------------------------------------------------------------
    def about(self):
        """ Info about this plugin """
        #
        QMessageBox.about(self,uu.MSG_BOX_TITLE,uu.Usage())
#
#===============================================================================
#
class bcccoltbl():

    def __init__(self, iface):
        # save reference to the QGIS interface (QgsInterface = iface)
        self.iface = iface

    #---------------------------------------------------------------------------
    def initGui(self):
        # create action that will start plugin configuration
        infopl = "Create colour table(s) for 1-band raster"
        self.action = QAction(QIcon(uu.Icon), uu.MSG_BOX_TITLE
                              , self.iface.mainWindow())
        self.action.setWhatsThis(infopl)
        self.action.setStatusTip(infopl)
        QObject.connect(self.action, SIGNAL("triggered()"), self.cdlgTBLcr)
        # add toolbar button and menu item
        if hasattr(self.iface, "addPluginToRasterMenu"):
            # new menu available so add both actions into PluginName submenu
            # under Raster menu
            self.iface.addPluginToRasterMenu( uu.inMenu, self.action )
            # and add Run button to the Raster panel
            self.iface.addRasterToolBarIcon( self.action )
        else:
            # oops... old QGIS without additional menus. Place plugin under
            # Plugins menu as usual
            self.iface.addPluginToMenu( uu.inMenu, self.action )
            # and add Run button to the Plugins panel
            self.iface.addToolBarIcon(self.action)

    #---------------------------------------------------------------------------
    def unload(self):
        # remove the plugin menu item and icon
        if hasattr(self.iface, "addPluginToRasterMenu"):
            # new menu used, remove submenus from main Raster menu
            self.iface.removePluginRasterMenu( uu.inMenu, self.action )
            # also remove button from Raster toolbar
            self.iface.removeRasterToolBarIcon( self.action )
        else:
            # Plugins menu used, remove submenu and toolbar button
            self.iface.removePluginMenu( uu.inMenu, self.action )
            self.iface.removeToolBarIcon( self.action )

    #---------------------------------------------------------------------------
    def CleanUp(self, theLayer, theCanvas, bkExtent):
        """ Remove temp layer and restore previous zoom state """
        #
        try:
            # Remove temp layer
            LID = theLayer.getLayerID()
            QgsMapLayerRegistry.instance().removeMapLayer(LID)
            # Zoom back to original extent (only if user hasn't changed it)
            if bkExtent == theCanvas.extent():
                self.iface.zoomToPrevious()
            self.iface.setActiveLayer(self.theSelectedLayer)
        except:
            pass

    #---------------------------------------------------------------------------
    def cdlgTBLcr(self):
        """ Create and display the dialog to do the colour table """
        #
        # We run some tests to see if the selected raster is suitable
        if QGis.QGIS_VERSION_INT < 10600:
            QMessageBox.warning(self.iface.mainWindow(),uu.MSG_BOX_TITLE,
                                "This plugin requires a QGIS version greater "
                                "than 1.6!/nYou cannot use it on your current "
                                "version: %s" % QGis.QGIS_VERSION)
            return
        #
        # Get the active layer and ensure that it is an image
        theLayer = self.iface.activeLayer()
        self.theSelectedLayer = theLayer
        if theLayer is None or theLayer.type() != QgsMapLayer.RasterLayer:
            QMessageBox.warning(self.iface.mainWindow(),uu.MSG_BOX_TITLE,
                                "No Raster Layer Selected\n"
                                "You must first select a 1-band raster in order"
                                " to create a colour table for it!")
            return
        #
        # current layer is an image, go ahead
        n = theLayer.bandCount()
        if n > 1:
            #but it is multiband => abort!
            QMessageBox.critical(self.iface.mainWindow(),
                                 uu.MSG_BOX_TITLE,
                                 "ERROR: You must use a one-band raster!\n"
                                 "The selected raster has %i bands..." % n)
            return
        #
        # Is it a file-based raster?
        source = theLayer.source()
        source = str(source)
        # if this is a windows OS then the filename needs to have
        #  '/' converted to '\'
        if source.find('windows') != 0 or source.find('Windows') != 0:
            source = os.path.normpath(source)
        if not os.path.isfile(source):
            # The raster layer is not a file so that a colour table
            # cannot be created
            QMessageBox.critical(self.iface.mainWindow(),uu.MSG_BOX_TITLE,
                                      "Invalid Layer for table colour!\n"
                                      "The raster layer: %s is not a file "
                                      "and this plugin cannot create a"
                                      "colour table for it!\n"
                                      "Please select a file-based raster "
                                      "layer" % source)
            return
        #
        FilePath = os.path.dirname(source)
        FilenameIn = os.path.basename(source)
        (theFile,theExt) = os.path.splitext(FilenameIn)
        #
        #Here we check for the dummy value, but we first check that the
        # raster has not been already processed
        (lDum, b) = theLayer.noDataValue()
        if not os.access(os.path.join(FilePath,theFile+".bccPAL"), os.F_OK):
            if not b:
                QMessageBox.critical(self.iface.mainWindow(),
                                     uu.MSG_BOX_TITLE,
                                     "Cannot continue\n"
                                     "This raster does not have a "
                                     "'No data value'!\n"
                                     "Please set the no_data_value on "
                                     "this raster and try again.")
                return
        #-----------------------------------------------------------------------
        #
        #--- Now we can show the main window
        dialog = cdlgTBL(self.iface, FilePath, FilenameIn, str(lDum))
        dialog.show()
        #
        # and the default coloured raster
        theTMPLayer, theCanvas, bkExtent = self.DisplayTMPRaster(dialog, source)
        if not theTMPLayer: return
        #
        # then let user do her stuff
        dialog.txtFD.setText("Ready")
        theLayer.showStatusMessage("")
        dialog.bFirst = False
        dialog.exec_()
        #-----------------------------------------------------------------------
        #
        if dialog.OK:
            # User has clicked on 'Close'. We now have to colour the original
            #  raster with the selected colour palette, if any. But, first, we
            #  create a colour scale bar and display it in the legend of the
            #  raster (well that would be the idea, but we cannot do it in
            #  PyQGIS...
            #
            # Retrieve selected info from dialog
            theTBL = dialog.theTBL             # colour table
            nColo  = dialog.nColo              # number of colours
            arColo = dialog.arColo             # colour RGBA
            arV    = dialog.arColV             # data values
            Vmin   = dialog.myGRD.S.vMin       # minimum data value
            #
            # Create a scale bar and stuff it into the raster legend
            colBar = vscbar.scVLgd( nColo, arColo, arV, Vmin )
            myLegendImg = colBar.retrieveIMG()
            ##--> how to set the raster legend to myLegendImg (a Qt QImage) ???
            #
            if theTBL:
                # Display the raster with the selected colour table:
                try:
                    setRasterColourTable(theLayer, theTBL)
                    self.iface.legendInterface().refreshLayerSymbology(
                                                                   theLayer)
                    # - tell QGIS that it needs to ask user to save changes
                    self.iface.mapCanvas().setDirty( True )
                except:
                    pass
        #-----------------------------------------------------------------------
        #
        # Do some clean-up before exiting
        self.CleanUp(theTMPLayer, theCanvas, bkExtent)

    #---------------------------------------------------------------------------
    def DisplayTMPRaster(self, dialog, source):
        """
        Now that the plugin window is displayed we can take the time to display
        the selected raster. In order to do that we load the raster in a new
        layer on the main canvas and colour it with the default colour table
        """
        #
        # Get the current extent of the mapcanvas
        # Zoom to full extent of raster
        theCanvas = self.iface.mapCanvas()
        self.iface.zoomToActiveLayer()
        bkExtent = theCanvas.extent()
        # Load raster now that the plugin window is displayed
        strInfo = "Displaying working raster..."
        dialog.txtFD.setText(strInfo)
        dialog.setRaster(source)
        theTMPLayer = dialog.theLayer          # temporary layer
        # Compute the stats
        strInfo = "Computing statistics..."
        dialog.txtFD.setText(strInfo)
        dialog.pBar.setValue(0)
        if not dialog.computeRasterStats():
            QMessageBox.critical(self.iface.mainWindow(), uu.MSG_BOX_TITLE,
                                 "Cannot continue. Problems!\n")
            self.CleanUp(theTMPLayer, theCanvas, bkExtent)
            return False, False, False
        #
        # And show the effect of the default colour table
        dialog.pBar.setValue(0)                # reset progress bar
        strInfo = "Applying default palette..."
        dialog.txtFD.setText(strInfo)
        dialog.applyTBL()  #can take a very long time due to QGIS stats compute
        # Reset list to NULL (we do not want the default palette here, at least
        #                     at first, user has to create it first)
        dialog.cbCreatedTBL.clear()
        dialog.cbCreatedTBL.addItem("")
        dialog.cbCreatedTBL.setEnabled(False)
        #
        # Display remaining of stats data
        if dialog.theLayer.hasStatistics(1):
            myStats = dialog.theLayer.bandStatistics(1)
            nt = dialog.myGRD.S.nX * dialog.myGRD.S.nY
            dialog.myGRD.S.nDum = nt - myStats.elementCount
            dialog.strSTATSInfo += ("<p>Sum of all values: %.3f<br />"
                                    "Empirical variance of the data: %.3f</p>"
                                    "<p>Number of valid cells: %i<br />"
                                    "Number of dummies: %i</p>"
                                    "<p>Not-A-Value: %s</p>" %
                                    (myStats.sum, myStats.sumOfSquares,
                                     myStats.elementCount,
                                     dialog.myGRD.S.nDum, dialog.myGRD.S.lDum))
            dialog.txtInfo.setText(dialog.strSTATSInfo)
        #
        return theTMPLayer, theCanvas, bkExtent
#===============================================================================