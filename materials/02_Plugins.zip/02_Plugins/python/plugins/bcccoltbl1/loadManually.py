# -*- coding: utf-8 -*-
#
# 1-Band Raster Colour Table (c) BC Consulting 2010
#
#    This file is part of "bcccoltbl"
#
#    bcccoltbl is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    bcccoltbl is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with bcccoltbl.  If not, see <http://www.gnu.org/licenses/>.
#
#===============================================================================
# WARNING: this code is not pythonic at all. I'm in no way a python programmer..
#          corrections are more than welcome if properly explained.
#          (trying to learn by mistakes!)
#===============================================================================
#
#loadManually.py
#    This is a plan-b routine in case the bcccoltbl.xml cannot be read. It loads
#    the original colouring methods and original colour palettes names.
#    This does not mean that the colour palettes are still present on disk...
#===============================================================================
#V1.0.0 - 20 October 2010
#===============================================================================
#
import info as uu
#
def loadManually(self, rstDT = 0):
    """
    Load the colour palettes and colouring methods from
    hardcoded lists....
    """
    #
    ccP=[["002_BR","00001","multi"],
         ["002_BW","00002","grey"],
         ["003_grey","00003","grey"],
         ["004","00004","multi"],
         ["004_jesus_land","00005","multi"],
         ["008","00006","multi"],
         ["008_Bu","00007","oneGR"],
         ["008_BuGy","00008","twoGR"],
         ["008_BuOr","00009","twoGR"],
         ["008_gebco","00010","oneGR"],
         ["008_GRASSstdev","00011","special"],
         ["009_gebco","00012","oneGR"],
         ["010_BrBu","00013","twoGR"],
         ["010_Bu","00014","oneGR"],
         ["010_BuOr","00015","twoGR"],
         ["011_RdYlBu_11b","00016","threeGR"],
         ["012_BrBu","00017","twoGR"],
         ["012_BuDOr","00018","twoGR"],
         ["012_BuDRd","00019","twoGR"],
         ["012_BuOr","00020","twoGR"],
         ["012_Cat","00021","multi"],
         ["014_BuGr","00022","twoGR"],
         ["014_BuOrR","00023","twoGR"],
         ["016_2xRepeat","00024","repeat"],
         ["016_GrMg","00025","twoGR"],
         ["016_noGreen","00026","twoGR"],
         ["016_SRTM","00027","dem"],
         ["018_BuDOr","00028","twoGR"],
         ["018_BuDRd","00032","twoGR"],
         ["020_wysiwig","00035","multi"],
         ["025_StepSeq","00037","multi"],
         ["031_GRASSdm","00041","special"],
         ["032_4xRepeat","00042","repeat"],
         ["032_grey","00080","grey"],
         ["032_haxby","00087","multi"],
         ["036_GMT_wysiwyg","00093","multi"],
         ["064_8xRepeat","00094","repeat"],
         ["068_tv-a","00095","multi"],
         ["073_cd-a","00096","multi"],
         ["073_tv-b","00097","multi"],
         ["074_cd-b","00098","multi"],
         ["076_wiki-1.03","00099","multi"],
         ["085_NDVI_colorscale.small","00100","multi"],
         ["099_gravi","00101","multi"],
         ["121_ndvi","00105","multi"],
         ["128_16xRepeat","00106","repeat"],
         ["135_exponential","00107","grey"],
         ["154_jmn-d50","00108","multi"],
         ["155_globe","00109","dem"],
         ["161_power-0.33","00110","gey"],
         ["166_power-3.00","00111","grey"],
         ["168_neutral","00112","multi"],
         ["173_GMT_globe","00113","dem"],
         ["194_gauss","00114","grey"],
         ["194_power-0.50","00115","grey"],
         ["200_R2Y","00116","twoGR"],
         ["201_power-1.50","00117","grey"],
         ["202_power-2.00","00118","grey"],
         ["206_power-1.25","00119","grey"],
         ["210_power-0.80","00120","grey"],
         ["224_snodraegon","00121","multi"],
         ["225_Elevation","00122","dem"],
         ["245_topo","00123","dem"],
         ["253_Fire-2","00124","twoGR"],
         ["254_grey","00125","grey"],
         ["254_palette_chl_etc","00126","multi"],
         ["254_palette_ndvi","00127","multi"],
         ["254_yarg","00129","grey"],
         ["255_autumn","00131","twoGR"],
         ["255_cool","00132","twoGR"],
         ["255_palette_sst","00136","multi"],
         ["255_palette_zeu","00137","multi"],
         ["268_seis","00138","multi"],
         ["274_GMT_topo","00139","dem"],
         ["275_cw1-013","00140","threeGR"],
         ["275_ocean","00141","dem"],
         ["278_DEM_poster","00142","dem"],
         ["278_Pink-Yellow-Orange-2","00143","threeGR"],
         ["278_springangel","00144","multi"],
         ["287_winter","00145","twoGR"],
         ["288_summer","00146","twoGR"],
         ["290_Yellow-Orange","00147","twoGR"],
         ["294_spring","00148","twoGR"],
         ["298_sealand","00149","dem"],
         ["299_polar","00150","threeGR"],
         ["300_red2green","00151","threeGR"],
         ["300_relief","00152","dem"],
         ["300_split","00153","threeGR"],
         ["302_elev_legend-full","00154","dem"],
         ["303_GMT_seis","00155","multi"],
         ["303_spellbound","00156","multi"],
         ["311_DEM_print","00157","dem"],
         ["315_copper","00158","twoGR"],
         ["323_DEM_screen","00159","dem"],
         ["328_bone","00160","twoGR"],
         ["330_Caribbean","00161","dem"],
         ["331_serendil","00162","dem"],
         ["334_Gummy-Bears","00163","threeGR"],
         ["338_sepia","00164","grey"],
         ["339_byg","00165","threeGR"],
         ["339_byr","00166","threeGR"],
         ["339_elevation","00167","dem"],
         ["339_scoutie","00168","threeGR"],
         ["339_Sunset_Real","00169","multi"],
         ["340_aspect","00170","grey"],
         ["340_bcyr","00171","multi"],
         ["340_bgyr","00172","multi"],
         ["340_colorcube","00173","repeat"],
         ["340_CW_Magenta_Green","00174","multi"],
         ["340_ETOPO1","00175","dem"],
         ["340_GMT_sealand","00176","dem"],
         ["340_Gummy-Kids","00177","multi"],
         ["340_hot","00178","multi"],
         ["340_hsv","00179","multi"],
         ["340_jet","00180","multi"],
         ["340_jmn-c64","00181","multi"],
         ["340_rainbow","00182","multi"],
         ["340_Ribbon-Colors","00183","multi"],
         ["340_ryb","00184","threeGR"],
         ["340_sst","00185","dem"],
         ["340_wave","00186","multi"],
         ["340_zeu","00187","multi"],
         ["341_gyr","00188","threeGR"]]
    #---------------------------------------------------------------------------
    cpc=[["All palettes",       "ALL"     ],
         ["Grey",               "grey"    ],
         ["Multicolour",        "multi"   ],
         ["Gradient 1col",      "oneGR"   ],
         ["Gradient 2col",      "twoGR"   ],
         ["Gradient 3col",      "threeGR" ],
         ["Repeat colours",     "repeat"  ],
         ["Special palettes",   "special" ],
         ["DEM [topo]",         "dem"     ],
         ["HSV colour space",   "HSV"     ]]
    #---------------------------------------------------------------------------
    #
    self.cbColMeth.clear()
    self.cbColMeth.addItems( uu.ccM )
    if rstDT: self.cbColMeth.addItems( uu.ccM1 )
    #
    return [121, ccP, 10, cpc]
