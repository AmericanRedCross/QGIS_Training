# -*- coding: utf-8 -*-
#
# 1-Band Raster Colour Table (c) BC Consulting 2010
#
#    This file is part of "bcccoltbl"
#
#    bcccoltbl is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    bcccoltbl is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with bcccoltbl.  If not, see <http://www.gnu.org/licenses/>.
#
#===============================================================================
# WARNING: this code is not pythonic at all. I'm in no way a python programmer..
#          corrections are more than welcome if properly explained.
#          (trying to learn by mistakes!)
#===============================================================================
#
#utils.py
#  Some objects to hold raster info.
#
#===============================================================================
#V1.0.0 - 20 October 2010
#===============================================================================
#
import os
import numpy as np
#
#===============================================================================
#
class oneBandRaster:
    def __init__(self, layer):
        """
        Object to store a compressed 1-one band raster
        ==================================================
        layer: raster layer object
        w: width of the compressed raster
        h: height of the compressed raster
        ==================================================
        """
        self.S = Stats(layer)

    def getStats(self):
        """
        Return the Stats object
        """
        return self.S

    def __str__(self):
        """
        Provide a way to represent the object as a text
        """
        n=1000
        L = """
layer  = %s\nnX     = %s\nnY     = %s\nnpts   = %s\nlDum   = %s\nnDum   = %s\n
vMin   = %s\nvMax   = %s\nMean   = %s\nSTDev  = %s\nnClass = %s\n\n
Histogram (over %s classes):\n
""" % (str(self.S.layer.source()), str(self.S.nX*self.S.nY),
       str(self.S.npts),
       str(self.S.lDum), str(self.S.nDum),
       str(self.S.vMin), str(self.S.vMax),
       str(self.S.mean), str(self.S.STDev),
       str(self.S.nClass), str(self.S.nClass / n))
        #
        summ = 0
        k = 0
        j = 0
        S = []
        for i in range(self.S.nClass):
            k=k+1
            if k <= n:
                summ += self.S.Histo[i,0]
            else:
                j += 1
                S.append(("0000" + str(j))[-3:] +": ("+ ("         " +
                         str(summ))[-8:] +") :" + ("-" * (summ/100)))
                summ = 0
                k = 1
        #
        if k>0: S.append("0" * summ)
        return "oneBandRaster object:\n"+L+"\n".join(S)+"\n"
#
#===============================================================================
#
class Stats:
    def __init__(self, layer):
        """
        Object to store stats for a 1-one band raster
        ==================================================
        layer: raster layer object
        ==================================================
        """
        self.layer  = layer                          # the raster we are acting on
        self.nX     = -1                             # number of cell in X
        self.nY     = -1                             # number of cell in Y
        self.npts   = -1                             # the number of valid points in the raster
        self.lDum   = ''                             # the not-a-value (dummy) value
        self.nDum   = -1                             # the number of dummies in the raster
        self.vMin   = 1.0e32                         # the minimum Z value in the raster
        self.vMax   = -1.0e32                        # the maximum Z value in the raster
        self.mean   = 0.0                            # the average value
        self.STDev  = 0.0                            # the standard deviation
        self.nClass = 40001                          # the number of classes for histogram
        self.Histo  = np.zeros((self.nClass,2),int)  # the histogram of Z values over 40000 classes
#
#===============================================================================