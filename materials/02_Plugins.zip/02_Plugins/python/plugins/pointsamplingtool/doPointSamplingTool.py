#-----------------------------------------------------------
#
# Point Sampling Tool
#
# A QGIS plugin for collecting polygon attributes and raster values from multiple layers at specified sampling points
#
# Copyright (C) 2008-2011  Borys Jurgiel
# based on Carson Farmer's PointsInPoly plugin, Copyright (C) 2008 Carson Farmer
#
#-----------------------------------------------------------
#
# licensed under the terms of GNU GPL 2
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, print to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
#
#---------------------------------------------------------------------

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from pointSamplingToolUi import Ui_Dialog


class Dialog(QDialog, Ui_Dialog):

 sampItems = {}  # {name1 : [layer1, [field_src,field_dsn,Active?], [field_src,field_dsn,Active?], ...] , name2 : [layer2, ...] }
 polyItems = {}  # {name1 : [layer1, [field_src,field_dsn,Active?], [field_src,field_dsn,Active?], ...] , name2 : [layer2, ...] }
 rastItems = {}  # {name1 : [layer1, [band_name,field_dsn,Active?], [band_name,field_dsn,Active?], ...] , name2 : [layer2, ...] }
 fields = []     # [[type,layer,field],[type,layer,field],[type,layer,field]...] list of adresses of output fields

 def __init__(self, iface):
  QDialog.__init__(self)
  self.iface = iface
  self.setupUi(self)
  QObject.connect(self.outButton, SIGNAL("clicked()"), self.outFile)
  QObject.connect(self.inSample, SIGNAL("currentIndexChanged ( int )"), self.updateFieldsList)
  QObject.connect(self.inData, SIGNAL("itemSelectionChanged()"), self.updateFieldsTable)
  QObject.connect(self.fieldsTable, SIGNAL("cellChanged(int,int)"), self.fieldNameChanged)
  self.addToToc.setCheckState(Qt.Checked)
  mapCanvas = self.iface.mapCanvas()
  # init dictionaries of items:
  self.sampItems = {}
  self.polyItems = {}
  self.rastItems = {}
  for i in range(mapCanvas.layerCount()):
   layer = mapCanvas.layer(i)
   if ( layer.type() == layer.VectorLayer ) and ( layer.geometryType() == QGis.Point ):
    # read point layers
    provider = layer.dataProvider()
    fields = provider.fields()
    theItem = [layer]
    for j in fields.values():
     theItem += [[unicode(j.name()), unicode(j.name()), False]]
    self.sampItems[unicode(layer.name())] = theItem
    self.inSample.addItem(layer.name())
   elif ( layer.type() == layer.VectorLayer ) and ( layer.geometryType() == QGis.Polygon ):
    # read polygon layers
    provider = layer.dataProvider()
    fields = provider.fields()
    theItem = [layer]
    for j in fields.values():
     theItem += [[unicode(j.name()), unicode(j.name()), False]]
    self.polyItems[unicode(layer.name())] = theItem
   elif layer.type() == layer.RasterLayer:
    # read raster layers
    theItem = [layer]
    for j in range(layer.bandCount()):
     if layer.bandCount() == 1:
      name1 = QString(layer.bandName(j+1))
      name2 = QString(layer.name()[:10])
     else:
      name1 = QString(layer.bandName(j+1))
      name2 = QString(layer.name()[:8] + "_" + unicode(j+1))
     theItem += [[name1, name2, False]]
    self.rastItems[unicode(layer.name())] = theItem
  self.updateFieldsList()


 def updateFieldsList(self):
  self.inData.clear()
  if not self.inSample.count(): return
  i = str(self.inSample.currentText())
  for j in range(1, len(self.sampItems[i])):
    #clear previously enabled fields (as they aren't selected in the widget)
    self.sampItems[i][j][2] = False
    self.inData.addItem(str(self.sampItems[i][0].name()) + " : " + str(self.sampItems[i][j][0]) + " (source point)")
#NOT YET FINISHED - to be switched to tree rather
#  self.inData.addItem(str(self.sampItems[i][0].name()) + " (X coordinate)")
#  self.inData.addItem(str(self.sampItems[i][0].name()) + " (Y coordinate)")

  for i in self.polyItems:
   for j in range(1, len(self.polyItems[i])):
    self.inData.addItem(unicode(self.polyItems[i][0].name()) + " : " + unicode(self.polyItems[i][j][0]) + " (polygon)")
  for i in self.rastItems:
   for j in range(1, len(self.rastItems[i])):
    self.inData.addItem(unicode(self.rastItems[i][0].name()) + " : "+ unicode(self.rastItems[i][j][0]) + " (raster)")
  self.updateFieldsTable()
  self.repaint()




 def updateFieldsTable(self): # called after selection changing
  # mark selected point items
  n=0
  i = str(self.inSample.currentText())
  for j in range(1, len(self.sampItems[i])):
    if self.inData.isItemSelected(self.inData.item(n)):
      self.sampItems[i][j][2] = True
    else:
      self.sampItems[i][j][2] = False
    n += 1
  # mark selected polygon items
  for i in self.polyItems:
   for j in range(1, len(self.polyItems[i])):
    if self.inData.isItemSelected(self.inData.item(n)):
     self.polyItems[i][j][2] = True
    else:
     self.polyItems[i][j][2] = False
    n += 1
  # mark selected raster items (don't zero n; it's one list)
  for i in self.rastItems:
   for j in range(1, len(self.rastItems[i])):
    if self.inData.isItemSelected(self.inData.item(n)):
     self.rastItems[i][j][2] = True
    else:
     self.rastItems[i][j][2] = False
    n += 1
  # fill the fieldsTable with point, then polygon and then raster items:
  self.fields = []
  n = 0
  self.fieldsTable.setRowCount(0)
  i = str(self.inSample.currentText())
  for j in range(1, len(self.sampItems[i])):
   if self.sampItems[i][j][2]:
    self.fields += [["point",i,j]]
    self.fieldsTable.setRowCount(n+1)
    cell = QTableWidgetItem(unicode(self.sampItems[i][0].name()) + " : " + unicode(self.sampItems[i][j][0]))
    cell.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
    self.fieldsTable.setItem(n,0,cell)
    self.fieldsTable.setItem(n,1,QTableWidgetItem(unicode(self.sampItems[i][j][1])))
    n += 1
  for i in self.polyItems:
   for j in range(1, len(self.polyItems[i])):
    if self.polyItems[i][j][2]:
     self.fields += [["poly",i,j]]
     self.fieldsTable.setRowCount(n+1)
     cell = QTableWidgetItem(unicode(self.polyItems[i][0].name()) + " : " + unicode(self.polyItems[i][j][0]))
     cell.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
     self.fieldsTable.setItem(n,0,cell)
     self.fieldsTable.setItem(n,1,QTableWidgetItem(unicode(self.polyItems[i][j][1])))
     n += 1
  for i in self.rastItems:
   for j in range(1, len(self.rastItems[i])):
    if self.rastItems[i][j][2]:
     self.fields += [["rast",i,j]]
     self.fieldsTable.setRowCount(n+1)
     cell = QTableWidgetItem(unicode(self.rastItems[i][0].name()) + " : " + unicode(self.rastItems[i][j][0]))
     cell.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
     self.fieldsTable.setItem(n,0,cell)
     self.fieldsTable.setItem(n,1,QTableWidgetItem(unicode(self.rastItems[i][j][1])))
     n += 1
  self.fieldsTable.resizeColumnsToContents()



 def fieldNameChanged(self, n): # called when any cell of the fieldsTable was modyfied
  # exit when false alarm
  if len(self.fields) == 0: return 0
  if self.fieldsTable.rowCount() == 0: return 0
  updatedItem = self.fieldsTable.item(n,1)
  if updatedItem == None: return 0
  # update items dictionaries
  updatedText = unicode(updatedItem.text())
  if self.fields[n][0] == "point":
   self.sampItems[self.fields[n][1]][self.fields[n][2]][1] = updatedText[:10]
  elif self.fields[n][0] == "poly":
   self.polyItems[self.fields[n][1]][self.fields[n][2]][1] = updatedText[:10]
  else:
   self.rastItems[self.fields[n][1]][self.fields[n][2]][1] = updatedText[:10]
  # cut to 10 characters if exceed
  if len(updatedText) > 10:
   self.updateFieldsTable()
   QMessageBox.information(self, "Point Sampling Tool", "Name length can't exceed 10 chars, so it has been truncated.")
   # This message box may to make some confusion, if user press OK while "too long name" is still under edition.
   # In this case, the message box pops up (correctly) and then the OK button becomes pressed, but the self.accept method is not called.
   # This pressed button with no action may to look like a hang up.
   # I've no idea either
   #  how to pull this button up, or
   #  how to forse execution the self.accept method, or
   #  how to don't allow user to exceed 10 chars limit in QTableWidget cell. (THIS OPTION WOULD BE THE BEST!)
  self.fieldsTable.resizeColumnsToContents()



 def outFile(self): # by Carson Farmer 2008
  # display file dialog for output shapefile
  self.outShape.clear()
  fileDialog = QFileDialog()
  fileDialog.setConfirmOverwrite(False)
  outName = fileDialog.getSaveFileName(self, "Output Shapefile",".", "Shapefiles (*.shp)")
  outPath = QFileInfo(outName).absoluteFilePath()
  if outPath.right(4) != ".shp":
   outPath = outPath + ".shp"
  if not outName.isEmpty():
   self.outShape.clear()
   self.outShape.insert(outPath)



 def accept(self): # Called when "OK" button pressed (based on the Carson Farmer's PointsInPoly Plugin, 2008)
  # check if all fields are filled up
  self.statusLabel.setText("Check input values, please!")
  nothingSelected = True
  for i in self.polyItems:
   for j in range(1, len(self.polyItems[i])):
    if self.polyItems[i][j][2]:
     nothingSelected = False
  for i in self.rastItems:
   for j in range(1, len(self.rastItems[i])):
    if self.rastItems[i][j][2]:
     nothingSelected = False
  if self.inSample.currentText() == "":
   self.tabWidget.setCurrentIndex(0)
   QMessageBox.information(self, "Point Sampling Tool", "Please select vector layer containing the sampling points")
  elif nothingSelected:
   self.tabWidget.setCurrentIndex(0)
   QMessageBox.information(self, "Point Sampling Tool", "Please select at least one polygon or raster layer")
  elif self.outShape.text() == "":
   self.tabWidget.setCurrentIndex(0)
   QMessageBox.information(self, "Point Sampling Tool", "Please specify output shapefile name")
  # check if destination field names are unique
  elif not self.testFieldsNames(self.fields):
   self.updateFieldsTable()
   self.tabWidget.setCurrentIndex(1)
   QMessageBox.warning(self, "Point Sampling Tool", "At least two field names are the same!\nPlease type unique names.")
  else:
   # all tests passed! Let's go on
   self.statusLabel.setText("Processing the output file name...")
   self.repaint()
   outPath = self.outShape.text()
   if outPath.contains("\\"):
    outName = outPath.right((outPath.length() - outPath.lastIndexOf("\\")) - 1)
   else:
    outName = outPath.right((outPath.length() - outPath.lastIndexOf("/")) - 1)
   if outName.endsWith(".shp"):
    outName = outName.left(outName.length() - 4)
   else:
    outPath = outPath + ".shp" # When only layer name is given, create it in current folder instead of in individual folders.
   oldFile = QFile(outPath)
   if oldFile.exists():
    QMessageBox.warning(self, "Point Sampling Tool", "Cannot overwrite existing shapefile.")
    # return to filling the input fields
    self.outShape.clear()
    self.statusLabel.setText("Fill up the input fields, please.")
    self.repaint()
   else:
    self.statusLabel.setText("Processing...")
    self.repaint()
    # execute main function
    self.sampling(outPath)
    self.outShape.clear()
    # add to the TOC if desired and possible ;)
    if self.addToToc.checkState() == Qt.Checked:
     self.vlayer = QgsVectorLayer(outPath, unicode(outName), "ogr")
     if self.vlayer.isValid():
      QgsMapLayerRegistry.instance().addMapLayer(self.vlayer)
      self.statusLabel.setText("OK. The new layer has been added to the TOC.")
     else:
      self.statusLabel.setText("Error loading the created layer")
      QMessageBox.warning(self, "Point Sampling Tool", "The new layer seems to be created, but is invalid.\nIt won't be loaded.")



 def sampling(self, outPath): # main process
  # open sampling points layer
  pointLayer = self.sampItems[unicode(self.inSample.currentText())][0]
  pointProvider = pointLayer.dataProvider()
  allAttrs = pointProvider.attributeIndexes()
  pointProvider.select(allAttrs)
  sRs = pointProvider.crs()
  # create destination layer: first create list of selected fields
  fieldList = {}
  for i in range(len(self.fields)):
    if self.fields[i][0] == "point": #copying fields from source layer
      field = pointProvider.fields()[pointProvider.fieldNameIndex(self.sampItems[self.fields[i][1]][self.fields[i][2]][0])]
      field.setName(self.sampItems[self.fields[i][1]][self.fields[i][2]][1])
    elif self.fields[i][0] == "poly": #copying fields from polygon layers
      polyLayer = self.polyItems[self.fields[i][1]][0]
      polyProvider = polyLayer.dataProvider()
      field = polyProvider.fields()[polyProvider.fieldNameIndex(self.polyItems[self.fields[i][1]][self.fields[i][2]][0])]
      field.setName(self.polyItems[self.fields[i][1]][self.fields[i][2]][1])
    else: #creating fields for raster layers
      field = QgsField(self.rastItems[self.fields[i][1]][self.fields[i][2]][1], QVariant.Double, "real", 20, 5, "")
      ##### Better data type fit will be implemented in next versions
    fieldList[i] = field
  # create destination layer
  writer = QgsVectorFileWriter(outPath, "UTF-8", fieldList, pointProvider.geometryType(), sRs)
  self.statusLabel.setText("Writing data to the new layer...")
  self.repaint()
  # process point after point...
  pointFeat = QgsFeature()
  np = 0
  snp = pointProvider.featureCount()
  while pointProvider.nextFeature(pointFeat):
   np += 1
   pointGeom = pointFeat.geometry()
   outFeat = QgsFeature()
   outFeat.setGeometry(pointGeom)
   # ...and inside: field after field
   for i in range(len(self.fields)):
    self.statusLabel.setText("Processing point %s of %s, field %s of %s" % (np, snp, i+1, len(self.fields)))
    self.repaint()
    field = self.fields[i]
    if field[0] == "point":
       attr = pointFeat.attributeMap()[pointProvider.fieldNameIndex(self.sampItems[field[1]][field[2]][0])]
       outFeat.addAttribute(i, QVariant(attr))
    elif field[0] == "poly":
     polyLayer = self.polyItems[field[1]][0]
     polyProvider = polyLayer.dataProvider()
     polyProvider.select(polyProvider.attributeIndexes())
     polyFeat = QgsFeature()
     while polyProvider.nextFeature(polyFeat):
      if pointFeat.geometry().intersects(polyFeat.geometry()):
       attr = polyFeat.attributeMap()[polyProvider.fieldNameIndex(self.polyItems[field[1]][field[2]][0])]
       outFeat.addAttribute(i, QVariant(attr))
    else: # field source is raster
     rastLayer = self.rastItems[field[1]][0]
     if pointFeat.geometry().wkbType() == QGis.WKBMultiPoint:
      point = pointFeat.geometry().asMultiPoint()[0]
     else:
      point = pointFeat.geometry().asPoint()
     ident = rastLayer.identify(point)[1]
#     #nr = rastLayer.bandNumber(self.rastItems[field[1]][field[2]][0])
     try:
#      #attr = float(ident.values()[nr-1])
      attr = float(ident[self.rastItems[field[1]][field[2]][0]]) ##### !! float() - I HAVE TO IMPLEMENT RASTER TYPE HANDLING!!!!
      outFeat.addAttribute(i,QVariant(attr))
     except: # point is out of raster extent
      pass
   writer.addFeature(outFeat)
  del writer
  self.statusLabel.setText("The new layer has been created.")



 def testFieldsNames(self, fields): #tests uniquity of field names
  ok = True
  if len(fields) > 1:
   for field1 in fields:
    for field2 in fields:
     if field1[0] == "point": name1 = self.sampItems[field1[1]][field1[2]][1]
     elif field1[0] == "poly": name1 = self.polyItems[field1[1]][field1[2]][1]
     else: name1 = self.rastItems[field1[1]][field1[2]][1]
     if field2[0] == "point": name2 = self.sampItems[field2[1]][field2[2]][1]
     elif field2[0] == "poly": name2 = self.polyItems[field2[1]][field2[2]][1]
     else: name2 = self.rastItems[field2[1]][field2[2]][1]
     if (name1 == name2) and (field1 != field2):
      ok = False
  return ok

