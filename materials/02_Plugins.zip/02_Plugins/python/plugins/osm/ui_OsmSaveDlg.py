# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'D:/src/qgis-1.7.3/python/plugins/osm/ui_files/OsmSaveDlg.ui'
#
# Created: Sun Dec 11 11:35:43 2011
#      by: PyQt4 UI code generator 4.8.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_OsmSaveDlg(object):
    def setupUi(self, OsmSaveDlg):
        OsmSaveDlg.setObjectName(_fromUtf8("OsmSaveDlg"))
        OsmSaveDlg.setWindowModality(QtCore.Qt.ApplicationModal)
        OsmSaveDlg.resize(370, 206)
        OsmSaveDlg.setToolTip(_fromUtf8(""))
        OsmSaveDlg.setWhatsThis(_fromUtf8(""))
        OsmSaveDlg.setModal(True)
        self.vboxlayout = QtGui.QVBoxLayout(OsmSaveDlg)
        self.vboxlayout.setObjectName(_fromUtf8("vboxlayout"))
        self.gridlayout = QtGui.QGridLayout()
        self.gridlayout.setObjectName(_fromUtf8("gridlayout"))
        self.label = QtGui.QLabel(OsmSaveDlg)
        self.label.setIndent(-1)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridlayout.addWidget(self.label, 0, 0, 1, 2)
        self.OSMFileEdit = QtGui.QLineEdit(OsmSaveDlg)
        self.OSMFileEdit.setObjectName(_fromUtf8("OSMFileEdit"))
        self.gridlayout.addWidget(self.OSMFileEdit, 1, 0, 1, 1)
        self.browseOSMButton = QtGui.QPushButton(OsmSaveDlg)
        self.browseOSMButton.setMaximumSize(QtCore.QSize(50, 16777215))
        self.browseOSMButton.setObjectName(_fromUtf8("browseOSMButton"))
        self.gridlayout.addWidget(self.browseOSMButton, 1, 1, 1, 1)
        self.vboxlayout.addLayout(self.gridlayout)
        self.label_2 = QtGui.QLabel(OsmSaveDlg)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.vboxlayout.addWidget(self.label_2)
        self.hboxlayout = QtGui.QHBoxLayout()
        self.hboxlayout.setContentsMargins(15, -1, 0, 10)
        self.hboxlayout.setObjectName(_fromUtf8("hboxlayout"))
        self.vboxlayout1 = QtGui.QVBoxLayout()
        self.vboxlayout1.setObjectName(_fromUtf8("vboxlayout1"))
        self.chkPoints = QtGui.QCheckBox(OsmSaveDlg)
        self.chkPoints.setChecked(True)
        self.chkPoints.setObjectName(_fromUtf8("chkPoints"))
        self.vboxlayout1.addWidget(self.chkPoints)
        self.chkLines = QtGui.QCheckBox(OsmSaveDlg)
        self.chkLines.setChecked(True)
        self.chkLines.setObjectName(_fromUtf8("chkLines"))
        self.vboxlayout1.addWidget(self.chkLines)
        self.chkPolygons = QtGui.QCheckBox(OsmSaveDlg)
        self.chkPolygons.setChecked(True)
        self.chkPolygons.setObjectName(_fromUtf8("chkPolygons"))
        self.vboxlayout1.addWidget(self.chkPolygons)
        self.hboxlayout.addLayout(self.vboxlayout1)
        self.vboxlayout2 = QtGui.QVBoxLayout()
        self.vboxlayout2.setObjectName(_fromUtf8("vboxlayout2"))
        self.chkRelations = QtGui.QCheckBox(OsmSaveDlg)
        self.chkRelations.setChecked(True)
        self.chkRelations.setObjectName(_fromUtf8("chkRelations"))
        self.vboxlayout2.addWidget(self.chkRelations)
        self.chkTags = QtGui.QCheckBox(OsmSaveDlg)
        self.chkTags.setChecked(True)
        self.chkTags.setObjectName(_fromUtf8("chkTags"))
        self.vboxlayout2.addWidget(self.chkTags)
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.vboxlayout2.addItem(spacerItem)
        self.hboxlayout.addLayout(self.vboxlayout2)
        spacerItem1 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.hboxlayout.addItem(spacerItem1)
        self.vboxlayout3 = QtGui.QVBoxLayout()
        self.vboxlayout3.setObjectName(_fromUtf8("vboxlayout3"))
        spacerItem2 = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.vboxlayout3.addItem(spacerItem2)
        self.buttonBox = QtGui.QDialogButtonBox(OsmSaveDlg)
        self.buttonBox.setMaximumSize(QtCore.QSize(110, 16777215))
        self.buttonBox.setBaseSize(QtCore.QSize(110, 0))
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.NoButton|QtGui.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName(_fromUtf8("buttonBox"))
        self.vboxlayout3.addWidget(self.buttonBox)
        self.hboxlayout.addLayout(self.vboxlayout3)
        self.vboxlayout.addLayout(self.hboxlayout)

        self.retranslateUi(OsmSaveDlg)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("rejected()")), OsmSaveDlg.reject)
        QtCore.QMetaObject.connectSlotsByName(OsmSaveDlg)
        OsmSaveDlg.setTabOrder(self.OSMFileEdit, self.browseOSMButton)

    def retranslateUi(self, OsmSaveDlg):
        OsmSaveDlg.setWindowTitle(QtGui.QApplication.translate("OsmSaveDlg", "Save OSM", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("OsmSaveDlg", "Where to save:", None, QtGui.QApplication.UnicodeUTF8))
        self.browseOSMButton.setText(QtGui.QApplication.translate("OsmSaveDlg", "...", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("OsmSaveDlg", "Features to save:", None, QtGui.QApplication.UnicodeUTF8))
        self.chkPoints.setText(QtGui.QApplication.translate("OsmSaveDlg", "Points", None, QtGui.QApplication.UnicodeUTF8))
        self.chkLines.setText(QtGui.QApplication.translate("OsmSaveDlg", "Lines", None, QtGui.QApplication.UnicodeUTF8))
        self.chkPolygons.setText(QtGui.QApplication.translate("OsmSaveDlg", "Polygons", None, QtGui.QApplication.UnicodeUTF8))
        self.chkRelations.setText(QtGui.QApplication.translate("OsmSaveDlg", "Relations", None, QtGui.QApplication.UnicodeUTF8))
        self.chkTags.setText(QtGui.QApplication.translate("OsmSaveDlg", "Tags", None, QtGui.QApplication.UnicodeUTF8))

