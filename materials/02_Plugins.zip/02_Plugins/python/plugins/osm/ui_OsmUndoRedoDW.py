# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'D:/src/qgis-1.7.3/python/plugins/osm/ui_files/OsmUndoRedoDW.ui'
#
# Created: Sun Dec 11 11:35:42 2011
#      by: PyQt4 UI code generator 4.8.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_OsmUndoRedoDW(object):
    def setupUi(self, OsmUndoRedoDW):
        OsmUndoRedoDW.setObjectName(_fromUtf8("OsmUndoRedoDW"))
        OsmUndoRedoDW.resize(227, 374)
        OsmUndoRedoDW.setAllowedAreas(QtCore.Qt.AllDockWidgetAreas)
        self.dockWidgetContents = QtGui.QWidget()
        self.dockWidgetContents.setObjectName(_fromUtf8("dockWidgetContents"))
        self.vboxlayout = QtGui.QVBoxLayout(self.dockWidgetContents)
        self.vboxlayout.setObjectName(_fromUtf8("vboxlayout"))
        self.hboxlayout = QtGui.QHBoxLayout()
        self.hboxlayout.setObjectName(_fromUtf8("hboxlayout"))
        self.clearButton = QtGui.QToolButton(self.dockWidgetContents)
        self.clearButton.setObjectName(_fromUtf8("clearButton"))
        self.hboxlayout.addWidget(self.clearButton)
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.hboxlayout.addItem(spacerItem)
        self.undoButton = QtGui.QToolButton(self.dockWidgetContents)
        self.undoButton.setEnabled(False)
        self.undoButton.setObjectName(_fromUtf8("undoButton"))
        self.hboxlayout.addWidget(self.undoButton)
        self.redoButton = QtGui.QToolButton(self.dockWidgetContents)
        self.redoButton.setEnabled(False)
        self.redoButton.setObjectName(_fromUtf8("redoButton"))
        self.hboxlayout.addWidget(self.redoButton)
        self.vboxlayout.addLayout(self.hboxlayout)
        self.actionList = QtGui.QListWidget(self.dockWidgetContents)
        self.actionList.setObjectName(_fromUtf8("actionList"))
        self.vboxlayout.addWidget(self.actionList)
        OsmUndoRedoDW.setWidget(self.dockWidgetContents)

        self.retranslateUi(OsmUndoRedoDW)
        QtCore.QMetaObject.connectSlotsByName(OsmUndoRedoDW)

    def retranslateUi(self, OsmUndoRedoDW):
        OsmUndoRedoDW.setWindowTitle(QtGui.QApplication.translate("OsmUndoRedoDW", "OSM Edit History", None, QtGui.QApplication.UnicodeUTF8))
        self.clearButton.setToolTip(QtGui.QApplication.translate("OsmUndoRedoDW", "Clear all", None, QtGui.QApplication.UnicodeUTF8))
        self.clearButton.setStatusTip(QtGui.QApplication.translate("OsmUndoRedoDW", "Clear all", None, QtGui.QApplication.UnicodeUTF8))
        self.clearButton.setWhatsThis(QtGui.QApplication.translate("OsmUndoRedoDW", "Clear all", None, QtGui.QApplication.UnicodeUTF8))
        self.clearButton.setText(QtGui.QApplication.translate("OsmUndoRedoDW", "...", None, QtGui.QApplication.UnicodeUTF8))
        self.undoButton.setToolTip(QtGui.QApplication.translate("OsmUndoRedoDW", "Undo", None, QtGui.QApplication.UnicodeUTF8))
        self.undoButton.setStatusTip(QtGui.QApplication.translate("OsmUndoRedoDW", "Undo", None, QtGui.QApplication.UnicodeUTF8))
        self.undoButton.setWhatsThis(QtGui.QApplication.translate("OsmUndoRedoDW", "Undo", None, QtGui.QApplication.UnicodeUTF8))
        self.undoButton.setText(QtGui.QApplication.translate("OsmUndoRedoDW", "...", None, QtGui.QApplication.UnicodeUTF8))
        self.redoButton.setToolTip(QtGui.QApplication.translate("OsmUndoRedoDW", "Redo", None, QtGui.QApplication.UnicodeUTF8))
        self.redoButton.setStatusTip(QtGui.QApplication.translate("OsmUndoRedoDW", "Redo", None, QtGui.QApplication.UnicodeUTF8))
        self.redoButton.setWhatsThis(QtGui.QApplication.translate("OsmUndoRedoDW", "Redo", None, QtGui.QApplication.UnicodeUTF8))
        self.redoButton.setText(QtGui.QApplication.translate("OsmUndoRedoDW", "...", None, QtGui.QApplication.UnicodeUTF8))

