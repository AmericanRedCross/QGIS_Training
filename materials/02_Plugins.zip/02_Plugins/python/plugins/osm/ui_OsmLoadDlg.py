# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'D:/src/qgis-1.7.3/python/plugins/osm/ui_files/OsmLoadDlg.ui'
#
# Created: Sun Dec 11 11:35:43 2011
#      by: PyQt4 UI code generator 4.8.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_OsmLoadDlg(object):
    def setupUi(self, OsmLoadDlg):
        OsmLoadDlg.setObjectName(_fromUtf8("OsmLoadDlg"))
        OsmLoadDlg.setWindowModality(QtCore.Qt.ApplicationModal)
        OsmLoadDlg.resize(508, 309)
        OsmLoadDlg.setToolTip(_fromUtf8(""))
        OsmLoadDlg.setWhatsThis(_fromUtf8(""))
        OsmLoadDlg.setModal(True)
        self.gridlayout = QtGui.QGridLayout(OsmLoadDlg)
        self.gridlayout.setObjectName(_fromUtf8("gridlayout"))
        self.gridlayout1 = QtGui.QGridLayout()
        self.gridlayout1.setObjectName(_fromUtf8("gridlayout1"))
        self.label = QtGui.QLabel(OsmLoadDlg)
        self.label.setIndent(-1)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridlayout1.addWidget(self.label, 0, 0, 1, 2)
        self.OSMFileEdit = QtGui.QLineEdit(OsmLoadDlg)
        self.OSMFileEdit.setObjectName(_fromUtf8("OSMFileEdit"))
        self.gridlayout1.addWidget(self.OSMFileEdit, 1, 0, 1, 1)
        self.browseOSMButton = QtGui.QPushButton(OsmLoadDlg)
        self.browseOSMButton.setObjectName(_fromUtf8("browseOSMButton"))
        self.gridlayout1.addWidget(self.browseOSMButton, 1, 1, 1, 1)
        self.gridlayout.addLayout(self.gridlayout1, 0, 0, 1, 2)
        self.label_2 = QtGui.QLabel(OsmLoadDlg)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridlayout.addWidget(self.label_2, 1, 0, 1, 1)
        self.hboxlayout = QtGui.QHBoxLayout()
        self.hboxlayout.setObjectName(_fromUtf8("hboxlayout"))
        self.lstTags = QtGui.QListWidget(OsmLoadDlg)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.lstTags.sizePolicy().hasHeightForWidth())
        self.lstTags.setSizePolicy(sizePolicy)
        self.lstTags.setObjectName(_fromUtf8("lstTags"))
        self.hboxlayout.addWidget(self.lstTags)
        self.gridlayout.addLayout(self.hboxlayout, 2, 0, 1, 2)
        self.hboxlayout1 = QtGui.QHBoxLayout()
        self.hboxlayout1.setObjectName(_fromUtf8("hboxlayout1"))
        self.chkCustomRenderer = QtGui.QCheckBox(OsmLoadDlg)
        self.chkCustomRenderer.setChecked(True)
        self.chkCustomRenderer.setObjectName(_fromUtf8("chkCustomRenderer"))
        self.hboxlayout1.addWidget(self.chkCustomRenderer)
        self.styleCombo = QtGui.QComboBox(OsmLoadDlg)
        self.styleCombo.setMinimumSize(QtCore.QSize(182, 0))
        self.styleCombo.setMaximumSize(QtCore.QSize(182, 16777215))
        self.styleCombo.setObjectName(_fromUtf8("styleCombo"))
        self.hboxlayout1.addWidget(self.styleCombo)
        self.gridlayout.addLayout(self.hboxlayout1, 4, 0, 1, 1)
        self.buttonBox = QtGui.QDialogButtonBox(OsmLoadDlg)
        self.buttonBox.setMaximumSize(QtCore.QSize(110, 16777215))
        self.buttonBox.setBaseSize(QtCore.QSize(110, 0))
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.NoButton|QtGui.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName(_fromUtf8("buttonBox"))
        self.gridlayout.addWidget(self.buttonBox, 4, 1, 1, 1)
        self.chkReplaceData = QtGui.QCheckBox(OsmLoadDlg)
        self.chkReplaceData.setChecked(False)
        self.chkReplaceData.setObjectName(_fromUtf8("chkReplaceData"))
        self.gridlayout.addWidget(self.chkReplaceData, 3, 0, 1, 1)

        self.retranslateUi(OsmLoadDlg)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("rejected()")), OsmLoadDlg.reject)
        QtCore.QMetaObject.connectSlotsByName(OsmLoadDlg)
        OsmLoadDlg.setTabOrder(self.OSMFileEdit, self.browseOSMButton)
        OsmLoadDlg.setTabOrder(self.browseOSMButton, self.lstTags)
        OsmLoadDlg.setTabOrder(self.lstTags, self.chkCustomRenderer)
        OsmLoadDlg.setTabOrder(self.chkCustomRenderer, self.buttonBox)

    def retranslateUi(self, OsmLoadDlg):
        OsmLoadDlg.setWindowTitle(QtGui.QApplication.translate("OsmLoadDlg", "Load OSM", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("OsmLoadDlg", "OpenStreetMap file to load:", None, QtGui.QApplication.UnicodeUTF8))
        self.browseOSMButton.setText(QtGui.QApplication.translate("OsmLoadDlg", "...", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("OsmLoadDlg", "Add columns for tags:", None, QtGui.QApplication.UnicodeUTF8))
        self.chkCustomRenderer.setText(QtGui.QApplication.translate("OsmLoadDlg", "Use custom renderer", None, QtGui.QApplication.UnicodeUTF8))
        self.chkReplaceData.setText(QtGui.QApplication.translate("OsmLoadDlg", "Replace current data (current layers will be removed)", None, QtGui.QApplication.UnicodeUTF8))

