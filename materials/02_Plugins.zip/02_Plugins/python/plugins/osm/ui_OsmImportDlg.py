# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'D:/src/qgis-1.7.3/python/plugins/osm/ui_files/OsmImportDlg.ui'
#
# Created: Sun Dec 11 11:35:44 2011
#      by: PyQt4 UI code generator 4.8.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_OsmImportDlg(object):
    def setupUi(self, OsmImportDlg):
        OsmImportDlg.setObjectName(_fromUtf8("OsmImportDlg"))
        OsmImportDlg.setWindowModality(QtCore.Qt.ApplicationModal)
        OsmImportDlg.resize(248, 228)
        OsmImportDlg.setModal(True)
        self.vboxlayout = QtGui.QVBoxLayout(OsmImportDlg)
        self.vboxlayout.setObjectName(_fromUtf8("vboxlayout"))
        self.label = QtGui.QLabel(OsmImportDlg)
        self.label.setWordWrap(True)
        self.label.setObjectName(_fromUtf8("label"))
        self.vboxlayout.addWidget(self.label)
        spacerItem = QtGui.QSpacerItem(20, 29, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.vboxlayout.addItem(spacerItem)
        self.hboxlayout = QtGui.QHBoxLayout()
        self.hboxlayout.setObjectName(_fromUtf8("hboxlayout"))
        self.label_2 = QtGui.QLabel(OsmImportDlg)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.hboxlayout.addWidget(self.label_2)
        self.cboLayer = QtGui.QComboBox(OsmImportDlg)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.cboLayer.sizePolicy().hasHeightForWidth())
        self.cboLayer.setSizePolicy(sizePolicy)
        self.cboLayer.setObjectName(_fromUtf8("cboLayer"))
        self.hboxlayout.addWidget(self.cboLayer)
        self.vboxlayout.addLayout(self.hboxlayout)
        self.chkOnlySelection = QtGui.QCheckBox(OsmImportDlg)
        self.chkOnlySelection.setObjectName(_fromUtf8("chkOnlySelection"))
        self.vboxlayout.addWidget(self.chkOnlySelection)
        spacerItem1 = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.vboxlayout.addItem(spacerItem1)
        self.buttonBox = QtGui.QDialogButtonBox(OsmImportDlg)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.NoButton|QtGui.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName(_fromUtf8("buttonBox"))
        self.vboxlayout.addWidget(self.buttonBox)

        self.retranslateUi(OsmImportDlg)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("rejected()")), OsmImportDlg.reject)
        QtCore.QMetaObject.connectSlotsByName(OsmImportDlg)
        OsmImportDlg.setTabOrder(self.cboLayer, self.chkOnlySelection)
        OsmImportDlg.setTabOrder(self.chkOnlySelection, self.buttonBox)

    def retranslateUi(self, OsmImportDlg):
        OsmImportDlg.setWindowTitle(QtGui.QApplication.translate("OsmImportDlg", "Import data to OSM", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("OsmImportDlg", "In this dialog you can import a layer loaded in QGIS into active OSM data.", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("OsmImportDlg", "Layer", None, QtGui.QApplication.UnicodeUTF8))
        self.chkOnlySelection.setText(QtGui.QApplication.translate("OsmImportDlg", "Import only current selection", None, QtGui.QApplication.UnicodeUTF8))

