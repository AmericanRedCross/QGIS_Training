from easyprint import EasyPrint
from PyQt4.QtCore import *
import os

def name(): 
    return "EasyPrint" 

def description():
    return QCoreApplication.translate("init","Create printable maps.")

def version(): 
    return "Version 0.2.0" 

def qgisMinimumVersion():
    return "1.7"
    
def icon():
	return "easyprint.png"    

def classFactory(iface): 
    return EasyPrint(iface)


