<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr">
<context>
    <name>EasyPrint</name>
    <message>
        <location filename="Ui_easyprint.py" line="140"/>
        <source>Easy Print</source>
        <translation type="obsolete">Easy Print</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="403"/>
        <source>Scale: </source>
        <translation>Echelle :</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="372"/>
        <source>Paper size: </source>
        <translation>Taille de page :</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="373"/>
        <source>Layout: </source>
        <translation>Mise en page: </translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="401"/>
        <source>Title: </source>
        <translation>Titre: </translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="402"/>
        <source>Subtitle: </source>
        <translation>Sous-titre: </translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="376"/>
        <source>Person: </source>
        <translation>Auteur :</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="147"/>
        <source>Grid</source>
        <translation type="obsolete">Grille</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="148"/>
        <source>Legend</source>
        <translation type="obsolete">Légende</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="149"/>
        <source>Copyright</source>
        <translation type="obsolete">Copyright</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="371"/>
        <source>User defined scale: </source>
        <translation>Choix de l&apos;échelle :</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="151"/>
        <source>Cutting lines</source>
        <translation type="obsolete">Lignes de coupe</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="152"/>
        <source>Folding marks</source>
        <translation type="obsolete">Marques de pliure</translation>
    </message>
    <message>
        <location filename="easyprint.py" line="105"/>
        <source>user defined</source>
        <translation>personnalisé</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="368"/>
        <source>EasyPrint</source>
        <translation></translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="399"/>
        <source>Map </source>
        <translation>Carte </translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="377"/>
        <source>Legend: </source>
        <translation>Légende :</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="378"/>
        <source>Copyright: </source>
        <translation>Copyright :</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="379"/>
        <source>Grid: </source>
        <translation>Grille :</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="380"/>
        <source>Cutting lines: </source>
        <translation>Lignes de coupe :</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="381"/>
        <source>Folding marks: </source>
        <translation>Marques de pliage :</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="382"/>
        <source>SimpleMap</source>
        <translation>Carte simple</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="383"/>
        <source>Grid </source>
        <translation>Grille</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="384"/>
        <source>Grid type: </source>
        <translation>Type de Grille :</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="400"/>
        <source>Map layer: </source>
        <translation>Couche de la carte :</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="386"/>
        <source>Overlap percentage: </source>
        <translation>Pourcentage de recouvrement :</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="409"/>
        <source> %</source>
        <translation></translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="388"/>
        <source>Create</source>
        <translation>Créé</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="405"/>
        <source>Parameter </source>
        <translation>Paramètre </translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="413"/>
        <source>Overview map: </source>
        <translation>Carte pour aperçu :</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="391"/>
        <source>Adjacent tile indicator: </source>
        <translation>Indicateur de tuiles adjacentes :</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="412"/>
        <source>Print as raster: </source>
        <translation>Imprimer en format image :</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="414"/>
        <source>Export </source>
        <translation></translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="415"/>
        <source>Export to: </source>
        <translation>Exporter vers :</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="416"/>
        <source>Browse</source>
        <translation>Afficher</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="398"/>
        <source>Mapbook by grid</source>
        <translation>Catalogue de carte par grille</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="404"/>
        <source>Rotation: </source>
        <translation>Rotation :</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="406"/>
        <source>Extra space: </source>
        <translation>Espace supplémentaire :</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="407"/>
        <source>Default scale: </source>
        <translation>Echelle par défaut :</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="408"/>
        <source>Default rotation: </source>
        <translation>Rotation par défaut :</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="410"/>
        <source>1 : </source>
        <translation></translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="411"/>
        <source> Degrees</source>
        <translation> Degrés</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="417"/>
        <source>Mapbook by feature</source>
        <translation>Catalogue de carte par objet</translation>
    </message>
    <message>
        <location filename="easyprintgui.py" line="54"/>
        <source>Regular grid</source>
        <translation>Grille régulière</translation>
    </message>
    <message>
        <location filename="easyprintgui.py" line="55"/>
        <source>Regular grid (w/o empty grids)</source>
        <translation>Grille régulière (sans grille vide)</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="393"/>
        <source>Shaded cells: </source>
        <translation>Cases grisées :</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="394"/>
        <source>Print single file: </source>
        <translation>Imprimer dans un seul fichier :</translation>
    </message>
</context>
<context>
    <name>init</name>
    <message>
        <location filename="__init__.py" line="9"/>
        <source>Create printable maps.</source>
        <translation>Créer des cartes.</translation>
    </message>
</context>
</TS>
