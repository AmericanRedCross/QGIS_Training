<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de">
<context>
    <name>EasyPrint</name>
    <message>
        <location filename="Ui_easyprint.py" line="140"/>
        <source>Easy Print</source>
        <translation type="obsolete">Easy Print</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="403"/>
        <source>Scale: </source>
        <translation>Massstab:</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="372"/>
        <source>Paper size: </source>
        <translation>Papiergrösse:</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="373"/>
        <source>Layout: </source>
        <translation>Layout:</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="401"/>
        <source>Title: </source>
        <translation>Titel:</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="402"/>
        <source>Subtitle: </source>
        <translation>Untertitel:</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="376"/>
        <source>Person: </source>
        <translation>Bearbeiter:</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="147"/>
        <source>Grid</source>
        <translation type="obsolete">Grid</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="148"/>
        <source>Legend</source>
        <translation type="obsolete">Legende</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="149"/>
        <source>Copyright</source>
        <translation type="obsolete">Copyright</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="371"/>
        <source>User defined scale: </source>
        <translation>freier Massstab:</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="151"/>
        <source>Cutting lines</source>
        <translation type="obsolete">Schnittmarken</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="152"/>
        <source>Folding marks</source>
        <translation type="obsolete">Faltmarken</translation>
    </message>
    <message>
        <location filename="easyprint.py" line="105"/>
        <source>user defined</source>
        <translation>benutzerdefiniert</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="368"/>
        <source>EasyPrint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="399"/>
        <source>Map </source>
        <translation>Karte </translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="377"/>
        <source>Legend: </source>
        <translation type="unfinished">Legende: </translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="378"/>
        <source>Copyright: </source>
        <translation></translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="379"/>
        <source>Grid: </source>
        <translation>Grid: </translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="380"/>
        <source>Cutting lines: </source>
        <translation>Schnittmarken: </translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="381"/>
        <source>Folding marks: </source>
        <translation>Faltmarken: </translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="382"/>
        <source>SimpleMap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="383"/>
        <source>Grid </source>
        <translation></translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="384"/>
        <source>Grid type: </source>
        <translation>Gittertyp: </translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="400"/>
        <source>Map layer: </source>
        <translation>Kartenlayer: </translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="386"/>
        <source>Overlap percentage: </source>
        <translation>Überlappung: </translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="409"/>
        <source> %</source>
        <translation> %</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="388"/>
        <source>Create</source>
        <translation>Erstellen</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="405"/>
        <source>Parameter </source>
        <translation>Parameter </translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="413"/>
        <source>Overview map: </source>
        <translation>Übersichtskarte: </translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="391"/>
        <source>Adjacent tile indicator: </source>
        <translation>Angrenzende Zellen: </translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="412"/>
        <source>Print as raster: </source>
        <translation>Als Raster drucken: </translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="414"/>
        <source>Export </source>
        <translation>Export: </translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="415"/>
        <source>Export to: </source>
        <translation>Exportieren nach: </translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="416"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="398"/>
        <source>Mapbook by grid</source>
        <translation>Mapbook (Grid)</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="404"/>
        <source>Rotation: </source>
        <translation>Rotation: </translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="406"/>
        <source>Extra space: </source>
        <translation type="unfinished">Zusätzlicher Rand: </translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="407"/>
        <source>Default scale: </source>
        <translation>Standard Massstab: </translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="408"/>
        <source>Default rotation: </source>
        <translation>Standard Rotation: </translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="410"/>
        <source>1 : </source>
        <translation>1 : </translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="411"/>
        <source> Degrees</source>
        <translation> Grad</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="417"/>
        <source>Mapbook by feature</source>
        <translation>Mapbook (Feature)</translation>
    </message>
    <message>
        <location filename="easyprintgui.py" line="54"/>
        <source>Regular grid</source>
        <translation>Regelmässiges Gitter</translation>
    </message>
    <message>
        <location filename="easyprintgui.py" line="55"/>
        <source>Regular grid (w/o empty grids)</source>
        <translation>Regelmässiges Gitter (ohne leere Zellen)</translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="393"/>
        <source>Shaded cells: </source>
        <translation>Schattierte Zellen: </translation>
    </message>
    <message>
        <location filename="Ui_easyprint.py" line="394"/>
        <source>Print single file: </source>
        <translation>Einzelne Datei erzeugen: </translation>
    </message>
</context>
<context>
    <name>init</name>
    <message>
        <location filename="__init__.py" line="9"/>
        <source>Create printable maps.</source>
        <translation>Einfaches Erstellen von Karten.</translation>
    </message>
</context>
</TS>
