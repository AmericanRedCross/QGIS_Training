Deps for tkme on x86_64 linux:

libXft.i686