<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1">
<context>
    <name>ApplyTemplatesDialog</name>
    <message>
        <location filename="ui/ui_apply_templates.ui" line="14"/>
        <source>Apply templates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_apply_templates.ui" line="22"/>
        <source>Select files from disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_apply_templates.ui" line="32"/>
        <source>Select files...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_apply_templates.ui" line="58"/>
        <source>Templates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_apply_templates.ui" line="64"/>
        <source>Institution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_apply_templates.ui" line="71"/>
        <source>License</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_apply_templates.ui" line="78"/>
        <source>Workflow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_apply_templates.ui" line="181"/>
        <source>Manage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_apply_templates.ui" line="136"/>
        <source>Log file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_apply_templates.ui" line="150"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_apply_templates.ui" line="157"/>
        <source>Extract layer parameters to metadata XML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_apply_templates.ui" line="164"/>
        <source>Generate preview image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_apply_templates.ui" line="171"/>
        <source>DataType</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="apply_templates_dialog.py" line="74"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="apply_templates_dialog.py" line="75"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="apply_templates_dialog.py" line="136"/>
        <source>Select files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="apply_templates_dialog.py" line="136"/>
        <source>All files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="apply_templates_dialog.py" line="200"/>
        <source>Select log file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="apply_templates_dialog.py" line="200"/>
        <source>Text files (*.txt);;Log files (*.log);;All files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="apply_templates_dialog.py" line="247"/>
        <source>No profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="apply_templates_dialog.py" line="247"/>
        <source>No profile selected. Please set default profile in plugin settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="apply_templates_dialog.py" line="314"/>
        <source>Metatools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="apply_templates_dialog.py" line="262"/>
        <source>Metadata file can&apos;t be created: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="apply_templates_dialog.py" line="269"/>
        <source>File %1 has unsupported metadata standard! Only ISO19115 supported now!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="apply_templates_dialog.py" line="305"/>
        <source>Done!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="apply_templates_dialog.py" line="314"/>
        <source>Operation can&apos;t be completed: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DataTypeEditorDialog</name>
    <message>
        <location filename="datatype_editor_dialog.py" line="140"/>
        <source>Manage data types</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_datatype_editor.ui" line="25"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_datatype_editor.ui" line="135"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_datatype_editor.ui" line="41"/>
        <source>Type of data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_datatype_editor.ui" line="50"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_datatype_editor.ui" line="60"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_datatype_editor.ui" line="70"/>
        <source>Spatial accuracy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_datatype_editor.ui" line="80"/>
        <source>Thematic accuracy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_datatype_editor.ui" line="93"/>
        <source>Spatial scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_datatype_editor.ui" line="100"/>
        <source>Thematic content</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_datatype_editor.ui" line="128"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_datatype_editor.ui" line="142"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="datatype_editor_dialog.py" line="223"/>
        <source>Metatools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="datatype_editor_dialog.py" line="93"/>
        <source>Template contains unsaved data. Create new template without saving?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="datatype_editor_dialog.py" line="129"/>
        <source>The name of the data type template must be specified!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="datatype_editor_dialog.py" line="140"/>
        <source>Template can&apos;t be saved: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="datatype_editor_dialog.py" line="154"/>
        <source>Template contains unsaved data. Close the window without saving?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="datatype_editor_dialog.py" line="212"/>
        <source>New keyword</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="datatype_editor_dialog.py" line="212"/>
        <source>Input keyword:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="datatype_editor_dialog.py" line="210"/>
        <source>Select keyword for edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="datatype_editor_dialog.py" line="220"/>
        <source>Select keyword for remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="datatype_editor_dialog.py" line="223"/>
        <source>Remove this keyword?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DomModel</name>
    <message>
        <location filename="dom_model.py" line="184"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dom_model.py" line="186"/>
        <source>Attributes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dom_model.py" line="188"/>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LicenseEditorDialog</name>
    <message>
        <location filename="license_editor_dialog.py" line="124"/>
        <source>Manage licenses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_license_editor.ui" line="25"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_license_editor.ui" line="32"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_license_editor.ui" line="41"/>
        <source>License</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_license_editor.ui" line="47"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_license_editor.ui" line="57"/>
        <source>Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_license_editor.ui" line="67"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="license_editor_dialog.py" line="157"/>
        <source>Metatools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="license_editor_dialog.py" line="77"/>
        <source>Template contains unsaved data. Create new template without saving?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="license_editor_dialog.py" line="113"/>
        <source>The name of the license must be specified!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="license_editor_dialog.py" line="124"/>
        <source>Template can&apos;t be saved: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="license_editor_dialog.py" line="157"/>
        <source>Template contains unsaved data. Close the window without saving?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MetadataBrowser</name>
    <message>
        <location filename="ui/ui_metadata_browser.ui" line="14"/>
        <source>Metadata browser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_metadata_browser.ui" line="24"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_metadata_browser.ui" line="33"/>
        <source>Search condition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_metadata_browser.ui" line="42"/>
        <source>Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_metadata_browser.ui" line="52"/>
        <source>Search result</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_metadata_browser.ui" line="128"/>
        <source>about:blank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_metadata_browser.ui" line="98"/>
        <source>Catalog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_metadata_browser.ui" line="141"/>
        <source>Databases</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_metadata_browser.ui" line="184"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Metatools</name>
    <message>
        <location filename="apply_templates_dialog.py" line="66"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="76"/>
        <source>Quantum GIS version detected: %1.%2
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="76"/>
        <source>This version of Metatools requires at least QGIS version 1.5.0
Plugin will not be enabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="83"/>
        <source>Qt version detected: %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="83"/>
        <source>This version of Metatools requires at least Qt version %1
Plugin will not be enabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="92"/>
        <source>Edit metadata</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="95"/>
        <source>Apply templates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="97"/>
        <source>Edit and apply templates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="102"/>
        <source>View metadata</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="105"/>
        <source>Configure Metatools plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="107"/>
        <source>Configure plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="112"/>
        <source>Validate metadata</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="118"/>
        <source>Import metadata</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="117"/>
        <source>Import metadata from file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="121"/>
        <source>Export metadata</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="122"/>
        <source>Export metadata to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="126"/>
        <source>Metadata browser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="132"/>
        <source>USGS Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="138"/>
        <source>MP Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="582"/>
        <source>Metatools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="179"/>
        <source>Metatools: FGDC tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="258"/>
        <source>Editor can&apos;t be loaded: %1 %2!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="319"/>
        <source>Unsupported metadata standard! Only ISO19115 and FGDC supported now!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="291"/>
        <source>Applyer can&apos;t be loaded: %1 %2!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="305"/>
        <source>Viewer can&apos;t be loaded: %1 %2!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="340"/>
        <source>The layer does not have metadata! Create metadata?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="349"/>
        <source>No profile selected. Please set default profile in plugin settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="357"/>
        <source>Metadata file can&apos;t be created: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="378"/>
        <source>USGS tool support only FGDC standard!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="404"/>
        <source>USGS tool can&apos;t be runing: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="418"/>
        <source>MP tool support only FGDC standard!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="458"/>
        <source>MP tool can&apos;t be runing: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="474"/>
        <source>MP result</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="492"/>
        <source>Unsupported metadata standard! Only FGDC supported now!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="505"/>
        <source>Metadata is invalid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="515"/>
        <source>Shcema for validate not loaded!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="528"/>
        <source>Metadata is valid!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="539"/>
        <source>Select metadata file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="565"/>
        <source>XML files (*.xml);;Text files (*.txt *.TXT);;All files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="550"/>
        <source>Metadata can&apos;t be imported: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="556"/>
        <source>Metadata was imported successful!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="565"/>
        <source>Save metadata to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="576"/>
        <source>Metadata can&apos;t be exported: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatools.py" line="582"/>
        <source>Metadata was exported successful!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MetatoolsEditor</name>
    <message>
        <location filename="ui/ui_editor.ui" line="14"/>
        <source>Metadata editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_editor.ui" line="31"/>
        <source>Full view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_editor.ui" line="41"/>
        <source>Filtered view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_editor.ui" line="47"/>
        <source>To set filtered view please check sample.txt in the filter directory for the filtering format and point to it at the plugin settings page.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_editor.ui" line="91"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_editor.ui" line="96"/>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_editor.ui" line="109"/>
        <source>Edit value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_editor.ui" line="115"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_editor.ui" line="153"/>
        <source>Copy path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_editor.ui" line="156"/>
        <source>Copy node path to clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatoolseditor.py" line="52"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatoolseditor.py" line="53"/>
        <source>Discard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatoolseditor.py" line="217"/>
        <source>Metatools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatoolseditor.py" line="217"/>
        <source>Metadata can&apos;t be saved:
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatoolseditor.py" line="230"/>
        <source>I/O error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatoolseditor.py" line="230"/>
        <source>Can&apos;t open file %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MetatoolsSettings</name>
    <message>
        <location filename="metatoolssettings.py" line="96"/>
        <source>Select filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatoolssettings.py" line="96"/>
        <source>Text files (*.txt *.TXT)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MetatoolsSettingsDialog</name>
    <message>
        <location filename="ui/ui_settings.ui" line="14"/>
        <source>Metatools settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="24"/>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="30"/>
        <source>Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="36"/>
        <source>Filter file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="46"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="56"/>
        <source>Preview image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="62"/>
        <source>Image format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="82"/>
        <source>Default profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="88"/>
        <source>Select profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="115"/>
        <source>ISO 19115</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="138"/>
        <source>View stylesheet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="132"/>
        <source>FGDC</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MetatoolsViewer</name>
    <message>
        <location filename="ui/ui_viewer.ui" line="20"/>
        <source>Metadata viewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_viewer.ui" line="54"/>
        <source>about:blank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_viewer.ui" line="82"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_viewer.ui" line="85"/>
        <source>Ctrl+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_viewer.ui" line="94"/>
        <source>Copy all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_viewer.ui" line="103"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_viewer.ui" line="106"/>
        <source>Ctrl+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="metatoolsviewer.py" line="97"/>
        <source>Translation error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OrganizationEditorDialog</name>
    <message>
        <location filename="ui/ui_organization_editor.ui" line="14"/>
        <source>Manage organisations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_organization_editor.ui" line="25"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_organization_editor.ui" line="32"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_organization_editor.ui" line="41"/>
        <source>Organisation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_organization_editor.ui" line="47"/>
        <source>Organisation name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_organization_editor.ui" line="57"/>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_organization_editor.ui" line="63"/>
        <source>Delivery point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_organization_editor.ui" line="73"/>
        <source>City</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_organization_editor.ui" line="83"/>
        <source>Administrative area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_organization_editor.ui" line="93"/>
        <source>Postal code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_organization_editor.ui" line="103"/>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_organization_editor.ui" line="116"/>
        <source>Contact person</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_organization_editor.ui" line="122"/>
        <source>Individual name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_organization_editor.ui" line="132"/>
        <source>Person title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_organization_editor.ui" line="142"/>
        <source>Person position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_organization_editor.ui" line="155"/>
        <source>Telephone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_organization_editor.ui" line="165"/>
        <source>Fax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_organization_editor.ui" line="175"/>
        <source>E-Mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_organization_editor.ui" line="185"/>
        <source>Office hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="organization_editor_dialog.py" line="185"/>
        <source>Metatools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="organization_editor_dialog.py" line="89"/>
        <source>Template contains unsaved data. Create new template without saving?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="organization_editor_dialog.py" line="185"/>
        <source>Template contains unsaved data. Close the window without saving?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WorkflowEditorDialog</name>
    <message>
        <location filename="workflow_editor_dialog.py" line="127"/>
        <source>Manage workflows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_workflow_editor.ui" line="25"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_workflow_editor.ui" line="32"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_workflow_editor.ui" line="41"/>
        <source>Workflow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_workflow_editor.ui" line="50"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_workflow_editor.ui" line="60"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="workflow_editor_dialog.py" line="157"/>
        <source>Metatools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="workflow_editor_dialog.py" line="76"/>
        <source>Template contains unsaved data. Create new template without saving?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="workflow_editor_dialog.py" line="116"/>
        <source>The name of the workflow must be specified!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="workflow_editor_dialog.py" line="127"/>
        <source>Template can&apos;t be saved: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="workflow_editor_dialog.py" line="157"/>
        <source>Template contains unsaved data. Close the window without saving?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
