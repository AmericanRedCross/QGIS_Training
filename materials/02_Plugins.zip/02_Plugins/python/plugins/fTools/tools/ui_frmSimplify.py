# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'D:/src/qgis-1.7.3/python/plugins/fTools/tools/frmSimplify.ui'
#
# Created: Sun Dec 11 11:35:49 2011
#      by: PyQt4 UI code generator 4.8.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.setWindowModality(QtCore.Qt.WindowModal)
        Dialog.resize(400, 269)
        self.verticalLayout = QtGui.QVBoxLayout(Dialog)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.label = QtGui.QLabel(Dialog)
        self.label.setObjectName(_fromUtf8("label"))
        self.verticalLayout.addWidget(self.label)
        self.cmbInputLayer = QtGui.QComboBox(Dialog)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.cmbInputLayer.sizePolicy().hasHeightForWidth())
        self.cmbInputLayer.setSizePolicy(sizePolicy)
        self.cmbInputLayer.setObjectName(_fromUtf8("cmbInputLayer"))
        self.verticalLayout.addWidget(self.cmbInputLayer)
        self.useSelectionCheck = QtGui.QCheckBox(Dialog)
        self.useSelectionCheck.setObjectName(_fromUtf8("useSelectionCheck"))
        self.verticalLayout.addWidget(self.useSelectionCheck)
        self.horizontalLayout_3 = QtGui.QHBoxLayout()
        self.horizontalLayout_3.setObjectName(_fromUtf8("horizontalLayout_3"))
        self.label_2 = QtGui.QLabel(Dialog)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.horizontalLayout_3.addWidget(self.label_2)
        self.toleranceSpin = QtGui.QDoubleSpinBox(Dialog)
        self.toleranceSpin.setDecimals(4)
        self.toleranceSpin.setMinimum(0.0)
        self.toleranceSpin.setMaximum(10000000.0)
        self.toleranceSpin.setProperty(_fromUtf8("value"), 0.0001)
        self.toleranceSpin.setObjectName(_fromUtf8("toleranceSpin"))
        self.horizontalLayout_3.addWidget(self.toleranceSpin)
        self.verticalLayout.addLayout(self.horizontalLayout_3)
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        self.writeShapefileCheck = QtGui.QCheckBox(Dialog)
        self.writeShapefileCheck.setObjectName(_fromUtf8("writeShapefileCheck"))
        self.horizontalLayout_2.addWidget(self.writeShapefileCheck)
        self.outputFileEdit = QtGui.QLineEdit(Dialog)
        self.outputFileEdit.setEnabled(False)
        self.outputFileEdit.setObjectName(_fromUtf8("outputFileEdit"))
        self.horizontalLayout_2.addWidget(self.outputFileEdit)
        self.btnSelectOutputFile = QtGui.QPushButton(Dialog)
        self.btnSelectOutputFile.setEnabled(False)
        self.btnSelectOutputFile.setObjectName(_fromUtf8("btnSelectOutputFile"))
        self.horizontalLayout_2.addWidget(self.btnSelectOutputFile)
        self.verticalLayout.addLayout(self.horizontalLayout_2)
        self.addToCanvasCheck = QtGui.QCheckBox(Dialog)
        self.addToCanvasCheck.setEnabled(False)
        self.addToCanvasCheck.setObjectName(_fromUtf8("addToCanvasCheck"))
        self.verticalLayout.addWidget(self.addToCanvasCheck)
        self.progressBar = QtGui.QProgressBar(Dialog)
        self.progressBar.setProperty(_fromUtf8("value"), 0)
        self.progressBar.setObjectName(_fromUtf8("progressBar"))
        self.verticalLayout.addWidget(self.progressBar)
        self.buttonBox = QtGui.QDialogButtonBox(Dialog)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Close|QtGui.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName(_fromUtf8("buttonBox"))
        self.verticalLayout.addWidget(self.buttonBox)

        self.retranslateUi(Dialog)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("accepted()")), Dialog.accept)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("rejected()")), Dialog.reject)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QtGui.QApplication.translate("Dialog", "Simplify geometries", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("Dialog", "Input line or polygon layer", None, QtGui.QApplication.UnicodeUTF8))
        self.useSelectionCheck.setText(QtGui.QApplication.translate("Dialog", "Use only selected features", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("Dialog", "Simplify tolerance", None, QtGui.QApplication.UnicodeUTF8))
        self.writeShapefileCheck.setText(QtGui.QApplication.translate("Dialog", "Save to new file", None, QtGui.QApplication.UnicodeUTF8))
        self.btnSelectOutputFile.setText(QtGui.QApplication.translate("Dialog", "Browse", None, QtGui.QApplication.UnicodeUTF8))
        self.addToCanvasCheck.setText(QtGui.QApplication.translate("Dialog", "Add result to canvas", None, QtGui.QApplication.UnicodeUTF8))

