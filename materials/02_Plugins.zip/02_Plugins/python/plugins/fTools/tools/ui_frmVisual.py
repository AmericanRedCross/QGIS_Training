# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'D:/src/qgis-1.7.3/python/plugins/fTools/tools/frmVisual.ui'
#
# Created: Sun Dec 11 11:35:47 2011
#      by: PyQt4 UI code generator 4.8.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.setWindowModality(QtCore.Qt.NonModal)
        Dialog.resize(404, 481)
        Dialog.setSizeGripEnabled(True)
        self.gridLayout = QtGui.QGridLayout(Dialog)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.vboxlayout = QtGui.QVBoxLayout()
        self.vboxlayout.setObjectName(_fromUtf8("vboxlayout"))
        self.label_3 = QtGui.QLabel(Dialog)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.vboxlayout.addWidget(self.label_3)
        self.inShape = QtGui.QComboBox(Dialog)
        self.inShape.setObjectName(_fromUtf8("inShape"))
        self.vboxlayout.addWidget(self.inShape)
        self.gridLayout.addLayout(self.vboxlayout, 0, 0, 1, 2)
        self.verticalLayout = QtGui.QVBoxLayout()
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.useSelected = QtGui.QCheckBox(Dialog)
        self.useSelected.setObjectName(_fromUtf8("useSelected"))
        self.verticalLayout.addWidget(self.useSelected)
        self.gridLayout.addLayout(self.verticalLayout, 3, 0, 1, 1)
        self.vboxlayout1 = QtGui.QVBoxLayout()
        self.vboxlayout1.setObjectName(_fromUtf8("vboxlayout1"))
        self.label = QtGui.QLabel(Dialog)
        self.label.setObjectName(_fromUtf8("label"))
        self.vboxlayout1.addWidget(self.label)
        self.cmbField = QtGui.QComboBox(Dialog)
        self.cmbField.setObjectName(_fromUtf8("cmbField"))
        self.vboxlayout1.addWidget(self.cmbField)
        self.gridLayout.addLayout(self.vboxlayout1, 4, 0, 1, 2)
        self.vboxlayout2 = QtGui.QVBoxLayout()
        self.vboxlayout2.setObjectName(_fromUtf8("vboxlayout2"))
        self.label_2 = QtGui.QLabel(Dialog)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.vboxlayout2.addWidget(self.label_2)
        self.tblUnique = QtGui.QTableWidget(Dialog)
        self.tblUnique.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.tblUnique.setTabKeyNavigation(False)
        self.tblUnique.setProperty(_fromUtf8("showDropIndicator"), False)
        self.tblUnique.setDragDropOverwriteMode(False)
        self.tblUnique.setAlternatingRowColors(True)
        self.tblUnique.setSelectionMode(QtGui.QAbstractItemView.NoSelection)
        self.tblUnique.setShowGrid(False)
        self.tblUnique.setWordWrap(False)
        self.tblUnique.setCornerButtonEnabled(False)
        self.tblUnique.setObjectName(_fromUtf8("tblUnique"))
        self.tblUnique.setColumnCount(0)
        self.tblUnique.setRowCount(0)
        self.tblUnique.horizontalHeader().setVisible(False)
        self.tblUnique.verticalHeader().setVisible(False)
        self.vboxlayout2.addWidget(self.tblUnique)
        self.gridLayout.addLayout(self.vboxlayout2, 5, 0, 1, 2)
        self.hboxlayout = QtGui.QHBoxLayout()
        self.hboxlayout.setObjectName(_fromUtf8("hboxlayout"))
        self.label_4 = QtGui.QLabel(Dialog)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.hboxlayout.addWidget(self.label_4)
        self.lstCount = QtGui.QLineEdit(Dialog)
        self.lstCount.setReadOnly(True)
        self.lstCount.setObjectName(_fromUtf8("lstCount"))
        self.hboxlayout.addWidget(self.lstCount)
        self.gridLayout.addLayout(self.hboxlayout, 6, 0, 1, 2)
        self.progressBar = QtGui.QProgressBar(Dialog)
        self.progressBar.setProperty(_fromUtf8("value"), 24)
        self.progressBar.setAlignment(QtCore.Qt.AlignCenter)
        self.progressBar.setObjectName(_fromUtf8("progressBar"))
        self.gridLayout.addWidget(self.progressBar, 9, 0, 1, 1)
        self.buttonBox_2 = QtGui.QDialogButtonBox(Dialog)
        self.buttonBox_2.setOrientation(QtCore.Qt.Vertical)
        self.buttonBox_2.setStandardButtons(QtGui.QDialogButtonBox.Close|QtGui.QDialogButtonBox.Ok)
        self.buttonBox_2.setObjectName(_fromUtf8("buttonBox_2"))
        self.gridLayout.addWidget(self.buttonBox_2, 8, 1, 2, 1)
        self.partProgressBar = QtGui.QProgressBar(Dialog)
        self.partProgressBar.setProperty(_fromUtf8("value"), 24)
        self.partProgressBar.setObjectName(_fromUtf8("partProgressBar"))
        self.gridLayout.addWidget(self.partProgressBar, 8, 0, 1, 1)
        self.label_5 = QtGui.QLabel(Dialog)
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.gridLayout.addWidget(self.label_5, 7, 0, 1, 1)

        self.retranslateUi(Dialog)
        QtCore.QObject.connect(self.buttonBox_2, QtCore.SIGNAL(_fromUtf8("accepted()")), Dialog.accept)
        QtCore.QObject.connect(self.buttonBox_2, QtCore.SIGNAL(_fromUtf8("rejected()")), Dialog.close)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QtGui.QApplication.translate("Dialog", "List Unique Values", None, QtGui.QApplication.UnicodeUTF8))
        self.label_3.setText(QtGui.QApplication.translate("Dialog", "Input Vector Layer", None, QtGui.QApplication.UnicodeUTF8))
        self.useSelected.setText(QtGui.QApplication.translate("Dialog", "Use only selected features", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("Dialog", "Target field", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("Dialog", "Unique values list", None, QtGui.QApplication.UnicodeUTF8))
        self.label_4.setText(QtGui.QApplication.translate("Dialog", "Unique value count", None, QtGui.QApplication.UnicodeUTF8))
        self.label_5.setText(QtGui.QApplication.translate("Dialog", "Press Ctrl+C to copy results to the clipboard", None, QtGui.QApplication.UnicodeUTF8))

