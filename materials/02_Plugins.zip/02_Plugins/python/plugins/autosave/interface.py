# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'interface.ui'
#
# Created: Sat Jan 31 09:38:22 2009
#      by: PyQt4 UI code generator 4.3.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_AutoSave(object):
    def setupUi(self, AutoSave):
        AutoSave.setObjectName("AutoSave")
        AutoSave.resize(QtCore.QSize(QtCore.QRect(0,0,453,290).size()).expandedTo(AutoSave.minimumSizeHint()))

        self.vboxlayout = QtGui.QVBoxLayout(AutoSave)
        self.vboxlayout.setObjectName("vboxlayout")

        self.myTitle = QtGui.QLabel(AutoSave)

        font = QtGui.QFont()
        font.setPointSize(24)
        self.myTitle.setFont(font)
        self.myTitle.setAlignment(QtCore.Qt.AlignCenter)
        self.myTitle.setObjectName("myTitle")
        self.vboxlayout.addWidget(self.myTitle)

        self.saveEnabled = QtGui.QCheckBox(AutoSave)
        self.saveEnabled.setObjectName("saveEnabled")
        self.vboxlayout.addWidget(self.saveEnabled)

        self.settings = QtGui.QGroupBox(AutoSave)
        self.settings.setObjectName("settings")

        self.vboxlayout1 = QtGui.QVBoxLayout(self.settings)
        self.vboxlayout1.setObjectName("vboxlayout1")

        self.hboxlayout = QtGui.QHBoxLayout()
        self.hboxlayout.setObjectName("hboxlayout")

        self.label = QtGui.QLabel(self.settings)
        self.label.setObjectName("label")
        self.hboxlayout.addWidget(self.label)

        self.interval = QtGui.QTimeEdit(self.settings)
        self.interval.setMinimumTime(QtCore.QTime(0,1,0))
        self.interval.setCurrentSection(QtGui.QDateTimeEdit.MinuteSection)
        self.interval.setTime(QtCore.QTime(0,10,0))
        self.interval.setObjectName("interval")
        self.hboxlayout.addWidget(self.interval)
        self.vboxlayout1.addLayout(self.hboxlayout)

        self.hboxlayout1 = QtGui.QHBoxLayout()
        self.hboxlayout1.setObjectName("hboxlayout1")

        self.label_2 = QtGui.QLabel(self.settings)
        self.label_2.setObjectName("label_2")
        self.hboxlayout1.addWidget(self.label_2)

        self.revisionCount = QtGui.QSpinBox(self.settings)
        self.revisionCount.setMinimum(1)
        self.revisionCount.setMaximum(10)
        self.revisionCount.setProperty("value",QtCore.QVariant(2))
        self.revisionCount.setObjectName("revisionCount")
        self.hboxlayout1.addWidget(self.revisionCount)
        self.vboxlayout1.addLayout(self.hboxlayout1)

        self.hboxlayout2 = QtGui.QHBoxLayout()
        self.hboxlayout2.setObjectName("hboxlayout2")

        self.chooseFolder = QtGui.QPushButton(self.settings)
        self.chooseFolder.setObjectName("chooseFolder")
        self.hboxlayout2.addWidget(self.chooseFolder)

        self.folder = QtGui.QLineEdit(self.settings)
        self.folder.setObjectName("folder")
        self.hboxlayout2.addWidget(self.folder)
        self.vboxlayout1.addLayout(self.hboxlayout2)
        self.vboxlayout.addWidget(self.settings)

        self.buttonBox = QtGui.QDialogButtonBox(AutoSave)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Help|QtGui.QDialogButtonBox.NoButton|QtGui.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.vboxlayout.addWidget(self.buttonBox)

        self.retranslateUi(AutoSave)
        QtCore.QObject.connect(self.buttonBox,QtCore.SIGNAL("accepted()"),AutoSave.accept)
        QtCore.QObject.connect(self.buttonBox,QtCore.SIGNAL("rejected()"),AutoSave.reject)
        QtCore.QMetaObject.connectSlotsByName(AutoSave)

    def retranslateUi(self, AutoSave):
        AutoSave.setWindowTitle(QtGui.QApplication.translate("AutoSave", "Dialog", None, QtGui.QApplication.UnicodeUTF8))
        self.myTitle.setText(QtGui.QApplication.translate("AutoSave", "AutoSave", None, QtGui.QApplication.UnicodeUTF8))
        self.saveEnabled.setText(QtGui.QApplication.translate("AutoSave", "Enable Auto-save", None, QtGui.QApplication.UnicodeUTF8))
        self.settings.setTitle(QtGui.QApplication.translate("AutoSave", "Settings", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("AutoSave", "Save Interval (hh:mm)", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("AutoSave", "Revisions to save:", None, QtGui.QApplication.UnicodeUTF8))
        self.chooseFolder.setText(QtGui.QApplication.translate("AutoSave", "Autosave Folder", None, QtGui.QApplication.UnicodeUTF8))

import resource_rc
