

from PyQt4 import QtGui, QtCore
from PyQt4.QtCore import Qt

#from qgis.core import *
#from qgis.gui import *

from interface import Ui_AutoSave

class AutosaveDialog(QtGui.QDialog, Ui_AutoSave):
    def __init__(self):
        QtGui.QDialog.__init__(self)
        s=QtCore.QSettings()
        self.setupUi(self)
        self.interval.setTime(s.value("AutoSave/interval").toTime())
        self.revisionCount.setValue(s.value("AutoSave/revisionCount").toInt()[0])
        self.folder.setText(s.value("AutoSave/folder").toString())
        self.saveEnabled.setCheckState(Qt.CheckState(s.value("AutoSave/saveEnabled").toInt()[0]))
        #print "state is ",s.value("AutoSave/saveEnabled").toInt()[0]
        self.settings.setEnabled(s.value("AutoSave/saveEnabled").toInt()[0] == 2)

        QtCore.QObject.connect(self.chooseFolder,QtCore.SIGNAL("clicked()"),self.pickFolder)

        QtCore.QObject.connect(self.saveEnabled,QtCore.SIGNAL("toggled(bool)"),self.settings.setEnabled)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL("helpRequested()"), self.help)

    def pickFolder(self):
        qd=QtGui.QFileDialog()
        f=qd.getExistingDirectory()
        if len(f) > 0:
            self.folder.setText(f)


    def accept(self):
        self.setSettingsFromDialog()
        QtGui.QDialog.accept(self)


    def reject(self):
        QtGui.QDialog.reject(self)

    def help(self):
        import showText

        mainHelp = """
AutoSave
--------

by Barry Rowlingson <b.rowlingson@lancaster.ac.uk>


This plugin saves your project every so often to a folder you specify. It 
is designed to keep a copy in case Qgis crashes.


Icons from:

 Javier Odriozola http://www.jodriozola.com/blog/?p=10  (CC license)

"""
        window = QtGui.QDialog()
        ui = showText.Ui_Dialog()
        ui.setupUi(window)
        ui.text.setText(mainHelp)
        window.show()
        window.exec_()

    def setSettingsFromDialog(self):
        """ set settings from dialog into qgis settings. """
        s=QtCore.QSettings()
        s.setValue("AutoSave/interval",QtCore.QVariant(QtCore.QTime(self.interval.time())))
        s.setValue("AutoSave/revisionCount",QtCore.QVariant(self.revisionCount.value()))
        s.setValue("AutoSave/folder",QtCore.QVariant(self.folder.text()))
        if self.saveEnabled.isChecked():
            code = 2
        else:
            code = 0
        s.setValue("AutoSave/saveEnabled",QtCore.QVariant(code))
 
def main():
    import sys
    app=QtGui.QApplication(sys.argv)
    ad = AutosaveDialog()
    ad.show()
    app.exec_()

    
if __name__=="__main__":
    main()
