# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'D:/src/qgis-1.7.3/python/plugins/plugin_installer/qgsplugininstalleroldreposbase.ui'
#
# Created: Sun Dec 11 11:35:42 2011
#      by: PyQt4 UI code generator 4.8.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_QgsPluginInstallerOldReposBase(object):
    def setupUi(self, QgsPluginInstallerOldReposBase):
        QgsPluginInstallerOldReposBase.setObjectName(_fromUtf8("QgsPluginInstallerOldReposBase"))
        QgsPluginInstallerOldReposBase.resize(601, 182)
        QgsPluginInstallerOldReposBase.setMinimumSize(QtCore.QSize(480, 182))
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(_fromUtf8(":/plugins/installer/qgis-icon.png")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        QgsPluginInstallerOldReposBase.setWindowIcon(icon)
        self.gridLayout = QtGui.QGridLayout(QgsPluginInstallerOldReposBase)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label = QtGui.QLabel(QgsPluginInstallerOldReposBase)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label.sizePolicy().hasHeightForWidth())
        self.label.setSizePolicy(sizePolicy)
        self.label.setWordWrap(True)
        self.label.setOpenExternalLinks(True)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 0, 1, 1, 1)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.butOldReposRemove = QtGui.QPushButton(QgsPluginInstallerOldReposBase)
        self.butOldReposRemove.setObjectName(_fromUtf8("butOldReposRemove"))
        self.horizontalLayout.addWidget(self.butOldReposRemove)
        self.butOldReposDisable = QtGui.QPushButton(QgsPluginInstallerOldReposBase)
        self.butOldReposDisable.setObjectName(_fromUtf8("butOldReposDisable"))
        self.horizontalLayout.addWidget(self.butOldReposDisable)
        self.butOldReposKeep = QtGui.QPushButton(QgsPluginInstallerOldReposBase)
        self.butOldReposKeep.setObjectName(_fromUtf8("butOldReposKeep"))
        self.horizontalLayout.addWidget(self.butOldReposKeep)
        self.butOldReposAsk = QtGui.QPushButton(QgsPluginInstallerOldReposBase)
        self.butOldReposAsk.setDefault(True)
        self.butOldReposAsk.setObjectName(_fromUtf8("butOldReposAsk"))
        self.horizontalLayout.addWidget(self.butOldReposAsk)
        self.gridLayout.addLayout(self.horizontalLayout, 1, 1, 1, 2)
        spacerItem = QtGui.QSpacerItem(20, 20, QtGui.QSizePolicy.Fixed, QtGui.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem, 0, 3, 1, 1)
        spacerItem1 = QtGui.QSpacerItem(20, 20, QtGui.QSizePolicy.Fixed, QtGui.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem1, 0, 0, 1, 1)

        self.retranslateUi(QgsPluginInstallerOldReposBase)
        QtCore.QMetaObject.connectSlotsByName(QgsPluginInstallerOldReposBase)

    def retranslateUi(self, QgsPluginInstallerOldReposBase):
        QgsPluginInstallerOldReposBase.setWindowTitle(QtGui.QApplication.translate("QgsPluginInstallerOldReposBase", "Plugin Installer", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("QgsPluginInstallerOldReposBase", "The Plugin Installer has detected that your copy of QGIS is configured to use a number of plugin repositories around the world. It was a typical situation in older versions of the program, but from the version 1.5, external plugins are collected in one central Contributed Repository, and all the old repositories are not necessary any more. Do you want to drop them now? If you\'re unsure what to do, probably you don\'t need them. However, if you choose to keep them in use, you will be able to remove them manually later.", None, QtGui.QApplication.UnicodeUTF8))
        self.butOldReposRemove.setText(QtGui.QApplication.translate("QgsPluginInstallerOldReposBase", "Remove", None, QtGui.QApplication.UnicodeUTF8))
        self.butOldReposDisable.setText(QtGui.QApplication.translate("QgsPluginInstallerOldReposBase", "Disable", None, QtGui.QApplication.UnicodeUTF8))
        self.butOldReposKeep.setText(QtGui.QApplication.translate("QgsPluginInstallerOldReposBase", "Keep", None, QtGui.QApplication.UnicodeUTF8))
        self.butOldReposAsk.setText(QtGui.QApplication.translate("QgsPluginInstallerOldReposBase", "Ask me later", None, QtGui.QApplication.UnicodeUTF8))

import resources_rc
