# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'D:/src/qgis-1.7.3/python/plugins/GdalTools/tools/widgetRasterize.ui'
#
# Created: Sun Dec 11 11:35:47 2011
#      by: PyQt4 UI code generator 4.8.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_GdalToolsWidget(object):
    def setupUi(self, GdalToolsWidget):
        GdalToolsWidget.setObjectName(_fromUtf8("GdalToolsWidget"))
        GdalToolsWidget.resize(509, 165)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(GdalToolsWidget.sizePolicy().hasHeightForWidth())
        GdalToolsWidget.setSizePolicy(sizePolicy)
        self.verticalLayout = QtGui.QVBoxLayout(GdalToolsWidget)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout_2 = QtGui.QGridLayout()
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.label = QtGui.QLabel(GdalToolsWidget)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout_2.addWidget(self.label, 0, 0, 1, 1)
        self.label_3 = QtGui.QLabel(GdalToolsWidget)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.gridLayout_2.addWidget(self.label_3, 1, 0, 1, 1)
        self.attributeComboBox = QtGui.QComboBox(GdalToolsWidget)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.attributeComboBox.sizePolicy().hasHeightForWidth())
        self.attributeComboBox.setSizePolicy(sizePolicy)
        self.attributeComboBox.setObjectName(_fromUtf8("attributeComboBox"))
        self.gridLayout_2.addWidget(self.attributeComboBox, 1, 1, 1, 1)
        self.label_2 = QtGui.QLabel(GdalToolsWidget)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout_2.addWidget(self.label_2, 2, 0, 1, 1)
        self.inSelector = GdalToolsInOutSelector(GdalToolsWidget)
        self.inSelector.setObjectName(_fromUtf8("inSelector"))
        self.gridLayout_2.addWidget(self.inSelector, 0, 1, 1, 1)
        self.outSelector = GdalToolsInOutSelector(GdalToolsWidget)
        self.outSelector.setObjectName(_fromUtf8("outSelector"))
        self.gridLayout_2.addWidget(self.outSelector, 2, 1, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout_2)
        self.resizeGroupBox = QtGui.QGroupBox(GdalToolsWidget)
        self.resizeGroupBox.setCheckable(True)
        self.resizeGroupBox.setChecked(False)
        self.resizeGroupBox.setObjectName(_fromUtf8("resizeGroupBox"))
        self.gridLayout_7 = QtGui.QGridLayout(self.resizeGroupBox)
        self.gridLayout_7.setObjectName(_fromUtf8("gridLayout_7"))
        self.label_11 = QtGui.QLabel(self.resizeGroupBox)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Fixed, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label_11.sizePolicy().hasHeightForWidth())
        self.label_11.setSizePolicy(sizePolicy)
        self.label_11.setObjectName(_fromUtf8("label_11"))
        self.gridLayout_7.addWidget(self.label_11, 0, 0, 1, 1)
        self.widthSpin = QtGui.QSpinBox(self.resizeGroupBox)
        self.widthSpin.setMaximum(999999)
        self.widthSpin.setObjectName(_fromUtf8("widthSpin"))
        self.gridLayout_7.addWidget(self.widthSpin, 0, 1, 1, 1)
        self.label_12 = QtGui.QLabel(self.resizeGroupBox)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Fixed, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label_12.sizePolicy().hasHeightForWidth())
        self.label_12.setSizePolicy(sizePolicy)
        self.label_12.setIndent(40)
        self.label_12.setObjectName(_fromUtf8("label_12"))
        self.gridLayout_7.addWidget(self.label_12, 0, 2, 1, 1)
        self.heightSpin = QtGui.QSpinBox(self.resizeGroupBox)
        self.heightSpin.setMaximum(999999)
        self.heightSpin.setObjectName(_fromUtf8("heightSpin"))
        self.gridLayout_7.addWidget(self.heightSpin, 0, 3, 1, 1)
        self.verticalLayout.addWidget(self.resizeGroupBox)
        self.label.setBuddy(self.inSelector)
        self.label_3.setBuddy(self.attributeComboBox)
        self.label_2.setBuddy(self.outSelector)

        self.retranslateUi(GdalToolsWidget)
        QtCore.QMetaObject.connectSlotsByName(GdalToolsWidget)

    def retranslateUi(self, GdalToolsWidget):
        GdalToolsWidget.setWindowTitle(QtGui.QApplication.translate("GdalToolsWidget", "Rasterize (Vector to raster)", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("GdalToolsWidget", "&Input file (shapefile)", None, QtGui.QApplication.UnicodeUTF8))
        self.label_3.setText(QtGui.QApplication.translate("GdalToolsWidget", "&Attribute field", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("GdalToolsWidget", "&Output file for rasterized vectors (raster)", None, QtGui.QApplication.UnicodeUTF8))
        self.resizeGroupBox.setTitle(QtGui.QApplication.translate("GdalToolsWidget", "New size (required if output file doens\'t exist)", None, QtGui.QApplication.UnicodeUTF8))
        self.label_11.setText(QtGui.QApplication.translate("GdalToolsWidget", "Width", None, QtGui.QApplication.UnicodeUTF8))
        self.label_12.setText(QtGui.QApplication.translate("GdalToolsWidget", "Height", None, QtGui.QApplication.UnicodeUTF8))

from inOutSelector import GdalToolsInOutSelector
