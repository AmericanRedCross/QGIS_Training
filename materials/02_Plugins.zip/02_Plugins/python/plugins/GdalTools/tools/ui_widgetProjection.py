# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'D:/src/qgis-1.7.3/python/plugins/GdalTools/tools/widgetProjection.ui'
#
# Created: Sun Dec 11 11:35:47 2011
#      by: PyQt4 UI code generator 4.8.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_GdalToolsWidget(object):
    def setupUi(self, GdalToolsWidget):
        GdalToolsWidget.setObjectName(_fromUtf8("GdalToolsWidget"))
        GdalToolsWidget.resize(369, 244)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(GdalToolsWidget.sizePolicy().hasHeightForWidth())
        GdalToolsWidget.setSizePolicy(sizePolicy)
        self.verticalLayout = QtGui.QVBoxLayout(GdalToolsWidget)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.batchCheck = QtGui.QCheckBox(GdalToolsWidget)
        self.batchCheck.setObjectName(_fromUtf8("batchCheck"))
        self.verticalLayout.addWidget(self.batchCheck)
        self.label_3 = QtGui.QLabel(GdalToolsWidget)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.verticalLayout.addWidget(self.label_3)
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label = QtGui.QLabel(GdalToolsWidget)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.recurseCheck = QtGui.QCheckBox(GdalToolsWidget)
        self.recurseCheck.setObjectName(_fromUtf8("recurseCheck"))
        self.gridLayout.addWidget(self.recurseCheck, 1, 1, 1, 1)
        self.label_2 = QtGui.QLabel(GdalToolsWidget)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 2, 0, 1, 1)
        self.label_4 = QtGui.QLabel(GdalToolsWidget)
        self.label_4.setTextFormat(QtCore.Qt.AutoText)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.gridLayout.addWidget(self.label_4, 3, 1, 1, 1)
        self.inSelector = GdalToolsInOutSelector(GdalToolsWidget)
        self.inSelector.setObjectName(_fromUtf8("inSelector"))
        self.gridLayout.addWidget(self.inSelector, 0, 1, 1, 1)
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        self.desiredSRSEdit = QtGui.QLineEdit(GdalToolsWidget)
        self.desiredSRSEdit.setObjectName(_fromUtf8("desiredSRSEdit"))
        self.horizontalLayout_2.addWidget(self.desiredSRSEdit)
        self.selectDesiredSRSButton = QtGui.QPushButton(GdalToolsWidget)
        self.selectDesiredSRSButton.setObjectName(_fromUtf8("selectDesiredSRSButton"))
        self.horizontalLayout_2.addWidget(self.selectDesiredSRSButton)
        self.gridLayout.addLayout(self.horizontalLayout_2, 2, 1, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)
        self.progressBar = QtGui.QProgressBar(GdalToolsWidget)
        self.progressBar.setObjectName(_fromUtf8("progressBar"))
        self.verticalLayout.addWidget(self.progressBar)
        self.label.setBuddy(self.inSelector)

        self.retranslateUi(GdalToolsWidget)
        QtCore.QMetaObject.connectSlotsByName(GdalToolsWidget)

    def retranslateUi(self, GdalToolsWidget):
        GdalToolsWidget.setWindowTitle(QtGui.QApplication.translate("GdalToolsWidget", "Assign projection", None, QtGui.QApplication.UnicodeUTF8))
        self.batchCheck.setText(QtGui.QApplication.translate("GdalToolsWidget", "Batch mode (for processing whole directory)", None, QtGui.QApplication.UnicodeUTF8))
        self.label_3.setText(QtGui.QApplication.translate("GdalToolsWidget", "WARNING: current projection definition will be cleared", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("GdalToolsWidget", "&Input file", None, QtGui.QApplication.UnicodeUTF8))
        self.recurseCheck.setText(QtGui.QApplication.translate("GdalToolsWidget", "Recurse subdirectories", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("GdalToolsWidget", "Desired SRS", None, QtGui.QApplication.UnicodeUTF8))
        self.label_4.setText(QtGui.QApplication.translate("GdalToolsWidget", "Output will be:\n"
"- new GeoTiff if input file is not GeoTiff\n"
"- overwritten if input is GeoTiff", None, QtGui.QApplication.UnicodeUTF8))
        self.selectDesiredSRSButton.setText(QtGui.QApplication.translate("GdalToolsWidget", "Select...", None, QtGui.QApplication.UnicodeUTF8))

from inOutSelector import GdalToolsInOutSelector
