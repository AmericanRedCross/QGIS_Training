# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'D:/src/qgis-1.7.3/python/plugins/GdalTools/tools/widgetOverview.ui'
#
# Created: Sun Dec 11 11:35:48 2011
#      by: PyQt4 UI code generator 4.8.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_GdalToolsWidget(object):
    def setupUi(self, GdalToolsWidget):
        GdalToolsWidget.setObjectName(_fromUtf8("GdalToolsWidget"))
        GdalToolsWidget.resize(376, 311)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(GdalToolsWidget.sizePolicy().hasHeightForWidth())
        GdalToolsWidget.setSizePolicy(sizePolicy)
        self.verticalLayout = QtGui.QVBoxLayout(GdalToolsWidget)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.batchCheck = QtGui.QCheckBox(GdalToolsWidget)
        self.batchCheck.setObjectName(_fromUtf8("batchCheck"))
        self.verticalLayout.addWidget(self.batchCheck)
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label = QtGui.QLabel(GdalToolsWidget)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.algorithmCheck = QtGui.QCheckBox(GdalToolsWidget)
        self.algorithmCheck.setObjectName(_fromUtf8("algorithmCheck"))
        self.gridLayout.addWidget(self.algorithmCheck, 1, 0, 1, 1)
        self.algorithmCombo = QtGui.QComboBox(GdalToolsWidget)
        self.algorithmCombo.setObjectName(_fromUtf8("algorithmCombo"))
        self.algorithmCombo.addItem(_fromUtf8(""))
        self.algorithmCombo.addItem(_fromUtf8(""))
        self.algorithmCombo.addItem(_fromUtf8(""))
        self.algorithmCombo.addItem(_fromUtf8(""))
        self.algorithmCombo.addItem(_fromUtf8(""))
        self.algorithmCombo.addItem(_fromUtf8(""))
        self.gridLayout.addWidget(self.algorithmCombo, 1, 1, 1, 1)
        self.label_3 = QtGui.QLabel(GdalToolsWidget)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.gridLayout.addWidget(self.label_3, 2, 0, 1, 1)
        self.levelsEdit = QtGui.QLineEdit(GdalToolsWidget)
        self.levelsEdit.setObjectName(_fromUtf8("levelsEdit"))
        self.gridLayout.addWidget(self.levelsEdit, 2, 1, 1, 1)
        self.inSelector = GdalToolsInOutSelector(GdalToolsWidget)
        self.inSelector.setObjectName(_fromUtf8("inSelector"))
        self.gridLayout.addWidget(self.inSelector, 0, 1, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)
        self.cleanCheck = QtGui.QCheckBox(GdalToolsWidget)
        self.cleanCheck.setObjectName(_fromUtf8("cleanCheck"))
        self.verticalLayout.addWidget(self.cleanCheck)
        self.roModeCheck = QtGui.QCheckBox(GdalToolsWidget)
        self.roModeCheck.setObjectName(_fromUtf8("roModeCheck"))
        self.verticalLayout.addWidget(self.roModeCheck)
        self.tiffjpegCheck = QtGui.QCheckBox(GdalToolsWidget)
        self.tiffjpegCheck.setObjectName(_fromUtf8("tiffjpegCheck"))
        self.verticalLayout.addWidget(self.tiffjpegCheck)
        self.jpegQualityContainer = QtGui.QFrame(GdalToolsWidget)
        self.jpegQualityContainer.setEnabled(True)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.jpegQualityContainer.sizePolicy().hasHeightForWidth())
        self.jpegQualityContainer.setSizePolicy(sizePolicy)
        self.jpegQualityContainer.setMinimumSize(QtCore.QSize(0, 25))
        self.jpegQualityContainer.setObjectName(_fromUtf8("jpegQualityContainer"))
        self.horizontalLayout_2 = QtGui.QHBoxLayout(self.jpegQualityContainer)
        self.horizontalLayout_2.setContentsMargins(24, 0, -1, 0)
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        self.jpegQualityLabel = QtGui.QLabel(self.jpegQualityContainer)
        self.jpegQualityLabel.setObjectName(_fromUtf8("jpegQualityLabel"))
        self.horizontalLayout_2.addWidget(self.jpegQualityLabel)
        self.jpegQualitySpin = QtGui.QSpinBox(self.jpegQualityContainer)
        self.jpegQualitySpin.setEnabled(True)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.jpegQualitySpin.sizePolicy().hasHeightForWidth())
        self.jpegQualitySpin.setSizePolicy(sizePolicy)
        self.jpegQualitySpin.setMaximum(100)
        self.jpegQualitySpin.setObjectName(_fromUtf8("jpegQualitySpin"))
        self.horizontalLayout_2.addWidget(self.jpegQualitySpin)
        self.verticalLayout.addWidget(self.jpegQualityContainer)
        self.rrdCheck = QtGui.QCheckBox(GdalToolsWidget)
        self.rrdCheck.setObjectName(_fromUtf8("rrdCheck"))
        self.verticalLayout.addWidget(self.rrdCheck)
        self.progressBar = QtGui.QProgressBar(GdalToolsWidget)
        self.progressBar.setObjectName(_fromUtf8("progressBar"))
        self.verticalLayout.addWidget(self.progressBar)
        self.label.setBuddy(self.inSelector)

        self.retranslateUi(GdalToolsWidget)
        QtCore.QMetaObject.connectSlotsByName(GdalToolsWidget)

    def retranslateUi(self, GdalToolsWidget):
        GdalToolsWidget.setWindowTitle(QtGui.QApplication.translate("GdalToolsWidget", "Build overviews (Pyramids)", None, QtGui.QApplication.UnicodeUTF8))
        self.batchCheck.setText(QtGui.QApplication.translate("GdalToolsWidget", "Batch mode (for processing whole directory)", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("GdalToolsWidget", "&Input file", None, QtGui.QApplication.UnicodeUTF8))
        self.algorithmCheck.setText(QtGui.QApplication.translate("GdalToolsWidget", "Resampling method", None, QtGui.QApplication.UnicodeUTF8))
        self.algorithmCombo.setItemText(0, QtGui.QApplication.translate("GdalToolsWidget", "nearest", None, QtGui.QApplication.UnicodeUTF8))
        self.algorithmCombo.setItemText(1, QtGui.QApplication.translate("GdalToolsWidget", "average", None, QtGui.QApplication.UnicodeUTF8))
        self.algorithmCombo.setItemText(2, QtGui.QApplication.translate("GdalToolsWidget", "gauss", None, QtGui.QApplication.UnicodeUTF8))
        self.algorithmCombo.setItemText(3, QtGui.QApplication.translate("GdalToolsWidget", "average_mp", None, QtGui.QApplication.UnicodeUTF8))
        self.algorithmCombo.setItemText(4, QtGui.QApplication.translate("GdalToolsWidget", "average_magphase", None, QtGui.QApplication.UnicodeUTF8))
        self.algorithmCombo.setItemText(5, QtGui.QApplication.translate("GdalToolsWidget", "mode", None, QtGui.QApplication.UnicodeUTF8))
        self.label_3.setText(QtGui.QApplication.translate("GdalToolsWidget", "Levels (space delimited)", None, QtGui.QApplication.UnicodeUTF8))
        self.cleanCheck.setToolTip(QtGui.QApplication.translate("GdalToolsWidget", "Remove all overviews.", None, QtGui.QApplication.UnicodeUTF8))
        self.cleanCheck.setText(QtGui.QApplication.translate("GdalToolsWidget", "Clean", None, QtGui.QApplication.UnicodeUTF8))
        self.roModeCheck.setToolTip(QtGui.QApplication.translate("GdalToolsWidget", "In order to generate external overview (for GeoTIFF especially).", None, QtGui.QApplication.UnicodeUTF8))
        self.roModeCheck.setText(QtGui.QApplication.translate("GdalToolsWidget", "Open in read-only mode", None, QtGui.QApplication.UnicodeUTF8))
        self.tiffjpegCheck.setToolTip(QtGui.QApplication.translate("GdalToolsWidget", "Create external overviews in TIFF format, compressed using JPEG.", None, QtGui.QApplication.UnicodeUTF8))
        self.tiffjpegCheck.setText(QtGui.QApplication.translate("GdalToolsWidget", "Overviews in TIFF format with JPEG compression", None, QtGui.QApplication.UnicodeUTF8))
        self.jpegQualityLabel.setToolTip(QtGui.QApplication.translate("GdalToolsWidget", "For JPEG compressed external overviews, \n"
"the JPEG quality can be set.", None, QtGui.QApplication.UnicodeUTF8))
        self.jpegQualityLabel.setText(QtGui.QApplication.translate("GdalToolsWidget", "JPEG Quality (1-100)", None, QtGui.QApplication.UnicodeUTF8))
        self.jpegQualitySpin.setToolTip(QtGui.QApplication.translate("GdalToolsWidget", "For JPEG compressed external overviews, \n"
"the JPEG quality can be set.", None, QtGui.QApplication.UnicodeUTF8))
        self.rrdCheck.setToolTip(QtGui.QApplication.translate("GdalToolsWidget", "Alternate overview format using Erdas Imagine format, \n"
"placing the overviews in an associated .aux file \n"
"suitable for direct use with Imagine,ArcGIS, GDAL.", None, QtGui.QApplication.UnicodeUTF8))
        self.rrdCheck.setText(QtGui.QApplication.translate("GdalToolsWidget", "Use Imagine format (.aux file)", None, QtGui.QApplication.UnicodeUTF8))

from inOutSelector import GdalToolsInOutSelector
