# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'D:/src/qgis-1.7.3/python/plugins/GdalTools/tools/dialogBase.ui'
#
# Created: Sun Dec 11 11:35:52 2011
#      by: PyQt4 UI code generator 4.8.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_GdalToolsDialog(object):
    def setupUi(self, GdalToolsDialog):
        GdalToolsDialog.setObjectName(_fromUtf8("GdalToolsDialog"))
        GdalToolsDialog.resize(285, 179)
        self.verticalLayout_2 = QtGui.QVBoxLayout(GdalToolsDialog)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.controlsWidget = QtGui.QWidget(GdalToolsDialog)
        self.controlsWidget.setObjectName(_fromUtf8("controlsWidget"))
        self.pluginLayout = QtGui.QVBoxLayout(self.controlsWidget)
        self.pluginLayout.setMargin(0)
        self.pluginLayout.setMargin(0)
        self.pluginLayout.setObjectName(_fromUtf8("pluginLayout"))
        self.verticalLayout_2.addWidget(self.controlsWidget)
        self.loadCheckBox = QtGui.QCheckBox(GdalToolsDialog)
        self.loadCheckBox.setObjectName(_fromUtf8("loadCheckBox"))
        self.verticalLayout_2.addWidget(self.loadCheckBox)
        self.commandWidget = QtGui.QWidget(GdalToolsDialog)
        self.commandWidget.setLocale(QtCore.QLocale(QtCore.QLocale.English, QtCore.QLocale.UnitedStates))
        self.commandWidget.setObjectName(_fromUtf8("commandWidget"))
        self.gridLayout = QtGui.QGridLayout(self.commandWidget)
        self.gridLayout.setMargin(0)
        self.gridLayout.setMargin(0)
        self.gridLayout.setHorizontalSpacing(6)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.textEditCommand = QtGui.QPlainTextEdit(self.commandWidget)
        self.textEditCommand.setMinimumSize(QtCore.QSize(0, 0))
        self.textEditCommand.setReadOnly(True)
        self.textEditCommand.setObjectName(_fromUtf8("textEditCommand"))
        self.gridLayout.addWidget(self.textEditCommand, 0, 0, 1, 1)
        self.verticalLayout = QtGui.QVBoxLayout()
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.editCmdBtn = QtGui.QToolButton(self.commandWidget)
        self.editCmdBtn.setCheckable(True)
        self.editCmdBtn.setObjectName(_fromUtf8("editCmdBtn"))
        self.verticalLayout.addWidget(self.editCmdBtn)
        self.resetCmdBtn = QtGui.QToolButton(self.commandWidget)
        self.resetCmdBtn.setEnabled(False)
        self.resetCmdBtn.setObjectName(_fromUtf8("resetCmdBtn"))
        self.verticalLayout.addWidget(self.resetCmdBtn)
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)
        self.gridLayout.addLayout(self.verticalLayout, 0, 1, 1, 1)
        self.verticalLayout_2.addWidget(self.commandWidget)
        self.buttonBox = QtGui.QDialogButtonBox(GdalToolsDialog)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Close|QtGui.QDialogButtonBox.Help|QtGui.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName(_fromUtf8("buttonBox"))
        self.verticalLayout_2.addWidget(self.buttonBox)

        self.retranslateUi(GdalToolsDialog)
        QtCore.QMetaObject.connectSlotsByName(GdalToolsDialog)

    def retranslateUi(self, GdalToolsDialog):
        GdalToolsDialog.setWindowTitle(QtGui.QApplication.translate("GdalToolsDialog", "Dialog", None, QtGui.QApplication.UnicodeUTF8))
        self.loadCheckBox.setText(QtGui.QApplication.translate("GdalToolsDialog", "&Load into canvas when finished", None, QtGui.QApplication.UnicodeUTF8))
        self.editCmdBtn.setToolTip(QtGui.QApplication.translate("GdalToolsDialog", "Edit", None, QtGui.QApplication.UnicodeUTF8))
        self.editCmdBtn.setText(QtGui.QApplication.translate("GdalToolsDialog", "Edit", None, QtGui.QApplication.UnicodeUTF8))
        self.resetCmdBtn.setToolTip(QtGui.QApplication.translate("GdalToolsDialog", "Reset", None, QtGui.QApplication.UnicodeUTF8))
        self.resetCmdBtn.setText(QtGui.QApplication.translate("GdalToolsDialog", "Reset", None, QtGui.QApplication.UnicodeUTF8))

