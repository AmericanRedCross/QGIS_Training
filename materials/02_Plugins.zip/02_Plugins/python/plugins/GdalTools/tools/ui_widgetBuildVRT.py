# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'D:/src/qgis-1.7.3/python/plugins/GdalTools/tools/widgetBuildVRT.ui'
#
# Created: Sun Dec 11 11:35:50 2011
#      by: PyQt4 UI code generator 4.8.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_GdalToolsWidget(object):
    def setupUi(self, GdalToolsWidget):
        GdalToolsWidget.setObjectName(_fromUtf8("GdalToolsWidget"))
        GdalToolsWidget.resize(348, 216)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(GdalToolsWidget.sizePolicy().hasHeightForWidth())
        GdalToolsWidget.setSizePolicy(sizePolicy)
        self.verticalLayout = QtGui.QVBoxLayout(GdalToolsWidget)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setSizeConstraint(QtGui.QLayout.SetNoConstraint)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.inputDirCheck = QtGui.QCheckBox(GdalToolsWidget)
        self.inputDirCheck.setObjectName(_fromUtf8("inputDirCheck"))
        self.gridLayout.addWidget(self.inputDirCheck, 0, 0, 1, 2)
        self.label = QtGui.QLabel(GdalToolsWidget)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 1, 0, 1, 1)
        self.recurseCheck = QtGui.QCheckBox(GdalToolsWidget)
        self.recurseCheck.setObjectName(_fromUtf8("recurseCheck"))
        self.gridLayout.addWidget(self.recurseCheck, 2, 1, 1, 1)
        self.label_2 = QtGui.QLabel(GdalToolsWidget)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 3, 0, 1, 1)
        self.resolutionCheck = QtGui.QCheckBox(GdalToolsWidget)
        self.resolutionCheck.setObjectName(_fromUtf8("resolutionCheck"))
        self.gridLayout.addWidget(self.resolutionCheck, 4, 0, 1, 1)
        self.resolutionComboBox = QtGui.QComboBox(GdalToolsWidget)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.resolutionComboBox.sizePolicy().hasHeightForWidth())
        self.resolutionComboBox.setSizePolicy(sizePolicy)
        self.resolutionComboBox.setObjectName(_fromUtf8("resolutionComboBox"))
        self.resolutionComboBox.addItem(_fromUtf8(""))
        self.resolutionComboBox.addItem(_fromUtf8(""))
        self.resolutionComboBox.addItem(_fromUtf8(""))
        self.gridLayout.addWidget(self.resolutionComboBox, 4, 1, 1, 1)
        self.srcNoDataCheck = QtGui.QCheckBox(GdalToolsWidget)
        self.srcNoDataCheck.setObjectName(_fromUtf8("srcNoDataCheck"))
        self.gridLayout.addWidget(self.srcNoDataCheck, 5, 0, 1, 1)
        self.srcNoDataSpin = QtGui.QSpinBox(GdalToolsWidget)
        self.srcNoDataSpin.setMinimum(-100000)
        self.srcNoDataSpin.setMaximum(65000)
        self.srcNoDataSpin.setObjectName(_fromUtf8("srcNoDataSpin"))
        self.gridLayout.addWidget(self.srcNoDataSpin, 5, 1, 1, 1)
        self.separateCheck = QtGui.QCheckBox(GdalToolsWidget)
        self.separateCheck.setObjectName(_fromUtf8("separateCheck"))
        self.gridLayout.addWidget(self.separateCheck, 6, 0, 1, 1)
        self.inSelector = GdalToolsInOutSelector(GdalToolsWidget)
        self.inSelector.setObjectName(_fromUtf8("inSelector"))
        self.gridLayout.addWidget(self.inSelector, 1, 1, 1, 1)
        self.outSelector = GdalToolsInOutSelector(GdalToolsWidget)
        self.outSelector.setObjectName(_fromUtf8("outSelector"))
        self.gridLayout.addWidget(self.outSelector, 3, 1, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)
        self.label.setBuddy(self.inSelector)
        self.label_2.setBuddy(self.outSelector)

        self.retranslateUi(GdalToolsWidget)
        self.resolutionComboBox.setCurrentIndex(1)
        QtCore.QMetaObject.connectSlotsByName(GdalToolsWidget)

    def retranslateUi(self, GdalToolsWidget):
        GdalToolsWidget.setWindowTitle(QtGui.QApplication.translate("GdalToolsWidget", "Build Virtual Raster (Catalog)", None, QtGui.QApplication.UnicodeUTF8))
        self.inputDirCheck.setText(QtGui.QApplication.translate("GdalToolsWidget", "Choose input directory instead of files", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("GdalToolsWidget", "&Input files", None, QtGui.QApplication.UnicodeUTF8))
        self.recurseCheck.setText(QtGui.QApplication.translate("GdalToolsWidget", "Recurse subdirectories", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("GdalToolsWidget", "&Output file", None, QtGui.QApplication.UnicodeUTF8))
        self.resolutionCheck.setText(QtGui.QApplication.translate("GdalToolsWidget", "&Resolution", None, QtGui.QApplication.UnicodeUTF8))
        self.resolutionComboBox.setItemText(0, QtGui.QApplication.translate("GdalToolsWidget", "Highest", None, QtGui.QApplication.UnicodeUTF8))
        self.resolutionComboBox.setItemText(1, QtGui.QApplication.translate("GdalToolsWidget", "Average", None, QtGui.QApplication.UnicodeUTF8))
        self.resolutionComboBox.setItemText(2, QtGui.QApplication.translate("GdalToolsWidget", "Lowest", None, QtGui.QApplication.UnicodeUTF8))
        self.srcNoDataCheck.setText(QtGui.QApplication.translate("GdalToolsWidget", "&Source No Data", None, QtGui.QApplication.UnicodeUTF8))
        self.separateCheck.setText(QtGui.QApplication.translate("GdalToolsWidget", "Se&parate", None, QtGui.QApplication.UnicodeUTF8))

from inOutSelector import GdalToolsInOutSelector
