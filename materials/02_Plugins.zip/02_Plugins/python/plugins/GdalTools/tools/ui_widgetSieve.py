# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'D:/src/qgis-1.7.3/python/plugins/GdalTools/tools/widgetSieve.ui'
#
# Created: Sun Dec 11 11:35:46 2011
#      by: PyQt4 UI code generator 4.8.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_GdalToolsWidget(object):
    def setupUi(self, GdalToolsWidget):
        GdalToolsWidget.setObjectName(_fromUtf8("GdalToolsWidget"))
        GdalToolsWidget.resize(365, 129)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(GdalToolsWidget.sizePolicy().hasHeightForWidth())
        GdalToolsWidget.setSizePolicy(sizePolicy)
        self.verticalLayout = QtGui.QVBoxLayout(GdalToolsWidget)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label = QtGui.QLabel(GdalToolsWidget)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.label_2 = QtGui.QLabel(GdalToolsWidget)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 1, 0, 1, 1)
        self.thresholdCheck = QtGui.QCheckBox(GdalToolsWidget)
        self.thresholdCheck.setObjectName(_fromUtf8("thresholdCheck"))
        self.gridLayout.addWidget(self.thresholdCheck, 2, 0, 1, 1)
        self.thresholdSpin = QtGui.QSpinBox(GdalToolsWidget)
        self.thresholdSpin.setMaximum(65000)
        self.thresholdSpin.setObjectName(_fromUtf8("thresholdSpin"))
        self.gridLayout.addWidget(self.thresholdSpin, 2, 1, 1, 1)
        self.connectionsCheck = QtGui.QCheckBox(GdalToolsWidget)
        self.connectionsCheck.setObjectName(_fromUtf8("connectionsCheck"))
        self.gridLayout.addWidget(self.connectionsCheck, 3, 0, 1, 1)
        self.connectionsCombo = QtGui.QComboBox(GdalToolsWidget)
        self.connectionsCombo.setObjectName(_fromUtf8("connectionsCombo"))
        self.connectionsCombo.addItem(_fromUtf8(""))
        self.connectionsCombo.addItem(_fromUtf8(""))
        self.gridLayout.addWidget(self.connectionsCombo, 3, 1, 1, 1)
        self.inSelector = GdalToolsInOutSelector(GdalToolsWidget)
        self.inSelector.setObjectName(_fromUtf8("inSelector"))
        self.gridLayout.addWidget(self.inSelector, 0, 1, 1, 1)
        self.outSelector = GdalToolsInOutSelector(GdalToolsWidget)
        self.outSelector.setObjectName(_fromUtf8("outSelector"))
        self.gridLayout.addWidget(self.outSelector, 1, 1, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)
        self.label.setBuddy(self.inSelector)
        self.label_2.setBuddy(self.outSelector)

        self.retranslateUi(GdalToolsWidget)
        QtCore.QMetaObject.connectSlotsByName(GdalToolsWidget)

    def retranslateUi(self, GdalToolsWidget):
        GdalToolsWidget.setWindowTitle(QtGui.QApplication.translate("GdalToolsWidget", "Sieve", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("GdalToolsWidget", "&Input file", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("GdalToolsWidget", "&Output file", None, QtGui.QApplication.UnicodeUTF8))
        self.thresholdCheck.setText(QtGui.QApplication.translate("GdalToolsWidget", "&Threshold", None, QtGui.QApplication.UnicodeUTF8))
        self.connectionsCheck.setText(QtGui.QApplication.translate("GdalToolsWidget", "&Pixel connections", None, QtGui.QApplication.UnicodeUTF8))
        self.connectionsCombo.setItemText(0, QtGui.QApplication.translate("GdalToolsWidget", "4", None, QtGui.QApplication.UnicodeUTF8))
        self.connectionsCombo.setItemText(1, QtGui.QApplication.translate("GdalToolsWidget", "8", None, QtGui.QApplication.UnicodeUTF8))

from inOutSelector import GdalToolsInOutSelector
