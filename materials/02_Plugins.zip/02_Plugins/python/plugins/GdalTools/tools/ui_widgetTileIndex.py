# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'D:/src/qgis-1.7.3/python/plugins/GdalTools/tools/widgetTileIndex.ui'
#
# Created: Sun Dec 11 11:35:46 2011
#      by: PyQt4 UI code generator 4.8.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_GdalToolsWidget(object):
    def setupUi(self, GdalToolsWidget):
        GdalToolsWidget.setObjectName(_fromUtf8("GdalToolsWidget"))
        GdalToolsWidget.resize(400, 181)
        self.verticalLayout = QtGui.QVBoxLayout(GdalToolsWidget)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label = QtGui.QLabel(GdalToolsWidget)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.recurseCheck = QtGui.QCheckBox(GdalToolsWidget)
        self.recurseCheck.setObjectName(_fromUtf8("recurseCheck"))
        self.gridLayout.addWidget(self.recurseCheck, 1, 1, 1, 1)
        self.label_2 = QtGui.QLabel(GdalToolsWidget)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 2, 0, 1, 1)
        self.indexFieldCheck = QtGui.QCheckBox(GdalToolsWidget)
        self.indexFieldCheck.setObjectName(_fromUtf8("indexFieldCheck"))
        self.gridLayout.addWidget(self.indexFieldCheck, 3, 0, 1, 1)
        self.indexFieldEdit = QtGui.QLineEdit(GdalToolsWidget)
        self.indexFieldEdit.setEnabled(True)
        self.indexFieldEdit.setObjectName(_fromUtf8("indexFieldEdit"))
        self.gridLayout.addWidget(self.indexFieldEdit, 3, 1, 1, 1)
        self.inSelector = GdalToolsInOutSelector(GdalToolsWidget)
        self.inSelector.setObjectName(_fromUtf8("inSelector"))
        self.gridLayout.addWidget(self.inSelector, 0, 1, 1, 1)
        self.outSelector = GdalToolsInOutSelector(GdalToolsWidget)
        self.outSelector.setObjectName(_fromUtf8("outSelector"))
        self.gridLayout.addWidget(self.outSelector, 2, 1, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)
        self.absolutePathCheck = QtGui.QCheckBox(GdalToolsWidget)
        self.absolutePathCheck.setObjectName(_fromUtf8("absolutePathCheck"))
        self.verticalLayout.addWidget(self.absolutePathCheck)
        self.skipDifferentProjCheck = QtGui.QCheckBox(GdalToolsWidget)
        self.skipDifferentProjCheck.setObjectName(_fromUtf8("skipDifferentProjCheck"))
        self.verticalLayout.addWidget(self.skipDifferentProjCheck)
        self.label.setBuddy(self.inSelector)
        self.label_2.setBuddy(self.outSelector)

        self.retranslateUi(GdalToolsWidget)
        QtCore.QMetaObject.connectSlotsByName(GdalToolsWidget)

    def retranslateUi(self, GdalToolsWidget):
        GdalToolsWidget.setWindowTitle(QtGui.QApplication.translate("GdalToolsWidget", "Raster tile index", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("GdalToolsWidget", "Input directory", None, QtGui.QApplication.UnicodeUTF8))
        self.recurseCheck.setText(QtGui.QApplication.translate("GdalToolsWidget", "Recurse subdirectories", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("GdalToolsWidget", "Output shapefile", None, QtGui.QApplication.UnicodeUTF8))
        self.indexFieldCheck.setText(QtGui.QApplication.translate("GdalToolsWidget", "Tile index field", None, QtGui.QApplication.UnicodeUTF8))
        self.indexFieldEdit.setText(QtGui.QApplication.translate("GdalToolsWidget", "location", None, QtGui.QApplication.UnicodeUTF8))
        self.absolutePathCheck.setText(QtGui.QApplication.translate("GdalToolsWidget", "Write absolute path", None, QtGui.QApplication.UnicodeUTF8))
        self.skipDifferentProjCheck.setText(QtGui.QApplication.translate("GdalToolsWidget", "Skip files with different projection ref", None, QtGui.QApplication.UnicodeUTF8))

from inOutSelector import GdalToolsInOutSelector
