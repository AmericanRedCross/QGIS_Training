# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'D:/src/qgis-1.7.3/python/plugins/GdalTools/tools/extentSelector.ui'
#
# Created: Sun Dec 11 11:35:51 2011
#      by: PyQt4 UI code generator 4.8.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_GdalToolsExtentSelector(object):
    def setupUi(self, GdalToolsExtentSelector):
        GdalToolsExtentSelector.setObjectName(_fromUtf8("GdalToolsExtentSelector"))
        GdalToolsExtentSelector.resize(343, 134)
        self.gridLayout = QtGui.QGridLayout(GdalToolsExtentSelector)
        self.gridLayout.setMargin(0)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label = QtGui.QLabel(GdalToolsExtentSelector)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 1, 0, 1, 1)
        self.label_7 = QtGui.QLabel(GdalToolsExtentSelector)
        self.label_7.setObjectName(_fromUtf8("label_7"))
        self.gridLayout.addWidget(self.label_7, 3, 0, 1, 2)
        self.widget = QtGui.QWidget(GdalToolsExtentSelector)
        self.widget.setObjectName(_fromUtf8("widget"))
        self.gridLayout_3 = QtGui.QGridLayout(self.widget)
        self.gridLayout_3.setMargin(0)
        self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))
        self.label_11 = QtGui.QLabel(self.widget)
        self.label_11.setObjectName(_fromUtf8("label_11"))
        self.gridLayout_3.addWidget(self.label_11, 0, 2, 1, 1)
        self.x1CoordEdit = QtGui.QLineEdit(self.widget)
        self.x1CoordEdit.setObjectName(_fromUtf8("x1CoordEdit"))
        self.gridLayout_3.addWidget(self.x1CoordEdit, 0, 3, 1, 1)
        self.label_13 = QtGui.QLabel(self.widget)
        self.label_13.setObjectName(_fromUtf8("label_13"))
        self.gridLayout_3.addWidget(self.label_13, 0, 7, 1, 1)
        self.x2CoordEdit = QtGui.QLineEdit(self.widget)
        self.x2CoordEdit.setObjectName(_fromUtf8("x2CoordEdit"))
        self.gridLayout_3.addWidget(self.x2CoordEdit, 0, 8, 1, 1)
        self.y1CoordEdit = QtGui.QLineEdit(self.widget)
        self.y1CoordEdit.setObjectName(_fromUtf8("y1CoordEdit"))
        self.gridLayout_3.addWidget(self.y1CoordEdit, 1, 3, 1, 1)
        self.y2CoordEdit = QtGui.QLineEdit(self.widget)
        self.y2CoordEdit.setObjectName(_fromUtf8("y2CoordEdit"))
        self.gridLayout_3.addWidget(self.y2CoordEdit, 1, 8, 1, 1)
        self.label_15 = QtGui.QLabel(self.widget)
        self.label_15.setObjectName(_fromUtf8("label_15"))
        self.gridLayout_3.addWidget(self.label_15, 1, 7, 1, 1)
        self.label_14 = QtGui.QLabel(self.widget)
        self.label_14.setObjectName(_fromUtf8("label_14"))
        self.gridLayout_3.addWidget(self.label_14, 1, 2, 1, 1)
        self.label_12 = QtGui.QLabel(self.widget)
        self.label_12.setIndent(20)
        self.label_12.setObjectName(_fromUtf8("label_12"))
        self.gridLayout_3.addWidget(self.label_12, 0, 6, 2, 1)
        self.label_10 = QtGui.QLabel(self.widget)
        self.label_10.setObjectName(_fromUtf8("label_10"))
        self.gridLayout_3.addWidget(self.label_10, 0, 1, 2, 1)
        self.gridLayout.addWidget(self.widget, 4, 0, 1, 2)
        self.btnEnable = QtGui.QPushButton(GdalToolsExtentSelector)
        self.btnEnable.setObjectName(_fromUtf8("btnEnable"))
        self.gridLayout.addWidget(self.btnEnable, 1, 1, 1, 1)

        self.retranslateUi(GdalToolsExtentSelector)
        QtCore.QMetaObject.connectSlotsByName(GdalToolsExtentSelector)

    def retranslateUi(self, GdalToolsExtentSelector):
        self.label.setText(QtGui.QApplication.translate("GdalToolsExtentSelector", "Select the extent by drag on canvas", None, QtGui.QApplication.UnicodeUTF8))
        self.label_7.setText(QtGui.QApplication.translate("GdalToolsExtentSelector", "or change the extent coordinates", None, QtGui.QApplication.UnicodeUTF8))
        self.label_11.setText(QtGui.QApplication.translate("GdalToolsExtentSelector", "x", None, QtGui.QApplication.UnicodeUTF8))
        self.label_13.setText(QtGui.QApplication.translate("GdalToolsExtentSelector", "x", None, QtGui.QApplication.UnicodeUTF8))
        self.label_15.setText(QtGui.QApplication.translate("GdalToolsExtentSelector", "y", None, QtGui.QApplication.UnicodeUTF8))
        self.label_14.setText(QtGui.QApplication.translate("GdalToolsExtentSelector", "y", None, QtGui.QApplication.UnicodeUTF8))
        self.label_12.setText(QtGui.QApplication.translate("GdalToolsExtentSelector", "2", None, QtGui.QApplication.UnicodeUTF8))
        self.label_10.setText(QtGui.QApplication.translate("GdalToolsExtentSelector", "1", None, QtGui.QApplication.UnicodeUTF8))
        self.btnEnable.setText(QtGui.QApplication.translate("GdalToolsExtentSelector", "Re-Enable", None, QtGui.QApplication.UnicodeUTF8))

