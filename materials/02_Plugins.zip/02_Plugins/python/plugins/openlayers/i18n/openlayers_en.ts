<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="en">
<context>
    <name>Form</name>
    <message>
        <location filename="openlayers_ovwidgetbase.py" line="72"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="openlayers_ovwidgetbase.py" line="73"/>
        <source>Enable map</source>
        <translation>Enable map</translation>
    </message>
    <message>
        <location filename="openlayers_ovwidgetbase.py" line="74"/>
        <source>Add map</source>
        <translation>Add map</translation>
    </message>
    <message>
        <location filename="openlayers_ovwidgetbase.py" line="75"/>
        <source>Hide cross in map</source>
        <translation>Hide cross in map</translation>
    </message>
    <message>
        <location filename="openlayers_ovwidgetbase.py" line="76"/>
        <source>Refresh map</source>
        <translation>Refresh map</translation>
    </message>
    <message>
        <location filename="openlayers_ovwidgetbase.py" line="77"/>
        <source>Save this image</source>
        <translation>Save this image</translation>
    </message>
    <message>
        <location filename="openlayers_ovwidgetbase.py" line="78"/>
        <source>Copy rectangle (KML) of map to clipboard</source>
        <translation>Copy rectangle (KML) of map to clipboard</translation>
    </message>
</context>
<context>
    <name>OpenLayersOverviewWidget</name>
    <message>
        <location filename="openlayers_ovwidget.py" line="235"/>
        <source>Save image</source>
        <translation>Save image</translation>
    </message>
    <message>
        <location filename="openlayers_ovwidget.py" line="235"/>
        <source>Image(*.jpg)</source>
        <translation>Image(*.jpg)</translation>
    </message>
    <message>
        <location filename="openlayers_ovwidget.py" line="248"/>
        <source>OpenLayers Overview</source>
        <translation>OpenLayers Overview</translation>
    </message>
    <message>
        <location filename="openlayers_ovwidget.py" line="158"/>
        <source>At least one layer in map canvas required</source>
        <translation>At least one layer in map canvas required</translation>
    </message>
    <message>
        <location filename="openlayers_ovwidget.py" line="248"/>
        <source>Error loading page!</source>
        <translation>Error loading page!</translation>
    </message>
    <message>
        <location filename="openlayers_ovwidget.py" line="258"/>
        <source>Loading %1...</source>
        <translation>Loading %1...</translation>
    </message>
</context>
<context>
    <name>OpenlayersPlugin</name>
    <message>
        <location filename="openlayers_plugin.py" line="144"/>
        <source>OpenLayers Overview</source>
        <translation>OpenLayers Overview</translation>
    </message>
    <message>
        <location filename="openlayers_plugin.py" line="154"/>
        <source>Add %1 layer</source>
        <translation>Add %1 layer</translation>
    </message>
    <message>
        <location filename="openlayers_plugin.py" line="161"/>
        <source>Could not set Google projection!</source>
        <translation>Could not set Google projection!</translation>
    </message>
</context>
</TS>
